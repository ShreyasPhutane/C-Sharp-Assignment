﻿namespace Destiny.cs
{
}

namespace Destiny.cs
{
}

namespace Destiny.cs
{
}

namespace Destiny.cs
{
}

namespace Destiny.cs
{


    public partial class DataSet1
    {
    }
}

namespace Destiny.cs.DataSetTableAdapters {
    
    
    public partial class Registration_PaymentTableAdapter {
    }
}
