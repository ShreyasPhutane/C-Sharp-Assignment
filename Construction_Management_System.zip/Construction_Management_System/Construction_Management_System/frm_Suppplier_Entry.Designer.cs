﻿namespace Construction_Management_System
{
    partial class frm_Suppplier_Entry
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_Supplier_Details = new System.Windows.Forms.Label();
            this.lbl_Supplier_ID = new System.Windows.Forms.Label();
            this.lbl_Supplier_Nsme = new System.Windows.Forms.Label();
            this.lbl_Address = new System.Windows.Forms.Label();
            this.lbl_Mobile_No = new System.Windows.Forms.Label();
            this.btn_New = new System.Windows.Forms.Button();
            this.btn_Save = new System.Windows.Forms.Button();
            this.btn_Update = new System.Windows.Forms.Button();
            this.btn_Delete = new System.Windows.Forms.Button();
            this.tb_Supplier_ID = new System.Windows.Forms.TextBox();
            this.tb_Supplier_Name = new System.Windows.Forms.TextBox();
            this.tb_Address = new System.Windows.Forms.TextBox();
            this.tb_Mobile_No = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // lbl_Supplier_Details
            // 
            this.lbl_Supplier_Details.AutoSize = true;
            this.lbl_Supplier_Details.Font = new System.Drawing.Font("Cambria", 30F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Supplier_Details.Location = new System.Drawing.Point(312, 55);
            this.lbl_Supplier_Details.Name = "lbl_Supplier_Details";
            this.lbl_Supplier_Details.Size = new System.Drawing.Size(490, 59);
            this.lbl_Supplier_Details.TabIndex = 0;
            this.lbl_Supplier_Details.Text = "SUPPPLIER DETAILS";
            // 
            // lbl_Supplier_ID
            // 
            this.lbl_Supplier_ID.AutoSize = true;
            this.lbl_Supplier_ID.Font = new System.Drawing.Font("Cambria", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Supplier_ID.Location = new System.Drawing.Point(239, 213);
            this.lbl_Supplier_ID.Name = "lbl_Supplier_ID";
            this.lbl_Supplier_ID.Size = new System.Drawing.Size(215, 40);
            this.lbl_Supplier_ID.TabIndex = 1;
            this.lbl_Supplier_ID.Text = "SUPPLIER ID";
            // 
            // lbl_Supplier_Nsme
            // 
            this.lbl_Supplier_Nsme.AutoSize = true;
            this.lbl_Supplier_Nsme.Font = new System.Drawing.Font("Cambria", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Supplier_Nsme.Location = new System.Drawing.Point(235, 305);
            this.lbl_Supplier_Nsme.Name = "lbl_Supplier_Nsme";
            this.lbl_Supplier_Nsme.Size = new System.Drawing.Size(264, 38);
            this.lbl_Supplier_Nsme.TabIndex = 2;
            this.lbl_Supplier_Nsme.Text = "SUPPLIER NAME";
            // 
            // lbl_Address
            // 
            this.lbl_Address.AutoSize = true;
            this.lbl_Address.Font = new System.Drawing.Font("Cambria", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Address.Location = new System.Drawing.Point(239, 396);
            this.lbl_Address.Name = "lbl_Address";
            this.lbl_Address.Size = new System.Drawing.Size(160, 38);
            this.lbl_Address.TabIndex = 3;
            this.lbl_Address.Text = "ADDRESS";
            // 
            // lbl_Mobile_No
            // 
            this.lbl_Mobile_No.AutoSize = true;
            this.lbl_Mobile_No.Font = new System.Drawing.Font("Cambria", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Mobile_No.Location = new System.Drawing.Point(257, 547);
            this.lbl_Mobile_No.Name = "lbl_Mobile_No";
            this.lbl_Mobile_No.Size = new System.Drawing.Size(190, 38);
            this.lbl_Mobile_No.TabIndex = 4;
            this.lbl_Mobile_No.Text = "MOBILE NO";
            // 
            // btn_New
            // 
            this.btn_New.Font = new System.Drawing.Font("Cambria", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_New.Location = new System.Drawing.Point(127, 644);
            this.btn_New.Name = "btn_New";
            this.btn_New.Size = new System.Drawing.Size(136, 51);
            this.btn_New.TabIndex = 5;
            this.btn_New.Text = "NEW";
            this.btn_New.UseVisualStyleBackColor = true;
            // 
            // btn_Save
            // 
            this.btn_Save.Font = new System.Drawing.Font("Cambria", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Save.Location = new System.Drawing.Point(307, 644);
            this.btn_Save.Name = "btn_Save";
            this.btn_Save.Size = new System.Drawing.Size(140, 51);
            this.btn_Save.TabIndex = 6;
            this.btn_Save.Text = "SAVE";
            this.btn_Save.UseVisualStyleBackColor = true;
            // 
            // btn_Update
            // 
            this.btn_Update.Font = new System.Drawing.Font("Cambria", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Update.Location = new System.Drawing.Point(506, 644);
            this.btn_Update.Name = "btn_Update";
            this.btn_Update.Size = new System.Drawing.Size(186, 51);
            this.btn_Update.TabIndex = 7;
            this.btn_Update.Text = "UPDATE";
            this.btn_Update.UseVisualStyleBackColor = true;
            // 
            // btn_Delete
            // 
            this.btn_Delete.Font = new System.Drawing.Font("Cambria", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Delete.Location = new System.Drawing.Point(748, 644);
            this.btn_Delete.Name = "btn_Delete";
            this.btn_Delete.Size = new System.Drawing.Size(166, 51);
            this.btn_Delete.TabIndex = 8;
            this.btn_Delete.Text = "DELETE";
            this.btn_Delete.UseVisualStyleBackColor = true;
            // 
            // tb_Supplier_ID
            // 
            this.tb_Supplier_ID.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Supplier_ID.Location = new System.Drawing.Point(547, 208);
            this.tb_Supplier_ID.Name = "tb_Supplier_ID";
            this.tb_Supplier_ID.Size = new System.Drawing.Size(255, 45);
            this.tb_Supplier_ID.TabIndex = 9;
            // 
            // tb_Supplier_Name
            // 
            this.tb_Supplier_Name.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Supplier_Name.Location = new System.Drawing.Point(547, 305);
            this.tb_Supplier_Name.Name = "tb_Supplier_Name";
            this.tb_Supplier_Name.Size = new System.Drawing.Size(255, 45);
            this.tb_Supplier_Name.TabIndex = 10;
            // 
            // tb_Address
            // 
            this.tb_Address.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Address.Location = new System.Drawing.Point(547, 396);
            this.tb_Address.Multiline = true;
            this.tb_Address.Name = "tb_Address";
            this.tb_Address.Size = new System.Drawing.Size(255, 106);
            this.tb_Address.TabIndex = 11;
            // 
            // tb_Mobile_No
            // 
            this.tb_Mobile_No.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Mobile_No.Location = new System.Drawing.Point(547, 547);
            this.tb_Mobile_No.Name = "tb_Mobile_No";
            this.tb_Mobile_No.Size = new System.Drawing.Size(255, 45);
            this.tb_Mobile_No.TabIndex = 12;
            // 
            // frm_Suppplier_Entry
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1112, 726);
            this.Controls.Add(this.tb_Mobile_No);
            this.Controls.Add(this.tb_Address);
            this.Controls.Add(this.tb_Supplier_Name);
            this.Controls.Add(this.tb_Supplier_ID);
            this.Controls.Add(this.btn_Delete);
            this.Controls.Add(this.btn_Update);
            this.Controls.Add(this.btn_Save);
            this.Controls.Add(this.btn_New);
            this.Controls.Add(this.lbl_Mobile_No);
            this.Controls.Add(this.lbl_Address);
            this.Controls.Add(this.lbl_Supplier_Nsme);
            this.Controls.Add(this.lbl_Supplier_ID);
            this.Controls.Add(this.lbl_Supplier_Details);
            this.Name = "frm_Suppplier_Entry";
            this.Text = "SUPPLIER ENTRY";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_Supplier_Details;
        private System.Windows.Forms.Label lbl_Supplier_ID;
        private System.Windows.Forms.Label lbl_Supplier_Nsme;
        private System.Windows.Forms.Label lbl_Address;
        private System.Windows.Forms.Label lbl_Mobile_No;
        private System.Windows.Forms.Button btn_New;
        private System.Windows.Forms.Button btn_Save;
        private System.Windows.Forms.Button btn_Update;
        private System.Windows.Forms.Button btn_Delete;
        private System.Windows.Forms.TextBox tb_Supplier_ID;
        private System.Windows.Forms.TextBox tb_Supplier_Name;
        private System.Windows.Forms.TextBox tb_Address;
        private System.Windows.Forms.TextBox tb_Mobile_No;
    }
}