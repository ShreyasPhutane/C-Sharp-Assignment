﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Destiny.cs
{
    public partial class Frm_Create_Profile_For : Form
    {
        public Frm_Create_Profile_For()
        {
            InitializeComponent();
        }

        private void btn_self_Click(object sender, EventArgs e)
        {
            frm_All_Details obj = new frm_All_Details();
            obj.Show();
            this.Hide();
        }
    }
}
