﻿namespace Destiny.cs
{
    partial class frm_Profile_Information
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.lbl_Profile_Information = new System.Windows.Forms.Label();
            this.pb_profile = new System.Windows.Forms.PictureBox();
            this.btn_Search = new System.Windows.Forms.Button();
            this.tb_ID = new System.Windows.Forms.TextBox();
            this.lbl_Profile_ID = new System.Windows.Forms.Label();
            this.tb_Mobile_No = new System.Windows.Forms.TextBox();
            this.lbl_Religion = new System.Windows.Forms.Label();
            this.lbl_Mobile_No = new System.Windows.Forms.Label();
            this.dtp_DOB = new System.Windows.Forms.DateTimePicker();
            this.lbl_DOB = new System.Windows.Forms.Label();
            this.tb_Gender = new System.Windows.Forms.TextBox();
            this.lbl_Gender = new System.Windows.Forms.Label();
            this.tb_Last_Name = new System.Windows.Forms.TextBox();
            this.lbl_Last_Name = new System.Windows.Forms.Label();
            this.tb_First_Name = new System.Windows.Forms.TextBox();
            this.lbl_First_Name = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.tb_Religion = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.tb_Highest_Education = new System.Windows.Forms.TextBox();
            this.tb_Complexion = new System.Windows.Forms.TextBox();
            this.tb_Body_Type = new System.Windows.Forms.TextBox();
            this.tb_Residing_City = new System.Windows.Forms.TextBox();
            this.tb_Residing_State = new System.Windows.Forms.TextBox();
            this.lbl_Highest_Education = new System.Windows.Forms.Label();
            this.tb_Weight = new System.Windows.Forms.TextBox();
            this.tb_Height = new System.Windows.Forms.TextBox();
            this.lbl_Complexion = new System.Windows.Forms.Label();
            this.lbl_Body_Type = new System.Windows.Forms.Label();
            this.lbl_Weight = new System.Windows.Forms.Label();
            this.lbl_Height = new System.Windows.Forms.Label();
            this.tb_Address = new System.Windows.Forms.TextBox();
            this.lbl_Address = new System.Windows.Forms.Label();
            this.tb_Gothra = new System.Windows.Forms.TextBox();
            this.tb_Sub_Caste = new System.Windows.Forms.TextBox();
            this.tb_Caste = new System.Windows.Forms.TextBox();
            this.lbl_Residing_State = new System.Windows.Forms.Label();
            this.lbl_Gothra = new System.Windows.Forms.Label();
            this.lbl_Sub_Caste = new System.Windows.Forms.Label();
            this.lbl_Caste = new System.Windows.Forms.Label();
            this.lbl_Residing_City = new System.Windows.Forms.Label();
            this.lbl_Marital_Status = new System.Windows.Forms.Label();
            this.tb_Marital_Status = new System.Windows.Forms.TextBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.tb_Family_Values = new System.Windows.Forms.TextBox();
            this.tb_Family_Type = new System.Windows.Forms.TextBox();
            this.tb_Family_Status = new System.Windows.Forms.TextBox();
            this.tb_Monthly_Income = new System.Windows.Forms.TextBox();
            this.tb_Employed_In = new System.Windows.Forms.TextBox();
            this.lbl_Family_Values = new System.Windows.Forms.Label();
            this.lbl_Family_Type = new System.Windows.Forms.Label();
            this.lbl_Family_Status = new System.Windows.Forms.Label();
            this.tb_Rassi_Moon_Sign = new System.Windows.Forms.TextBox();
            this.lbl_Rassi_Moon_Sign = new System.Windows.Forms.Label();
            this.lbl_Employed_In = new System.Windows.Forms.Label();
            this.lbl_Monthly_Income = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_profile)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel1.Controls.Add(this.pictureBox7);
            this.panel1.Controls.Add(this.lbl_Profile_Information);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1482, 116);
            this.panel1.TabIndex = 18;
            // 
            // pictureBox7
            // 
            this.pictureBox7.Image = global::Destiny.cs.Properties.Resources.download__1_1;
            this.pictureBox7.Location = new System.Drawing.Point(1401, 23);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(78, 67);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox7.TabIndex = 24;
            this.pictureBox7.TabStop = false;
            // 
            // lbl_Profile_Information
            // 
            this.lbl_Profile_Information.AutoSize = true;
            this.lbl_Profile_Information.Font = new System.Drawing.Font("Times New Roman", 36F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Profile_Information.ForeColor = System.Drawing.Color.Navy;
            this.lbl_Profile_Information.Location = new System.Drawing.Point(481, 23);
            this.lbl_Profile_Information.Name = "lbl_Profile_Information";
            this.lbl_Profile_Information.Size = new System.Drawing.Size(519, 67);
            this.lbl_Profile_Information.TabIndex = 0;
            this.lbl_Profile_Information.Text = "Profile Information";
            // 
            // pb_profile
            // 
            this.pb_profile.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.pb_profile.Location = new System.Drawing.Point(4, 122);
            this.pb_profile.Name = "pb_profile";
            this.pb_profile.Size = new System.Drawing.Size(166, 163);
            this.pb_profile.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pb_profile.TabIndex = 25;
            this.pb_profile.TabStop = false;
            // 
            // btn_Search
            // 
            this.btn_Search.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btn_Search.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Search.Location = new System.Drawing.Point(560, 134);
            this.btn_Search.Name = "btn_Search";
            this.btn_Search.Size = new System.Drawing.Size(145, 36);
            this.btn_Search.TabIndex = 84;
            this.btn_Search.Text = "Search";
            this.btn_Search.UseVisualStyleBackColor = false;
            // 
            // tb_ID
            // 
            this.tb_ID.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_ID.Location = new System.Drawing.Point(311, 134);
            this.tb_ID.Name = "tb_ID";
            this.tb_ID.Size = new System.Drawing.Size(231, 36);
            this.tb_ID.TabIndex = 83;
            // 
            // lbl_Profile_ID
            // 
            this.lbl_Profile_ID.AutoSize = true;
            this.lbl_Profile_ID.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Profile_ID.Location = new System.Drawing.Point(194, 141);
            this.lbl_Profile_ID.Name = "lbl_Profile_ID";
            this.lbl_Profile_ID.Size = new System.Drawing.Size(111, 29);
            this.lbl_Profile_ID.TabIndex = 82;
            this.lbl_Profile_ID.Text = "Profile ID";
            // 
            // tb_Mobile_No
            // 
            this.tb_Mobile_No.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Mobile_No.Location = new System.Drawing.Point(561, 82);
            this.tb_Mobile_No.Name = "tb_Mobile_No";
            this.tb_Mobile_No.Size = new System.Drawing.Size(229, 32);
            this.tb_Mobile_No.TabIndex = 89;
            // 
            // lbl_Religion
            // 
            this.lbl_Religion.AutoSize = true;
            this.lbl_Religion.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Religion.ForeColor = System.Drawing.Color.Black;
            this.lbl_Religion.Location = new System.Drawing.Point(832, 86);
            this.lbl_Religion.Name = "lbl_Religion";
            this.lbl_Religion.Size = new System.Drawing.Size(90, 26);
            this.lbl_Religion.TabIndex = 96;
            this.lbl_Religion.Text = "Religion";
            // 
            // lbl_Mobile_No
            // 
            this.lbl_Mobile_No.AutoSize = true;
            this.lbl_Mobile_No.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Mobile_No.ForeColor = System.Drawing.Color.Black;
            this.lbl_Mobile_No.Location = new System.Drawing.Point(415, 88);
            this.lbl_Mobile_No.Name = "lbl_Mobile_No";
            this.lbl_Mobile_No.Size = new System.Drawing.Size(117, 26);
            this.lbl_Mobile_No.TabIndex = 95;
            this.lbl_Mobile_No.Text = "Mobile No.";
            // 
            // dtp_DOB
            // 
            this.dtp_DOB.CalendarFont = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtp_DOB.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtp_DOB.Location = new System.Drawing.Point(149, 80);
            this.dtp_DOB.Name = "dtp_DOB";
            this.dtp_DOB.Size = new System.Drawing.Size(243, 32);
            this.dtp_DOB.TabIndex = 88;
            // 
            // lbl_DOB
            // 
            this.lbl_DOB.AutoSize = true;
            this.lbl_DOB.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_DOB.ForeColor = System.Drawing.Color.Black;
            this.lbl_DOB.Location = new System.Drawing.Point(3, 86);
            this.lbl_DOB.Name = "lbl_DOB";
            this.lbl_DOB.Size = new System.Drawing.Size(59, 26);
            this.lbl_DOB.TabIndex = 94;
            this.lbl_DOB.Text = "DOB";
            // 
            // tb_Gender
            // 
            this.tb_Gender.Font = new System.Drawing.Font("Times New Roman", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Gender.Location = new System.Drawing.Point(978, 32);
            this.tb_Gender.Name = "tb_Gender";
            this.tb_Gender.Size = new System.Drawing.Size(229, 32);
            this.tb_Gender.TabIndex = 87;
            // 
            // lbl_Gender
            // 
            this.lbl_Gender.AutoSize = true;
            this.lbl_Gender.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Gender.ForeColor = System.Drawing.Color.Black;
            this.lbl_Gender.Location = new System.Drawing.Point(832, 38);
            this.lbl_Gender.Name = "lbl_Gender";
            this.lbl_Gender.Size = new System.Drawing.Size(80, 26);
            this.lbl_Gender.TabIndex = 93;
            this.lbl_Gender.Text = "Gender";
            // 
            // tb_Last_Name
            // 
            this.tb_Last_Name.Font = new System.Drawing.Font("Times New Roman", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Last_Name.Location = new System.Drawing.Point(561, 35);
            this.tb_Last_Name.Name = "tb_Last_Name";
            this.tb_Last_Name.Size = new System.Drawing.Size(229, 32);
            this.tb_Last_Name.TabIndex = 86;
            // 
            // lbl_Last_Name
            // 
            this.lbl_Last_Name.AutoSize = true;
            this.lbl_Last_Name.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Last_Name.ForeColor = System.Drawing.Color.Black;
            this.lbl_Last_Name.Location = new System.Drawing.Point(416, 38);
            this.lbl_Last_Name.Name = "lbl_Last_Name";
            this.lbl_Last_Name.Size = new System.Drawing.Size(110, 26);
            this.lbl_Last_Name.TabIndex = 92;
            this.lbl_Last_Name.Text = "Last Name";
            // 
            // tb_First_Name
            // 
            this.tb_First_Name.Font = new System.Drawing.Font("Times New Roman", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_First_Name.Location = new System.Drawing.Point(149, 32);
            this.tb_First_Name.Name = "tb_First_Name";
            this.tb_First_Name.Size = new System.Drawing.Size(229, 32);
            this.tb_First_Name.TabIndex = 85;
            // 
            // lbl_First_Name
            // 
            this.lbl_First_Name.AutoSize = true;
            this.lbl_First_Name.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_First_Name.ForeColor = System.Drawing.Color.Black;
            this.lbl_First_Name.Location = new System.Drawing.Point(3, 38);
            this.lbl_First_Name.Name = "lbl_First_Name";
            this.lbl_First_Name.Size = new System.Drawing.Size(114, 26);
            this.lbl_First_Name.TabIndex = 91;
            this.lbl_First_Name.Text = "First Name";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.tb_Religion);
            this.groupBox1.Controls.Add(this.tb_First_Name);
            this.groupBox1.Controls.Add(this.lbl_First_Name);
            this.groupBox1.Controls.Add(this.tb_Mobile_No);
            this.groupBox1.Controls.Add(this.dtp_DOB);
            this.groupBox1.Controls.Add(this.lbl_Religion);
            this.groupBox1.Controls.Add(this.lbl_Last_Name);
            this.groupBox1.Controls.Add(this.lbl_Mobile_No);
            this.groupBox1.Controls.Add(this.tb_Last_Name);
            this.groupBox1.Controls.Add(this.lbl_Gender);
            this.groupBox1.Controls.Add(this.lbl_DOB);
            this.groupBox1.Controls.Add(this.tb_Gender);
            this.groupBox1.Location = new System.Drawing.Point(199, 192);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1280, 130);
            this.groupBox1.TabIndex = 97;
            this.groupBox1.TabStop = false;
            // 
            // tb_Religion
            // 
            this.tb_Religion.Font = new System.Drawing.Font("Times New Roman", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Religion.Location = new System.Drawing.Point(978, 82);
            this.tb_Religion.Name = "tb_Religion";
            this.tb_Religion.Size = new System.Drawing.Size(229, 32);
            this.tb_Religion.TabIndex = 97;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.tb_Highest_Education);
            this.groupBox2.Controls.Add(this.tb_Complexion);
            this.groupBox2.Controls.Add(this.tb_Body_Type);
            this.groupBox2.Controls.Add(this.tb_Residing_City);
            this.groupBox2.Controls.Add(this.tb_Residing_State);
            this.groupBox2.Controls.Add(this.lbl_Highest_Education);
            this.groupBox2.Controls.Add(this.tb_Weight);
            this.groupBox2.Controls.Add(this.tb_Height);
            this.groupBox2.Controls.Add(this.lbl_Complexion);
            this.groupBox2.Controls.Add(this.lbl_Body_Type);
            this.groupBox2.Controls.Add(this.lbl_Weight);
            this.groupBox2.Controls.Add(this.lbl_Height);
            this.groupBox2.Controls.Add(this.tb_Address);
            this.groupBox2.Controls.Add(this.lbl_Address);
            this.groupBox2.Controls.Add(this.tb_Gothra);
            this.groupBox2.Controls.Add(this.tb_Sub_Caste);
            this.groupBox2.Controls.Add(this.tb_Caste);
            this.groupBox2.Controls.Add(this.lbl_Residing_State);
            this.groupBox2.Controls.Add(this.lbl_Gothra);
            this.groupBox2.Controls.Add(this.lbl_Sub_Caste);
            this.groupBox2.Controls.Add(this.lbl_Caste);
            this.groupBox2.Controls.Add(this.lbl_Residing_City);
            this.groupBox2.Location = new System.Drawing.Point(4, 328);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(1478, 182);
            this.groupBox2.TabIndex = 98;
            this.groupBox2.TabStop = false;
            // 
            // tb_Highest_Education
            // 
            this.tb_Highest_Education.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Highest_Education.Location = new System.Drawing.Point(1002, 128);
            this.tb_Highest_Education.Name = "tb_Highest_Education";
            this.tb_Highest_Education.Size = new System.Drawing.Size(374, 36);
            this.tb_Highest_Education.TabIndex = 105;
            // 
            // tb_Complexion
            // 
            this.tb_Complexion.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Complexion.Location = new System.Drawing.Point(597, 128);
            this.tb_Complexion.Name = "tb_Complexion";
            this.tb_Complexion.Size = new System.Drawing.Size(167, 36);
            this.tb_Complexion.TabIndex = 104;
            // 
            // tb_Body_Type
            // 
            this.tb_Body_Type.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Body_Type.Location = new System.Drawing.Point(191, 133);
            this.tb_Body_Type.Name = "tb_Body_Type";
            this.tb_Body_Type.Size = new System.Drawing.Size(167, 36);
            this.tb_Body_Type.TabIndex = 103;
            // 
            // tb_Residing_City
            // 
            this.tb_Residing_City.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Residing_City.Location = new System.Drawing.Point(597, 76);
            this.tb_Residing_City.Name = "tb_Residing_City";
            this.tb_Residing_City.Size = new System.Drawing.Size(167, 36);
            this.tb_Residing_City.TabIndex = 102;
            // 
            // tb_Residing_State
            // 
            this.tb_Residing_State.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Residing_State.Location = new System.Drawing.Point(191, 76);
            this.tb_Residing_State.Name = "tb_Residing_State";
            this.tb_Residing_State.Size = new System.Drawing.Size(167, 36);
            this.tb_Residing_State.TabIndex = 101;
            // 
            // lbl_Highest_Education
            // 
            this.lbl_Highest_Education.AutoSize = true;
            this.lbl_Highest_Education.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Highest_Education.Location = new System.Drawing.Point(798, 135);
            this.lbl_Highest_Education.Name = "lbl_Highest_Education";
            this.lbl_Highest_Education.Size = new System.Drawing.Size(198, 29);
            this.lbl_Highest_Education.TabIndex = 100;
            this.lbl_Highest_Education.Text = "Highest Education";
            // 
            // tb_Weight
            // 
            this.tb_Weight.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Weight.Location = new System.Drawing.Point(1247, 71);
            this.tb_Weight.Name = "tb_Weight";
            this.tb_Weight.Size = new System.Drawing.Size(219, 36);
            this.tb_Weight.TabIndex = 66;
            // 
            // tb_Height
            // 
            this.tb_Height.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Height.Location = new System.Drawing.Point(910, 72);
            this.tb_Height.Name = "tb_Height";
            this.tb_Height.Size = new System.Drawing.Size(167, 36);
            this.tb_Height.TabIndex = 64;
            // 
            // lbl_Complexion
            // 
            this.lbl_Complexion.AutoSize = true;
            this.lbl_Complexion.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Complexion.Location = new System.Drawing.Point(423, 135);
            this.lbl_Complexion.Name = "lbl_Complexion";
            this.lbl_Complexion.Size = new System.Drawing.Size(138, 29);
            this.lbl_Complexion.TabIndex = 68;
            this.lbl_Complexion.Text = "Complexion";
            // 
            // lbl_Body_Type
            // 
            this.lbl_Body_Type.AutoSize = true;
            this.lbl_Body_Type.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Body_Type.Location = new System.Drawing.Point(17, 135);
            this.lbl_Body_Type.Name = "lbl_Body_Type";
            this.lbl_Body_Type.Size = new System.Drawing.Size(123, 29);
            this.lbl_Body_Type.TabIndex = 67;
            this.lbl_Body_Type.Text = "Body Type";
            // 
            // lbl_Weight
            // 
            this.lbl_Weight.AutoSize = true;
            this.lbl_Weight.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Weight.Location = new System.Drawing.Point(1125, 74);
            this.lbl_Weight.Name = "lbl_Weight";
            this.lbl_Weight.Size = new System.Drawing.Size(84, 29);
            this.lbl_Weight.TabIndex = 65;
            this.lbl_Weight.Text = "Weight";
            // 
            // lbl_Height
            // 
            this.lbl_Height.AutoSize = true;
            this.lbl_Height.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Height.Location = new System.Drawing.Point(798, 79);
            this.lbl_Height.Name = "lbl_Height";
            this.lbl_Height.Size = new System.Drawing.Size(80, 29);
            this.lbl_Height.TabIndex = 63;
            this.lbl_Height.Text = "Height";
            // 
            // tb_Address
            // 
            this.tb_Address.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Address.Location = new System.Drawing.Point(1247, 15);
            this.tb_Address.Multiline = true;
            this.tb_Address.Name = "tb_Address";
            this.tb_Address.Size = new System.Drawing.Size(219, 37);
            this.tb_Address.TabIndex = 62;
            // 
            // lbl_Address
            // 
            this.lbl_Address.AutoSize = true;
            this.lbl_Address.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Address.Location = new System.Drawing.Point(1125, 18);
            this.lbl_Address.Name = "lbl_Address";
            this.lbl_Address.Size = new System.Drawing.Size(96, 29);
            this.lbl_Address.TabIndex = 61;
            this.lbl_Address.Text = "Address";
            // 
            // tb_Gothra
            // 
            this.tb_Gothra.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Gothra.Location = new System.Drawing.Point(910, 15);
            this.tb_Gothra.Name = "tb_Gothra";
            this.tb_Gothra.Size = new System.Drawing.Size(167, 36);
            this.tb_Gothra.TabIndex = 54;
            // 
            // tb_Sub_Caste
            // 
            this.tb_Sub_Caste.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Sub_Caste.Location = new System.Drawing.Point(597, 15);
            this.tb_Sub_Caste.Name = "tb_Sub_Caste";
            this.tb_Sub_Caste.Size = new System.Drawing.Size(167, 36);
            this.tb_Sub_Caste.TabIndex = 52;
            // 
            // tb_Caste
            // 
            this.tb_Caste.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Caste.Location = new System.Drawing.Point(191, 11);
            this.tb_Caste.Name = "tb_Caste";
            this.tb_Caste.Size = new System.Drawing.Size(167, 36);
            this.tb_Caste.TabIndex = 51;
            // 
            // lbl_Residing_State
            // 
            this.lbl_Residing_State.AutoSize = true;
            this.lbl_Residing_State.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Residing_State.Location = new System.Drawing.Point(17, 79);
            this.lbl_Residing_State.Name = "lbl_Residing_State";
            this.lbl_Residing_State.Size = new System.Drawing.Size(157, 29);
            this.lbl_Residing_State.TabIndex = 58;
            this.lbl_Residing_State.Text = "Residing State";
            // 
            // lbl_Gothra
            // 
            this.lbl_Gothra.AutoSize = true;
            this.lbl_Gothra.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Gothra.Location = new System.Drawing.Point(794, 18);
            this.lbl_Gothra.Name = "lbl_Gothra";
            this.lbl_Gothra.Size = new System.Drawing.Size(83, 29);
            this.lbl_Gothra.TabIndex = 57;
            this.lbl_Gothra.Text = "Gothra";
            // 
            // lbl_Sub_Caste
            // 
            this.lbl_Sub_Caste.AutoSize = true;
            this.lbl_Sub_Caste.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Sub_Caste.Location = new System.Drawing.Point(423, 17);
            this.lbl_Sub_Caste.Name = "lbl_Sub_Caste";
            this.lbl_Sub_Caste.Size = new System.Drawing.Size(115, 29);
            this.lbl_Sub_Caste.TabIndex = 55;
            this.lbl_Sub_Caste.Text = "Sub Caste";
            // 
            // lbl_Caste
            // 
            this.lbl_Caste.AutoSize = true;
            this.lbl_Caste.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Caste.Location = new System.Drawing.Point(17, 18);
            this.lbl_Caste.Name = "lbl_Caste";
            this.lbl_Caste.Size = new System.Drawing.Size(69, 29);
            this.lbl_Caste.TabIndex = 53;
            this.lbl_Caste.Text = "Caste";
            // 
            // lbl_Residing_City
            // 
            this.lbl_Residing_City.AutoSize = true;
            this.lbl_Residing_City.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Residing_City.Location = new System.Drawing.Point(423, 79);
            this.lbl_Residing_City.Name = "lbl_Residing_City";
            this.lbl_Residing_City.Size = new System.Drawing.Size(150, 29);
            this.lbl_Residing_City.TabIndex = 59;
            this.lbl_Residing_City.Text = "Residing City";
            // 
            // lbl_Marital_Status
            // 
            this.lbl_Marital_Status.AutoSize = true;
            this.lbl_Marital_Status.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Marital_Status.Location = new System.Drawing.Point(755, 141);
            this.lbl_Marital_Status.Name = "lbl_Marital_Status";
            this.lbl_Marital_Status.Size = new System.Drawing.Size(152, 29);
            this.lbl_Marital_Status.TabIndex = 65;
            this.lbl_Marital_Status.Text = "Marital Status";
            // 
            // tb_Marital_Status
            // 
            this.tb_Marital_Status.Font = new System.Drawing.Font("Times New Roman", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Marital_Status.Location = new System.Drawing.Point(940, 141);
            this.tb_Marital_Status.Name = "tb_Marital_Status";
            this.tb_Marital_Status.Size = new System.Drawing.Size(229, 32);
            this.tb_Marital_Status.TabIndex = 97;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.tb_Family_Values);
            this.groupBox3.Controls.Add(this.tb_Family_Type);
            this.groupBox3.Controls.Add(this.tb_Family_Status);
            this.groupBox3.Controls.Add(this.tb_Monthly_Income);
            this.groupBox3.Controls.Add(this.tb_Employed_In);
            this.groupBox3.Controls.Add(this.lbl_Family_Values);
            this.groupBox3.Controls.Add(this.lbl_Family_Type);
            this.groupBox3.Controls.Add(this.lbl_Family_Status);
            this.groupBox3.Controls.Add(this.tb_Rassi_Moon_Sign);
            this.groupBox3.Controls.Add(this.lbl_Rassi_Moon_Sign);
            this.groupBox3.Controls.Add(this.lbl_Employed_In);
            this.groupBox3.Controls.Add(this.lbl_Monthly_Income);
            this.groupBox3.Location = new System.Drawing.Point(12, 516);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(1458, 174);
            this.groupBox3.TabIndex = 99;
            this.groupBox3.TabStop = false;
            // 
            // tb_Family_Values
            // 
            this.tb_Family_Values.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Family_Values.Location = new System.Drawing.Point(1193, 87);
            this.tb_Family_Values.Name = "tb_Family_Values";
            this.tb_Family_Values.Size = new System.Drawing.Size(246, 36);
            this.tb_Family_Values.TabIndex = 56;
            // 
            // tb_Family_Type
            // 
            this.tb_Family_Type.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Family_Type.Location = new System.Drawing.Point(670, 83);
            this.tb_Family_Type.Name = "tb_Family_Type";
            this.tb_Family_Type.Size = new System.Drawing.Size(252, 36);
            this.tb_Family_Type.TabIndex = 55;
            // 
            // tb_Family_Status
            // 
            this.tb_Family_Status.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Family_Status.Location = new System.Drawing.Point(183, 83);
            this.tb_Family_Status.Name = "tb_Family_Status";
            this.tb_Family_Status.Size = new System.Drawing.Size(252, 36);
            this.tb_Family_Status.TabIndex = 54;
            // 
            // tb_Monthly_Income
            // 
            this.tb_Monthly_Income.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Monthly_Income.Location = new System.Drawing.Point(670, 23);
            this.tb_Monthly_Income.Name = "tb_Monthly_Income";
            this.tb_Monthly_Income.Size = new System.Drawing.Size(252, 36);
            this.tb_Monthly_Income.TabIndex = 53;
            // 
            // tb_Employed_In
            // 
            this.tb_Employed_In.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Employed_In.Location = new System.Drawing.Point(183, 20);
            this.tb_Employed_In.Name = "tb_Employed_In";
            this.tb_Employed_In.Size = new System.Drawing.Size(252, 36);
            this.tb_Employed_In.TabIndex = 52;
            // 
            // lbl_Family_Values
            // 
            this.lbl_Family_Values.AutoSize = true;
            this.lbl_Family_Values.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Family_Values.Location = new System.Drawing.Point(1022, 93);
            this.lbl_Family_Values.Name = "lbl_Family_Values";
            this.lbl_Family_Values.Size = new System.Drawing.Size(155, 29);
            this.lbl_Family_Values.TabIndex = 25;
            this.lbl_Family_Values.Text = "Family Values";
            // 
            // lbl_Family_Type
            // 
            this.lbl_Family_Type.AutoSize = true;
            this.lbl_Family_Type.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Family_Type.Location = new System.Drawing.Point(497, 90);
            this.lbl_Family_Type.Name = "lbl_Family_Type";
            this.lbl_Family_Type.Size = new System.Drawing.Size(138, 29);
            this.lbl_Family_Type.TabIndex = 24;
            this.lbl_Family_Type.Text = "Family Type";
            // 
            // lbl_Family_Status
            // 
            this.lbl_Family_Status.AutoSize = true;
            this.lbl_Family_Status.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Family_Status.Location = new System.Drawing.Point(9, 81);
            this.lbl_Family_Status.Name = "lbl_Family_Status";
            this.lbl_Family_Status.Size = new System.Drawing.Size(151, 29);
            this.lbl_Family_Status.TabIndex = 23;
            this.lbl_Family_Status.Text = "Family Status";
            // 
            // tb_Rassi_Moon_Sign
            // 
            this.tb_Rassi_Moon_Sign.Font = new System.Drawing.Font("Times New Roman", 15F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Rassi_Moon_Sign.Location = new System.Drawing.Point(1193, 23);
            this.tb_Rassi_Moon_Sign.Name = "tb_Rassi_Moon_Sign";
            this.tb_Rassi_Moon_Sign.Size = new System.Drawing.Size(246, 36);
            this.tb_Rassi_Moon_Sign.TabIndex = 22;
            // 
            // lbl_Rassi_Moon_Sign
            // 
            this.lbl_Rassi_Moon_Sign.AutoSize = true;
            this.lbl_Rassi_Moon_Sign.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Rassi_Moon_Sign.Location = new System.Drawing.Point(983, 23);
            this.lbl_Rassi_Moon_Sign.Name = "lbl_Rassi_Moon_Sign";
            this.lbl_Rassi_Moon_Sign.Size = new System.Drawing.Size(198, 29);
            this.lbl_Rassi_Moon_Sign.TabIndex = 21;
            this.lbl_Rassi_Moon_Sign.Text = "Rassi / Moon Sign";
            // 
            // lbl_Employed_In
            // 
            this.lbl_Employed_In.AutoSize = true;
            this.lbl_Employed_In.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Employed_In.Location = new System.Drawing.Point(9, 23);
            this.lbl_Employed_In.Name = "lbl_Employed_In";
            this.lbl_Employed_In.Size = new System.Drawing.Size(144, 29);
            this.lbl_Employed_In.TabIndex = 19;
            this.lbl_Employed_In.Text = "Employed In";
            // 
            // lbl_Monthly_Income
            // 
            this.lbl_Monthly_Income.AutoSize = true;
            this.lbl_Monthly_Income.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Monthly_Income.Location = new System.Drawing.Point(476, 23);
            this.lbl_Monthly_Income.Name = "lbl_Monthly_Income";
            this.lbl_Monthly_Income.Size = new System.Drawing.Size(182, 29);
            this.lbl_Monthly_Income.TabIndex = 20;
            this.lbl_Monthly_Income.Text = "Monthly Income";
            // 
            // frm_Profile_Information
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ClientSize = new System.Drawing.Size(1482, 753);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.tb_Marital_Status);
            this.Controls.Add(this.lbl_Marital_Status);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btn_Search);
            this.Controls.Add(this.tb_ID);
            this.Controls.Add(this.lbl_Profile_ID);
            this.Controls.Add(this.pb_profile);
            this.Controls.Add(this.panel1);
            this.Name = "frm_Profile_Information";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.frm_Profile_Information_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_profile)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.Label lbl_Profile_Information;
        private System.Windows.Forms.PictureBox pb_profile;
        private System.Windows.Forms.Button btn_Search;
        private System.Windows.Forms.TextBox tb_ID;
        private System.Windows.Forms.Label lbl_Profile_ID;
        private System.Windows.Forms.TextBox tb_Mobile_No;
        private System.Windows.Forms.Label lbl_Religion;
        private System.Windows.Forms.Label lbl_Mobile_No;
        private System.Windows.Forms.DateTimePicker dtp_DOB;
        private System.Windows.Forms.Label lbl_DOB;
        private System.Windows.Forms.TextBox tb_Gender;
        private System.Windows.Forms.Label lbl_Gender;
        private System.Windows.Forms.TextBox tb_Last_Name;
        private System.Windows.Forms.Label lbl_Last_Name;
        private System.Windows.Forms.TextBox tb_First_Name;
        private System.Windows.Forms.Label lbl_First_Name;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox tb_Address;
        private System.Windows.Forms.Label lbl_Address;
        private System.Windows.Forms.TextBox tb_Gothra;
        private System.Windows.Forms.TextBox tb_Sub_Caste;
        private System.Windows.Forms.TextBox tb_Caste;
        private System.Windows.Forms.Label lbl_Residing_State;
        private System.Windows.Forms.Label lbl_Gothra;
        private System.Windows.Forms.Label lbl_Sub_Caste;
        private System.Windows.Forms.Label lbl_Caste;
        private System.Windows.Forms.Label lbl_Residing_City;
        private System.Windows.Forms.Label lbl_Marital_Status;
        private System.Windows.Forms.TextBox tb_Marital_Status;
        private System.Windows.Forms.TextBox tb_Weight;
        private System.Windows.Forms.TextBox tb_Height;
        private System.Windows.Forms.Label lbl_Complexion;
        private System.Windows.Forms.Label lbl_Body_Type;
        private System.Windows.Forms.Label lbl_Weight;
        private System.Windows.Forms.Label lbl_Height;
        private System.Windows.Forms.Label lbl_Highest_Education;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label lbl_Employed_In;
        private System.Windows.Forms.Label lbl_Monthly_Income;
        private System.Windows.Forms.TextBox tb_Rassi_Moon_Sign;
        private System.Windows.Forms.Label lbl_Rassi_Moon_Sign;
        private System.Windows.Forms.Label lbl_Family_Values;
        private System.Windows.Forms.Label lbl_Family_Type;
        private System.Windows.Forms.Label lbl_Family_Status;
        private System.Windows.Forms.TextBox tb_Religion;
        private System.Windows.Forms.TextBox tb_Highest_Education;
        private System.Windows.Forms.TextBox tb_Complexion;
        private System.Windows.Forms.TextBox tb_Body_Type;
        private System.Windows.Forms.TextBox tb_Residing_City;
        private System.Windows.Forms.TextBox tb_Residing_State;
        private System.Windows.Forms.TextBox tb_Family_Values;
        private System.Windows.Forms.TextBox tb_Family_Type;
        private System.Windows.Forms.TextBox tb_Family_Status;
        private System.Windows.Forms.TextBox tb_Monthly_Income;
        private System.Windows.Forms.TextBox tb_Employed_In;
    }
}