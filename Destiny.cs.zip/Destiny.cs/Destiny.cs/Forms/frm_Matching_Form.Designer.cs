﻿namespace Destiny.cs
{
    partial class frm_Matching_Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel2 = new System.Windows.Forms.Panel();
            this.lbl_matching_Slogen = new System.Windows.Forms.Label();
            this.lbl_Find_Your_Compader = new System.Windows.Forms.Label();
            this.lbl_Marital_Status = new System.Windows.Forms.Label();
            this.lbl_Caste = new System.Windows.Forms.Label();
            this.lbl_Sub_Caste = new System.Windows.Forms.Label();
            this.cmb_Residing_City = new System.Windows.Forms.ComboBox();
            this.lbl_Residing_City = new System.Windows.Forms.Label();
            this.cmb_Complexion = new System.Windows.Forms.ComboBox();
            this.lbl_Complexion = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.cmb_Employed_In = new System.Windows.Forms.ComboBox();
            this.lbl_Highest_Education = new System.Windows.Forms.Label();
            this.cmb_Highest_Educatiion = new System.Windows.Forms.ComboBox();
            this.lbl_Occupation = new System.Windows.Forms.Label();
            this.cmb_Occupation = new System.Windows.Forms.ComboBox();
            this.lbl_Employed_In = new System.Windows.Forms.Label();
            this.lbl_Monthly_Income = new System.Windows.Forms.Label();
            this.cmb_Monthly_Income = new System.Windows.Forms.ComboBox();
            this.cmb_Family_Type = new System.Windows.Forms.ComboBox();
            this.lbl_Family_Type = new System.Windows.Forms.Label();
            this.cmb_Marital_Status = new System.Windows.Forms.ComboBox();
            this.cmb_Caste = new System.Windows.Forms.ComboBox();
            this.cmb_Sub_Caste = new System.Windows.Forms.ComboBox();
            this.cmb_Food = new System.Windows.Forms.ComboBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.lbl_Looking_For = new System.Windows.Forms.Label();
            this.btn_Search = new System.Windows.Forms.Button();
            this.cmb_Looking_for = new System.Windows.Forms.ComboBox();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel2.Controls.Add(this.lbl_matching_Slogen);
            this.panel2.Controls.Add(this.lbl_Find_Your_Compader);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1482, 110);
            this.panel2.TabIndex = 19;
            // 
            // lbl_matching_Slogen
            // 
            this.lbl_matching_Slogen.AutoSize = true;
            this.lbl_matching_Slogen.Font = new System.Drawing.Font("Times New Roman", 15F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_matching_Slogen.ForeColor = System.Drawing.Color.Navy;
            this.lbl_matching_Slogen.Location = new System.Drawing.Point(496, 66);
            this.lbl_matching_Slogen.Name = "lbl_matching_Slogen";
            this.lbl_matching_Slogen.Size = new System.Drawing.Size(474, 30);
            this.lbl_matching_Slogen.TabIndex = 1;
            this.lbl_matching_Slogen.Text = "It\'s Better To Hold Onto Each Other In Life.";
            // 
            // lbl_Find_Your_Compader
            // 
            this.lbl_Find_Your_Compader.AutoSize = true;
            this.lbl_Find_Your_Compader.Font = new System.Drawing.Font("Times New Roman", 36F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Find_Your_Compader.ForeColor = System.Drawing.Color.Navy;
            this.lbl_Find_Your_Compader.Location = new System.Drawing.Point(439, 2);
            this.lbl_Find_Your_Compader.Name = "lbl_Find_Your_Compader";
            this.lbl_Find_Your_Compader.Size = new System.Drawing.Size(623, 67);
            this.lbl_Find_Your_Compader.TabIndex = 0;
            this.lbl_Find_Your_Compader.Text = "Find Your Compader.....";
            // 
            // lbl_Marital_Status
            // 
            this.lbl_Marital_Status.AutoSize = true;
            this.lbl_Marital_Status.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Marital_Status.Location = new System.Drawing.Point(12, 189);
            this.lbl_Marital_Status.Name = "lbl_Marital_Status";
            this.lbl_Marital_Status.Size = new System.Drawing.Size(158, 29);
            this.lbl_Marital_Status.TabIndex = 36;
            this.lbl_Marital_Status.Text = "Marital Status:";
            // 
            // lbl_Caste
            // 
            this.lbl_Caste.AutoSize = true;
            this.lbl_Caste.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Caste.Location = new System.Drawing.Point(439, 188);
            this.lbl_Caste.Name = "lbl_Caste";
            this.lbl_Caste.Size = new System.Drawing.Size(69, 29);
            this.lbl_Caste.TabIndex = 42;
            this.lbl_Caste.Text = "Caste";
            // 
            // lbl_Sub_Caste
            // 
            this.lbl_Sub_Caste.AutoSize = true;
            this.lbl_Sub_Caste.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Sub_Caste.Location = new System.Drawing.Point(719, 189);
            this.lbl_Sub_Caste.Name = "lbl_Sub_Caste";
            this.lbl_Sub_Caste.Size = new System.Drawing.Size(115, 29);
            this.lbl_Sub_Caste.TabIndex = 44;
            this.lbl_Sub_Caste.Text = "Sub Caste";
            // 
            // cmb_Residing_City
            // 
            this.cmb_Residing_City.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_Residing_City.FormattingEnabled = true;
            this.cmb_Residing_City.Items.AddRange(new object[] {
            "Mumbai ",
            "Pune ",
            "Nagpur",
            "Nashik",
            "Thane",
            "Sambhaji Nagar",
            "Solapur",
            "Nashik",
            "Jalgaon",
            "Amravati",
            "Nanded",
            "Kolhapur",
            "Akola",
            "Sangli",
            "Latur",
            "Raigad ",
            "Satara",
            "Beed",
            "Yavatmal",
            "Nagpur",
            "Gondia",
            "Solapur",
            "Amravati",
            "Osmanabad",
            "Nandurbar",
            "Wardha",
            "Dhule",
            "Ahmednagar",
            "Chandrapur",
            "Parbhani",
            "Jalna",
            "Neutral"});
            this.cmb_Residing_City.Location = new System.Drawing.Point(1236, 189);
            this.cmb_Residing_City.Name = "cmb_Residing_City";
            this.cmb_Residing_City.Size = new System.Drawing.Size(234, 37);
            this.cmb_Residing_City.TabIndex = 47;
            // 
            // lbl_Residing_City
            // 
            this.lbl_Residing_City.AutoSize = true;
            this.lbl_Residing_City.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Residing_City.Location = new System.Drawing.Point(1081, 189);
            this.lbl_Residing_City.Name = "lbl_Residing_City";
            this.lbl_Residing_City.Size = new System.Drawing.Size(150, 29);
            this.lbl_Residing_City.TabIndex = 46;
            this.lbl_Residing_City.Text = "Residing City";
            // 
            // cmb_Complexion
            // 
            this.cmb_Complexion.Font = new System.Drawing.Font("Times New Roman", 15F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_Complexion.FormattingEnabled = true;
            this.cmb_Complexion.Items.AddRange(new object[] {
            "Fair",
            "Over Fair",
            "Wheatish",
            "Wheatish Brown",
            "Neutral"});
            this.cmb_Complexion.Location = new System.Drawing.Point(176, 233);
            this.cmb_Complexion.Name = "cmb_Complexion";
            this.cmb_Complexion.Size = new System.Drawing.Size(231, 38);
            this.cmb_Complexion.TabIndex = 49;
            // 
            // lbl_Complexion
            // 
            this.lbl_Complexion.AutoSize = true;
            this.lbl_Complexion.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Complexion.Location = new System.Drawing.Point(12, 237);
            this.lbl_Complexion.Name = "lbl_Complexion";
            this.lbl_Complexion.Size = new System.Drawing.Size(138, 29);
            this.lbl_Complexion.TabIndex = 48;
            this.lbl_Complexion.Text = "Complexion";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(439, 236);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(66, 29);
            this.label3.TabIndex = 61;
            this.label3.Text = "Food";
            // 
            // cmb_Employed_In
            // 
            this.cmb_Employed_In.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_Employed_In.FormattingEnabled = true;
            this.cmb_Employed_In.Items.AddRange(new object[] {
            "Government",
            "Private",
            "Business",
            "Defence",
            "Self Employed",
            "Neutral"});
            this.cmb_Employed_In.Location = new System.Drawing.Point(588, 287);
            this.cmb_Employed_In.Name = "cmb_Employed_In";
            this.cmb_Employed_In.Size = new System.Drawing.Size(246, 37);
            this.cmb_Employed_In.TabIndex = 64;
            // 
            // lbl_Highest_Education
            // 
            this.lbl_Highest_Education.AutoSize = true;
            this.lbl_Highest_Education.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Highest_Education.Location = new System.Drawing.Point(1026, 236);
            this.lbl_Highest_Education.Name = "lbl_Highest_Education";
            this.lbl_Highest_Education.Size = new System.Drawing.Size(198, 29);
            this.lbl_Highest_Education.TabIndex = 66;
            this.lbl_Highest_Education.Text = "Highest Education";
            // 
            // cmb_Highest_Educatiion
            // 
            this.cmb_Highest_Educatiion.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_Highest_Educatiion.FormattingEnabled = true;
            this.cmb_Highest_Educatiion.Items.AddRange(new object[] {
            "Bachelor of Applied Science (BAS)",
            "Bachelor of Architecture (B.Arch.)",
            "Bachelor of Arts (BA)",
            "Bachelor of Business Administration (BBA)",
            "Bachelor of Fine Arts (BFA)",
            "Bachelor of Science (BS)",
            "Master of Business Administration (MBA)",
            "Master of Education (M.Ed.)",
            "Master of Fine Arts (MFA)",
            "Master of Laws (LL.M.)",
            "Master of Public Administration (MPA)",
            "Master of Public Health (MPH)",
            "Master of Publishing (M.Pub.)",
            "Master of Science (MS)",
            "Master of Social Work (MSW)",
            "Doctor of Business Administration (DBA)",
            "Doctor of Dental Surgery (DDS)",
            "Doctor of Education (Ed.D.)",
            "Doctor of Medicine (MD)",
            "Doctor of Pharmacy (Pharm.D.)",
            "Doctor of Philosophy (Ph.D.)",
            "Doctor of Psychology (Psy.D.)",
            "Juris Doctor (JD)",
            "Neutral"});
            this.cmb_Highest_Educatiion.Location = new System.Drawing.Point(1236, 233);
            this.cmb_Highest_Educatiion.Name = "cmb_Highest_Educatiion";
            this.cmb_Highest_Educatiion.Size = new System.Drawing.Size(234, 37);
            this.cmb_Highest_Educatiion.TabIndex = 62;
            // 
            // lbl_Occupation
            // 
            this.lbl_Occupation.AutoSize = true;
            this.lbl_Occupation.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Occupation.Location = new System.Drawing.Point(12, 290);
            this.lbl_Occupation.Name = "lbl_Occupation";
            this.lbl_Occupation.Size = new System.Drawing.Size(129, 29);
            this.lbl_Occupation.TabIndex = 67;
            this.lbl_Occupation.Text = "Occupation";
            // 
            // cmb_Occupation
            // 
            this.cmb_Occupation.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_Occupation.FormattingEnabled = true;
            this.cmb_Occupation.Items.AddRange(new object[] {
            "Worker ",
            "Engineer ",
            "Architect ",
            "Technician ",
            "Teacher ",
            "Software Developer ",
            "Civil Engineer ",
            "Accountant ",
            "Social Worker ",
            "Mechanical Engineer ",
            "Electrical Enginner ",
            "Police Officer ",
            "Plumber ",
            "Adviser ",
            "Agriculture Enginner ",
            "Aeronautical Engineer ",
            "Lawyer  ",
            "Farmer",
            "Neutral"});
            this.cmb_Occupation.Location = new System.Drawing.Point(176, 282);
            this.cmb_Occupation.Name = "cmb_Occupation";
            this.cmb_Occupation.Size = new System.Drawing.Size(231, 37);
            this.cmb_Occupation.TabIndex = 63;
            // 
            // lbl_Employed_In
            // 
            this.lbl_Employed_In.AutoSize = true;
            this.lbl_Employed_In.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Employed_In.Location = new System.Drawing.Point(429, 290);
            this.lbl_Employed_In.Name = "lbl_Employed_In";
            this.lbl_Employed_In.Size = new System.Drawing.Size(144, 29);
            this.lbl_Employed_In.TabIndex = 68;
            this.lbl_Employed_In.Text = "Employed In";
            // 
            // lbl_Monthly_Income
            // 
            this.lbl_Monthly_Income.AutoSize = true;
            this.lbl_Monthly_Income.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Monthly_Income.Location = new System.Drawing.Point(861, 290);
            this.lbl_Monthly_Income.Name = "lbl_Monthly_Income";
            this.lbl_Monthly_Income.Size = new System.Drawing.Size(182, 29);
            this.lbl_Monthly_Income.TabIndex = 69;
            this.lbl_Monthly_Income.Text = "Monthly Income";
            // 
            // cmb_Monthly_Income
            // 
            this.cmb_Monthly_Income.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_Monthly_Income.FormattingEnabled = true;
            this.cmb_Monthly_Income.Items.AddRange(new object[] {
            "5000 - 10,000  ",
            "10,000 - 20,000 ",
            "20,000 - 30,000 ",
            "30,000 - 40,000 ",
            "40,000 - 50,000 ",
            "50,000 - 60,000 ",
            "60,000 - 70,000 ",
            "70,000 - 80,000 ",
            "80,000 - 90,000 ",
            "90,000 - 1,00,000",
            "Neutral"});
            this.cmb_Monthly_Income.Location = new System.Drawing.Point(1052, 287);
            this.cmb_Monthly_Income.Name = "cmb_Monthly_Income";
            this.cmb_Monthly_Income.Size = new System.Drawing.Size(258, 37);
            this.cmb_Monthly_Income.TabIndex = 65;
            // 
            // cmb_Family_Type
            // 
            this.cmb_Family_Type.Font = new System.Drawing.Font("Times New Roman", 15F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_Family_Type.FormattingEnabled = true;
            this.cmb_Family_Type.Items.AddRange(new object[] {
            "Joint",
            "Nuclear",
            "Neutral"});
            this.cmb_Family_Type.Location = new System.Drawing.Point(859, 233);
            this.cmb_Family_Type.Name = "cmb_Family_Type";
            this.cmb_Family_Type.Size = new System.Drawing.Size(155, 38);
            this.cmb_Family_Type.TabIndex = 71;
            // 
            // lbl_Family_Type
            // 
            this.lbl_Family_Type.AutoSize = true;
            this.lbl_Family_Type.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Family_Type.Location = new System.Drawing.Point(715, 237);
            this.lbl_Family_Type.Name = "lbl_Family_Type";
            this.lbl_Family_Type.Size = new System.Drawing.Size(138, 29);
            this.lbl_Family_Type.TabIndex = 70;
            this.lbl_Family_Type.Text = "Family Type";
            // 
            // cmb_Marital_Status
            // 
            this.cmb_Marital_Status.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb_Marital_Status.Font = new System.Drawing.Font("Times New Roman", 15F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_Marital_Status.FormattingEnabled = true;
            this.cmb_Marital_Status.Items.AddRange(new object[] {
            "Never Married",
            "Widow",
            "Divorced",
            "Awaiting Divorced",
            "Neutral"});
            this.cmb_Marital_Status.Location = new System.Drawing.Point(176, 180);
            this.cmb_Marital_Status.Name = "cmb_Marital_Status";
            this.cmb_Marital_Status.Size = new System.Drawing.Size(231, 38);
            this.cmb_Marital_Status.TabIndex = 72;
            // 
            // cmb_Caste
            // 
            this.cmb_Caste.Font = new System.Drawing.Font("Times New Roman", 15F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_Caste.FormattingEnabled = true;
            this.cmb_Caste.Items.AddRange(new object[] {
            "SC",
            "ST",
            "OBC",
            "SBC",
            "SEBC",
            "VJ",
            "NT-B",
            "NT-C",
            "NT-D",
            "Neutral"});
            this.cmb_Caste.Location = new System.Drawing.Point(514, 185);
            this.cmb_Caste.Name = "cmb_Caste";
            this.cmb_Caste.Size = new System.Drawing.Size(168, 38);
            this.cmb_Caste.TabIndex = 73;
            this.cmb_Caste.SelectedIndexChanged += new System.EventHandler(this.cmb_Caste_SelectedIndexChanged);
            // 
            // cmb_Sub_Caste
            // 
            this.cmb_Sub_Caste.Font = new System.Drawing.Font("Times New Roman", 15F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_Sub_Caste.FormattingEnabled = true;
            this.cmb_Sub_Caste.Items.AddRange(new object[] {
            "Kumbhar",
            "Lohar ",
            "Gujjar ",
            "Chambar ",
            "Aagri ",
            "Sonar ",
            "Kasar ",
            "Shimpi ",
            "Bhavsar ",
            "Sutar ",
            "Gurav",
            "Neutral"});
            this.cmb_Sub_Caste.Location = new System.Drawing.Point(859, 184);
            this.cmb_Sub_Caste.Name = "cmb_Sub_Caste";
            this.cmb_Sub_Caste.Size = new System.Drawing.Size(155, 38);
            this.cmb_Sub_Caste.TabIndex = 74;
            // 
            // cmb_Food
            // 
            this.cmb_Food.Font = new System.Drawing.Font("Times New Roman", 15F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_Food.FormattingEnabled = true;
            this.cmb_Food.Items.AddRange(new object[] {
            "Vegetarian",
            "Non-Vegetarian",
            "Eggetarian",
            "Neutral"});
            this.cmb_Food.Location = new System.Drawing.Point(514, 233);
            this.cmb_Food.Name = "cmb_Food";
            this.cmb_Food.Size = new System.Drawing.Size(169, 38);
            this.cmb_Food.TabIndex = 75;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.Info;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(0, 341);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(1482, 411);
            this.dataGridView1.TabIndex = 76;
            this.dataGridView1.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellDoubleClick);
            // 
            // lbl_Looking_For
            // 
            this.lbl_Looking_For.AutoSize = true;
            this.lbl_Looking_For.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Looking_For.Location = new System.Drawing.Point(12, 132);
            this.lbl_Looking_For.Name = "lbl_Looking_For";
            this.lbl_Looking_For.Size = new System.Drawing.Size(138, 29);
            this.lbl_Looking_For.TabIndex = 77;
            this.lbl_Looking_For.Text = "Looking For";
            // 
            // btn_Search
            // 
            this.btn_Search.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btn_Search.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Search.Location = new System.Drawing.Point(1316, 290);
            this.btn_Search.Name = "btn_Search";
            this.btn_Search.Size = new System.Drawing.Size(154, 39);
            this.btn_Search.TabIndex = 81;
            this.btn_Search.Text = "Search";
            this.btn_Search.UseVisualStyleBackColor = false;
            this.btn_Search.Click += new System.EventHandler(this.btn_Search_Click);
            // 
            // cmb_Looking_for
            // 
            this.cmb_Looking_for.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb_Looking_for.Font = new System.Drawing.Font("Times New Roman", 15F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_Looking_for.Items.AddRange(new object[] {
            "Male",
            "Female"});
            this.cmb_Looking_for.Location = new System.Drawing.Point(176, 128);
            this.cmb_Looking_for.Name = "cmb_Looking_for";
            this.cmb_Looking_for.Size = new System.Drawing.Size(231, 38);
            this.cmb_Looking_for.TabIndex = 82;
            this.cmb_Looking_for.SelectedIndexChanged += new System.EventHandler(this.cmb_Looking_for_SelectedIndexChanged);
            // 
            // frm_Matching_Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.ClientSize = new System.Drawing.Size(1482, 753);
            this.Controls.Add(this.cmb_Looking_for);
            this.Controls.Add(this.btn_Search);
            this.Controls.Add(this.lbl_Looking_For);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.cmb_Food);
            this.Controls.Add(this.cmb_Sub_Caste);
            this.Controls.Add(this.cmb_Caste);
            this.Controls.Add(this.cmb_Marital_Status);
            this.Controls.Add(this.cmb_Family_Type);
            this.Controls.Add(this.lbl_Family_Type);
            this.Controls.Add(this.cmb_Employed_In);
            this.Controls.Add(this.lbl_Highest_Education);
            this.Controls.Add(this.cmb_Highest_Educatiion);
            this.Controls.Add(this.lbl_Occupation);
            this.Controls.Add(this.cmb_Occupation);
            this.Controls.Add(this.lbl_Employed_In);
            this.Controls.Add(this.lbl_Monthly_Income);
            this.Controls.Add(this.cmb_Monthly_Income);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.cmb_Complexion);
            this.Controls.Add(this.lbl_Complexion);
            this.Controls.Add(this.cmb_Residing_City);
            this.Controls.Add(this.lbl_Residing_City);
            this.Controls.Add(this.lbl_Sub_Caste);
            this.Controls.Add(this.lbl_Caste);
            this.Controls.Add(this.lbl_Marital_Status);
            this.Controls.Add(this.panel2);
            this.Name = "frm_Matching_Form";
            this.Load += new System.EventHandler(this.frm_Matching_Form_Load);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion 

        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label lbl_matching_Slogen;
        private System.Windows.Forms.Label lbl_Find_Your_Compader;
        private System.Windows.Forms.Label lbl_Marital_Status;
        private System.Windows.Forms.Label lbl_Caste;
        private System.Windows.Forms.Label lbl_Sub_Caste;
        private System.Windows.Forms.ComboBox cmb_Residing_City;
        private System.Windows.Forms.Label lbl_Residing_City;
        private System.Windows.Forms.ComboBox cmb_Complexion;
        private System.Windows.Forms.Label lbl_Complexion;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cmb_Employed_In;
        private System.Windows.Forms.Label lbl_Highest_Education;
        private System.Windows.Forms.ComboBox cmb_Highest_Educatiion;
        private System.Windows.Forms.Label lbl_Occupation;
        private System.Windows.Forms.ComboBox cmb_Occupation;
        private System.Windows.Forms.Label lbl_Employed_In;
        private System.Windows.Forms.Label lbl_Monthly_Income;
        private System.Windows.Forms.ComboBox cmb_Monthly_Income;
        private System.Windows.Forms.ComboBox cmb_Family_Type;
        private System.Windows.Forms.Label lbl_Family_Type;
        private System.Windows.Forms.ComboBox cmb_Marital_Status;
        private System.Windows.Forms.ComboBox cmb_Caste;
        private System.Windows.Forms.ComboBox cmb_Sub_Caste;
        private System.Windows.Forms.ComboBox cmb_Food;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label lbl_Looking_For;
        private System.Windows.Forms.Button btn_Search;
        private System.Windows.Forms.ComboBox cmb_Looking_for;
    }
}
