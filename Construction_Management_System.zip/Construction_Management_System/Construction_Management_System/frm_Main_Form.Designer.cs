﻿namespace Construction_Management_System
{
    partial class frm_Main_Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_Entry = new System.Windows.Forms.Button();
            this.btn_Transaction = new System.Windows.Forms.Button();
            this.btn_Accounting = new System.Windows.Forms.Button();
            this.btn_Report = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn_Entry
            // 
            this.btn_Entry.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btn_Entry.Font = new System.Drawing.Font("Cambria", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Entry.Location = new System.Drawing.Point(0, 0);
            this.btn_Entry.Name = "btn_Entry";
            this.btn_Entry.Size = new System.Drawing.Size(147, 52);
            this.btn_Entry.TabIndex = 0;
            this.btn_Entry.Text = "ENTRY";
            this.btn_Entry.UseVisualStyleBackColor = false;
            // 
            // btn_Transaction
            // 
            this.btn_Transaction.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btn_Transaction.Font = new System.Drawing.Font("Cambria", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Transaction.Location = new System.Drawing.Point(144, 0);
            this.btn_Transaction.Name = "btn_Transaction";
            this.btn_Transaction.Size = new System.Drawing.Size(282, 52);
            this.btn_Transaction.TabIndex = 1;
            this.btn_Transaction.Text = "TRANSACTION";
            this.btn_Transaction.UseVisualStyleBackColor = false;
            // 
            // btn_Accounting
            // 
            this.btn_Accounting.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btn_Accounting.Font = new System.Drawing.Font("Cambria", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Accounting.Location = new System.Drawing.Point(422, 0);
            this.btn_Accounting.Name = "btn_Accounting";
            this.btn_Accounting.Size = new System.Drawing.Size(260, 52);
            this.btn_Accounting.TabIndex = 2;
            this.btn_Accounting.Text = "ACCOUNTING";
            this.btn_Accounting.UseVisualStyleBackColor = false;
            // 
            // btn_Report
            // 
            this.btn_Report.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btn_Report.Font = new System.Drawing.Font("Cambria", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Report.Location = new System.Drawing.Point(678, 0);
            this.btn_Report.Name = "btn_Report";
            this.btn_Report.Size = new System.Drawing.Size(229, 53);
            this.btn_Report.TabIndex = 3;
            this.btn_Report.Text = "REPORTS";
            this.btn_Report.UseVisualStyleBackColor = false;
            // 
            // frm_Main_Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Construction_Management_System.Properties.Resources.b30ce826c9a6c1d31a5d1a3341fecbe62;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1109, 743);
            this.Controls.Add(this.btn_Report);
            this.Controls.Add(this.btn_Accounting);
            this.Controls.Add(this.btn_Transaction);
            this.Controls.Add(this.btn_Entry);
            this.Name = "frm_Main_Form";
            this.Text = "Main Form";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_Entry;
        private System.Windows.Forms.Button btn_Transaction;
        private System.Windows.Forms.Button btn_Accounting;
        private System.Windows.Forms.Button btn_Report;
    }
}