﻿namespace Construction_Management_System
{
    partial class frm_Site_Entry
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_Site_Entry = new System.Windows.Forms.Label();
            this.lbl_Site_ID = new System.Windows.Forms.Label();
            this.lbl_Site_Name = new System.Windows.Forms.Label();
            this.lbl_Owner_Name = new System.Windows.Forms.Label();
            this.lbl_Address = new System.Windows.Forms.Label();
            this.lbl_Mobile_No = new System.Windows.Forms.Label();
            this.lbl_Start_Date = new System.Windows.Forms.Label();
            this.lbl_Proposed_Date = new System.Windows.Forms.Label();
            this.tb_Site_ID = new System.Windows.Forms.TextBox();
            this.tb_Site_Name = new System.Windows.Forms.TextBox();
            this.tb_Owner_Name = new System.Windows.Forms.TextBox();
            this.tb_Address = new System.Windows.Forms.TextBox();
            this.tb_Mobile_No = new System.Windows.Forms.TextBox();
            this.dtp_Start_Date = new System.Windows.Forms.DateTimePicker();
            this.dtp_Proposed_Date = new System.Windows.Forms.DateTimePicker();
            this.btn_New = new System.Windows.Forms.Button();
            this.btn_Save = new System.Windows.Forms.Button();
            this.btn_Edit = new System.Windows.Forms.Button();
            this.btn_Show = new System.Windows.Forms.Button();
            this.lbl_Site_Details = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lbl_Construction_Details = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.tb_Total_Area_In_SQ_FT = new System.Windows.Forms.TextBox();
            this.lbl_Estimate_Cost = new System.Windows.Forms.Label();
            this.tb_Estimated_Cost = new System.Windows.Forms.TextBox();
            this.lbl_Owner_Requirment = new System.Windows.Forms.Label();
            this.tb_Owner_Requirment = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // lbl_Site_Entry
            // 
            this.lbl_Site_Entry.AutoSize = true;
            this.lbl_Site_Entry.Font = new System.Drawing.Font("Cambria", 25.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Site_Entry.Location = new System.Drawing.Point(393, 9);
            this.lbl_Site_Entry.Name = "lbl_Site_Entry";
            this.lbl_Site_Entry.Size = new System.Drawing.Size(253, 51);
            this.lbl_Site_Entry.TabIndex = 0;
            this.lbl_Site_Entry.Text = "SITE ENTRY";
            // 
            // lbl_Site_ID
            // 
            this.lbl_Site_ID.AutoSize = true;
            this.lbl_Site_ID.Font = new System.Drawing.Font("Cambria", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Site_ID.Location = new System.Drawing.Point(41, 91);
            this.lbl_Site_ID.Name = "lbl_Site_ID";
            this.lbl_Site_ID.Size = new System.Drawing.Size(105, 32);
            this.lbl_Site_ID.TabIndex = 1;
            this.lbl_Site_ID.Text = "SITE ID";
            // 
            // lbl_Site_Name
            // 
            this.lbl_Site_Name.AutoSize = true;
            this.lbl_Site_Name.Font = new System.Drawing.Font("Cambria", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Site_Name.Location = new System.Drawing.Point(254, 91);
            this.lbl_Site_Name.Name = "lbl_Site_Name";
            this.lbl_Site_Name.Size = new System.Drawing.Size(151, 32);
            this.lbl_Site_Name.TabIndex = 2;
            this.lbl_Site_Name.Text = "SITE NAME";
            // 
            // lbl_Owner_Name
            // 
            this.lbl_Owner_Name.AutoSize = true;
            this.lbl_Owner_Name.Font = new System.Drawing.Font("Cambria", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Owner_Name.Location = new System.Drawing.Point(42, 183);
            this.lbl_Owner_Name.Name = "lbl_Owner_Name";
            this.lbl_Owner_Name.Size = new System.Drawing.Size(192, 32);
            this.lbl_Owner_Name.TabIndex = 3;
            this.lbl_Owner_Name.Text = "OWNER NAME";
            // 
            // lbl_Address
            // 
            this.lbl_Address.AutoSize = true;
            this.lbl_Address.Font = new System.Drawing.Font("Cambria", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Address.Location = new System.Drawing.Point(42, 266);
            this.lbl_Address.Name = "lbl_Address";
            this.lbl_Address.Size = new System.Drawing.Size(136, 33);
            this.lbl_Address.TabIndex = 4;
            this.lbl_Address.Text = "ADDRESS";
            // 
            // lbl_Mobile_No
            // 
            this.lbl_Mobile_No.AutoSize = true;
            this.lbl_Mobile_No.Font = new System.Drawing.Font("Cambria", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Mobile_No.Location = new System.Drawing.Point(356, 266);
            this.lbl_Mobile_No.Name = "lbl_Mobile_No";
            this.lbl_Mobile_No.Size = new System.Drawing.Size(161, 33);
            this.lbl_Mobile_No.TabIndex = 5;
            this.lbl_Mobile_No.Text = "MOBILE NO";
            // 
            // lbl_Start_Date
            // 
            this.lbl_Start_Date.AutoSize = true;
            this.lbl_Start_Date.Font = new System.Drawing.Font("Cambria", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Start_Date.Location = new System.Drawing.Point(356, 352);
            this.lbl_Start_Date.Name = "lbl_Start_Date";
            this.lbl_Start_Date.Size = new System.Drawing.Size(173, 33);
            this.lbl_Start_Date.TabIndex = 6;
            this.lbl_Start_Date.Text = "START DATE";
            // 
            // lbl_Proposed_Date
            // 
            this.lbl_Proposed_Date.AutoSize = true;
            this.lbl_Proposed_Date.Font = new System.Drawing.Font("Cambria", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Proposed_Date.Location = new System.Drawing.Point(356, 429);
            this.lbl_Proposed_Date.Name = "lbl_Proposed_Date";
            this.lbl_Proposed_Date.Size = new System.Drawing.Size(230, 33);
            this.lbl_Proposed_Date.TabIndex = 7;
            this.lbl_Proposed_Date.Text = "PROPOSED DATE";
            // 
            // tb_Site_ID
            // 
            this.tb_Site_ID.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Site_ID.Location = new System.Drawing.Point(47, 135);
            this.tb_Site_ID.Name = "tb_Site_ID";
            this.tb_Site_ID.Size = new System.Drawing.Size(187, 36);
            this.tb_Site_ID.TabIndex = 1;
            // 
            // tb_Site_Name
            // 
            this.tb_Site_Name.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Site_Name.Location = new System.Drawing.Point(260, 135);
            this.tb_Site_Name.Name = "tb_Site_Name";
            this.tb_Site_Name.Size = new System.Drawing.Size(371, 36);
            this.tb_Site_Name.TabIndex = 2;
            // 
            // tb_Owner_Name
            // 
            this.tb_Owner_Name.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Owner_Name.Location = new System.Drawing.Point(47, 218);
            this.tb_Owner_Name.Name = "tb_Owner_Name";
            this.tb_Owner_Name.Size = new System.Drawing.Size(584, 36);
            this.tb_Owner_Name.TabIndex = 3;
            // 
            // tb_Address
            // 
            this.tb_Address.Location = new System.Drawing.Point(47, 302);
            this.tb_Address.Multiline = true;
            this.tb_Address.Name = "tb_Address";
            this.tb_Address.Size = new System.Drawing.Size(277, 115);
            this.tb_Address.TabIndex = 4;
            // 
            // tb_Mobile_No
            // 
            this.tb_Mobile_No.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Mobile_No.Location = new System.Drawing.Point(362, 302);
            this.tb_Mobile_No.Name = "tb_Mobile_No";
            this.tb_Mobile_No.Size = new System.Drawing.Size(269, 36);
            this.tb_Mobile_No.TabIndex = 5;
            // 
            // dtp_Start_Date
            // 
            this.dtp_Start_Date.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtp_Start_Date.Location = new System.Drawing.Point(362, 391);
            this.dtp_Start_Date.Name = "dtp_Start_Date";
            this.dtp_Start_Date.Size = new System.Drawing.Size(269, 26);
            this.dtp_Start_Date.TabIndex = 6;
            // 
            // dtp_Proposed_Date
            // 
            this.dtp_Proposed_Date.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtp_Proposed_Date.Location = new System.Drawing.Point(362, 465);
            this.dtp_Proposed_Date.Name = "dtp_Proposed_Date";
            this.dtp_Proposed_Date.Size = new System.Drawing.Size(269, 26);
            this.dtp_Proposed_Date.TabIndex = 7;
            // 
            // btn_New
            // 
            this.btn_New.Font = new System.Drawing.Font("Cambria", 25.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_New.Location = new System.Drawing.Point(816, 91);
            this.btn_New.Name = "btn_New";
            this.btn_New.Size = new System.Drawing.Size(133, 61);
            this.btn_New.TabIndex = 15;
            this.btn_New.Text = "NEW";
            this.btn_New.UseVisualStyleBackColor = true;
            // 
            // btn_Save
            // 
            this.btn_Save.Font = new System.Drawing.Font("Cambria", 25.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Save.Location = new System.Drawing.Point(816, 184);
            this.btn_Save.Name = "btn_Save";
            this.btn_Save.Size = new System.Drawing.Size(133, 70);
            this.btn_Save.TabIndex = 16;
            this.btn_Save.Text = "SAVE";
            this.btn_Save.UseVisualStyleBackColor = true;
            // 
            // btn_Edit
            // 
            this.btn_Edit.Font = new System.Drawing.Font("Cambria", 25.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Edit.Location = new System.Drawing.Point(816, 291);
            this.btn_Edit.Name = "btn_Edit";
            this.btn_Edit.Size = new System.Drawing.Size(133, 62);
            this.btn_Edit.TabIndex = 17;
            this.btn_Edit.Text = "EDIT";
            this.btn_Edit.UseVisualStyleBackColor = true;
            // 
            // btn_Show
            // 
            this.btn_Show.Font = new System.Drawing.Font("Cambria", 25.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Show.Location = new System.Drawing.Point(816, 391);
            this.btn_Show.Name = "btn_Show";
            this.btn_Show.Size = new System.Drawing.Size(160, 60);
            this.btn_Show.TabIndex = 18;
            this.btn_Show.Text = "SHOW";
            this.btn_Show.UseVisualStyleBackColor = true;
            // 
            // lbl_Site_Details
            // 
            this.lbl_Site_Details.AutoSize = true;
            this.lbl_Site_Details.Font = new System.Drawing.Font("Cambria", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Site_Details.Location = new System.Drawing.Point(45, 59);
            this.lbl_Site_Details.Name = "lbl_Site_Details";
            this.lbl_Site_Details.Size = new System.Drawing.Size(101, 20);
            this.lbl_Site_Details.TabIndex = 19;
            this.lbl_Site_Details.Text = "Site Details:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(0, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(46, 17);
            this.label1.TabIndex = 20;
            this.label1.Text = "label1";
            // 
            // lbl_Construction_Details
            // 
            this.lbl_Construction_Details.AutoSize = true;
            this.lbl_Construction_Details.Font = new System.Drawing.Font("Cambria", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Construction_Details.Location = new System.Drawing.Point(66, 501);
            this.lbl_Construction_Details.Name = "lbl_Construction_Details";
            this.lbl_Construction_Details.Size = new System.Drawing.Size(168, 20);
            this.lbl_Construction_Details.TabIndex = 21;
            this.lbl_Construction_Details.Text = "Construction Details";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Cambria", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(65, 531);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(259, 30);
            this.label2.TabIndex = 22;
            this.label2.Text = "TOTAL AREA IN SQ.FT";
            // 
            // tb_Total_Area_In_SQ_FT
            // 
            this.tb_Total_Area_In_SQ_FT.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Total_Area_In_SQ_FT.Location = new System.Drawing.Point(70, 564);
            this.tb_Total_Area_In_SQ_FT.Name = "tb_Total_Area_In_SQ_FT";
            this.tb_Total_Area_In_SQ_FT.Size = new System.Drawing.Size(181, 26);
            this.tb_Total_Area_In_SQ_FT.TabIndex = 8;
            // 
            // lbl_Estimate_Cost
            // 
            this.lbl_Estimate_Cost.AutoSize = true;
            this.lbl_Estimate_Cost.Font = new System.Drawing.Font("Cambria", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Estimate_Cost.Location = new System.Drawing.Point(357, 531);
            this.lbl_Estimate_Cost.Name = "lbl_Estimate_Cost";
            this.lbl_Estimate_Cost.Size = new System.Drawing.Size(214, 30);
            this.lbl_Estimate_Cost.TabIndex = 24;
            this.lbl_Estimate_Cost.Text = "ESTIMATED COST";
            // 
            // tb_Estimated_Cost
            // 
            this.tb_Estimated_Cost.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Estimated_Cost.Location = new System.Drawing.Point(362, 567);
            this.tb_Estimated_Cost.Name = "tb_Estimated_Cost";
            this.tb_Estimated_Cost.Size = new System.Drawing.Size(200, 26);
            this.tb_Estimated_Cost.TabIndex = 9;
            // 
            // lbl_Owner_Requirment
            // 
            this.lbl_Owner_Requirment.AutoSize = true;
            this.lbl_Owner_Requirment.Font = new System.Drawing.Font("Cambria", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Owner_Requirment.Location = new System.Drawing.Point(622, 531);
            this.lbl_Owner_Requirment.Name = "lbl_Owner_Requirment";
            this.lbl_Owner_Requirment.Size = new System.Drawing.Size(267, 30);
            this.lbl_Owner_Requirment.TabIndex = 26;
            this.lbl_Owner_Requirment.Text = "OWNER REQUIRMENT";
            // 
            // tb_Owner_Requirment
            // 
            this.tb_Owner_Requirment.Location = new System.Drawing.Point(638, 568);
            this.tb_Owner_Requirment.Multiline = true;
            this.tb_Owner_Requirment.Name = "tb_Owner_Requirment";
            this.tb_Owner_Requirment.Size = new System.Drawing.Size(251, 79);
            this.tb_Owner_Requirment.TabIndex = 10;
            // 
            // frm_Site_Entry
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.ClientSize = new System.Drawing.Size(1112, 708);
            this.Controls.Add(this.tb_Owner_Requirment);
            this.Controls.Add(this.lbl_Owner_Requirment);
            this.Controls.Add(this.tb_Estimated_Cost);
            this.Controls.Add(this.lbl_Estimate_Cost);
            this.Controls.Add(this.tb_Total_Area_In_SQ_FT);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lbl_Construction_Details);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lbl_Site_Details);
            this.Controls.Add(this.btn_Show);
            this.Controls.Add(this.btn_Edit);
            this.Controls.Add(this.btn_Save);
            this.Controls.Add(this.btn_New);
            this.Controls.Add(this.dtp_Proposed_Date);
            this.Controls.Add(this.dtp_Start_Date);
            this.Controls.Add(this.tb_Mobile_No);
            this.Controls.Add(this.tb_Address);
            this.Controls.Add(this.tb_Owner_Name);
            this.Controls.Add(this.tb_Site_Name);
            this.Controls.Add(this.tb_Site_ID);
            this.Controls.Add(this.lbl_Proposed_Date);
            this.Controls.Add(this.lbl_Start_Date);
            this.Controls.Add(this.lbl_Mobile_No);
            this.Controls.Add(this.lbl_Address);
            this.Controls.Add(this.lbl_Owner_Name);
            this.Controls.Add(this.lbl_Site_Name);
            this.Controls.Add(this.lbl_Site_ID);
            this.Controls.Add(this.lbl_Site_Entry);
            this.Name = "frm_Site_Entry";
            this.Text = "SITE ENTRY";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_Site_Entry;
        private System.Windows.Forms.Label lbl_Site_ID;
        private System.Windows.Forms.Label lbl_Site_Name;
        private System.Windows.Forms.Label lbl_Owner_Name;
        private System.Windows.Forms.Label lbl_Address;
        private System.Windows.Forms.Label lbl_Mobile_No;
        private System.Windows.Forms.Label lbl_Start_Date;
        private System.Windows.Forms.Label lbl_Proposed_Date;
        private System.Windows.Forms.TextBox tb_Site_ID;
        private System.Windows.Forms.TextBox tb_Site_Name;
        private System.Windows.Forms.TextBox tb_Owner_Name;
        private System.Windows.Forms.TextBox tb_Address;
        private System.Windows.Forms.TextBox tb_Mobile_No;
        private System.Windows.Forms.DateTimePicker dtp_Start_Date;
        private System.Windows.Forms.DateTimePicker dtp_Proposed_Date;
        private System.Windows.Forms.Button btn_New;
        private System.Windows.Forms.Button btn_Save;
        private System.Windows.Forms.Button btn_Edit;
        private System.Windows.Forms.Button btn_Show;
        private System.Windows.Forms.Label lbl_Site_Details;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lbl_Construction_Details;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tb_Total_Area_In_SQ_FT;
        private System.Windows.Forms.Label lbl_Estimate_Cost;
        private System.Windows.Forms.TextBox tb_Estimated_Cost;
        private System.Windows.Forms.Label lbl_Owner_Requirment;
        private System.Windows.Forms.TextBox tb_Owner_Requirment;
    }
}