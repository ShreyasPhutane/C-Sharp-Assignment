﻿namespace Destiny.cs
{
    partial class frm_More_Details
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.lbl_More_Personal_Details = new System.Windows.Forms.Label();
            this.gb_More_Personal_Details = new System.Windows.Forms.GroupBox();
            this.cmb_Residing_City = new System.Windows.Forms.ComboBox();
            this.cmb_Residing_State = new System.Windows.Forms.ComboBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.tb_Sub_Caste = new System.Windows.Forms.TextBox();
            this.tb_Caste = new System.Windows.Forms.TextBox();
            this.lbl_Residing_State = new System.Windows.Forms.Label();
            this.lbl_Gothra = new System.Windows.Forms.Label();
            this.lbl_Sub_Caste = new System.Windows.Forms.Label();
            this.lbl_Caste = new System.Windows.Forms.Label();
            this.lbl_Residing_City = new System.Windows.Forms.Label();
            this.radioButton4 = new System.Windows.Forms.RadioButton();
            this.radioButton3 = new System.Windows.Forms.RadioButton();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.lbl_Marital_Status = new System.Windows.Forms.Label();
            this.gb_Physical_Attributes = new System.Windows.Forms.GroupBox();
            this.cmb_Complexion = new System.Windows.Forms.ComboBox();
            this.cmb_Body_Type = new System.Windows.Forms.ComboBox();
            this.tb_Weight = new System.Windows.Forms.TextBox();
            this.tb_Height = new System.Windows.Forms.TextBox();
            this.rb_Physically_Challenged = new System.Windows.Forms.RadioButton();
            this.rb_normal = new System.Windows.Forms.RadioButton();
            this.rb_Dark = new System.Windows.Forms.RadioButton();
            this.lbl_Physical_Status = new System.Windows.Forms.Label();
            this.lbl_Complexion = new System.Windows.Forms.Label();
            this.lbl_Body_Type = new System.Windows.Forms.Label();
            this.lbl_Weight = new System.Windows.Forms.Label();
            this.lbl_Height = new System.Windows.Forms.Label();
            this.gb_Habits = new System.Windows.Forms.GroupBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.rb_Yes_ = new System.Windows.Forms.RadioButton();
            this.rb_No_ = new System.Windows.Forms.RadioButton();
            this.rb_Drink_Socially = new System.Windows.Forms.RadioButton();
            this.rb_Yes = new System.Windows.Forms.RadioButton();
            this.rb_Occasionally = new System.Windows.Forms.RadioButton();
            this.rb_No = new System.Windows.Forms.RadioButton();
            this.rb_Eggetarian = new System.Windows.Forms.RadioButton();
            this.rb_Non_Vegetarian = new System.Windows.Forms.RadioButton();
            this.lbl_Drinking = new System.Windows.Forms.Label();
            this.lbl_Smoking = new System.Windows.Forms.Label();
            this.rb_Vegetarian = new System.Windows.Forms.RadioButton();
            this.lbl_Food = new System.Windows.Forms.Label();
            this.btn_Save = new System.Windows.Forms.Button();
            this.btn_Next = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.gb_More_Personal_Details.SuspendLayout();
            this.gb_Physical_Attributes.SuspendLayout();
            this.gb_Habits.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel1.Controls.Add(this.lbl_More_Personal_Details);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1482, 116);
            this.panel1.TabIndex = 18;
            // 
            // lbl_More_Personal_Details
            // 
            this.lbl_More_Personal_Details.AutoSize = true;
            this.lbl_More_Personal_Details.Font = new System.Drawing.Font("Times New Roman", 36F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_More_Personal_Details.ForeColor = System.Drawing.Color.Navy;
            this.lbl_More_Personal_Details.Location = new System.Drawing.Point(435, 24);
            this.lbl_More_Personal_Details.Name = "lbl_More_Personal_Details";
            this.lbl_More_Personal_Details.Size = new System.Drawing.Size(586, 67);
            this.lbl_More_Personal_Details.TabIndex = 0;
            this.lbl_More_Personal_Details.Text = "More Personal Details";
            // 
            // gb_More_Personal_Details
            // 
            this.gb_More_Personal_Details.Controls.Add(this.cmb_Residing_City);
            this.gb_More_Personal_Details.Controls.Add(this.cmb_Residing_State);
            this.gb_More_Personal_Details.Controls.Add(this.textBox3);
            this.gb_More_Personal_Details.Controls.Add(this.tb_Sub_Caste);
            this.gb_More_Personal_Details.Controls.Add(this.tb_Caste);
            this.gb_More_Personal_Details.Controls.Add(this.lbl_Residing_State);
            this.gb_More_Personal_Details.Controls.Add(this.lbl_Gothra);
            this.gb_More_Personal_Details.Controls.Add(this.lbl_Sub_Caste);
            this.gb_More_Personal_Details.Controls.Add(this.lbl_Caste);
            this.gb_More_Personal_Details.Controls.Add(this.lbl_Residing_City);
            this.gb_More_Personal_Details.Controls.Add(this.radioButton4);
            this.gb_More_Personal_Details.Controls.Add(this.radioButton3);
            this.gb_More_Personal_Details.Controls.Add(this.radioButton2);
            this.gb_More_Personal_Details.Controls.Add(this.radioButton1);
            this.gb_More_Personal_Details.Controls.Add(this.lbl_Marital_Status);
            this.gb_More_Personal_Details.Font = new System.Drawing.Font("Times New Roman", 19.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gb_More_Personal_Details.Location = new System.Drawing.Point(106, 135);
            this.gb_More_Personal_Details.Name = "gb_More_Personal_Details";
            this.gb_More_Personal_Details.Size = new System.Drawing.Size(617, 522);
            this.gb_More_Personal_Details.TabIndex = 19;
            this.gb_More_Personal_Details.TabStop = false;
            this.gb_More_Personal_Details.Text = "More Personal Details";
            // 
            // cmb_Residing_City
            // 
            this.cmb_Residing_City.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_Residing_City.FormattingEnabled = true;
            this.cmb_Residing_City.Items.AddRange(new object[] {
            "Satara",
            "Kolhapur",
            "Pune",
            "Mumbai"});
            this.cmb_Residing_City.Location = new System.Drawing.Point(188, 471);
            this.cmb_Residing_City.Name = "cmb_Residing_City";
            this.cmb_Residing_City.Size = new System.Drawing.Size(167, 37);
            this.cmb_Residing_City.TabIndex = 45;
            // 
            // cmb_Residing_State
            // 
            this.cmb_Residing_State.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_Residing_State.FormattingEnabled = true;
            this.cmb_Residing_State.Items.AddRange(new object[] {
            "Maharashtra"});
            this.cmb_Residing_State.Location = new System.Drawing.Point(188, 388);
            this.cmb_Residing_State.Name = "cmb_Residing_State";
            this.cmb_Residing_State.Size = new System.Drawing.Size(167, 37);
            this.cmb_Residing_State.TabIndex = 41;
            // 
            // textBox3
            // 
            this.textBox3.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox3.Location = new System.Drawing.Point(188, 317);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(167, 36);
            this.textBox3.TabIndex = 39;
            // 
            // tb_Sub_Caste
            // 
            this.tb_Sub_Caste.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Sub_Caste.Location = new System.Drawing.Point(188, 240);
            this.tb_Sub_Caste.Name = "tb_Sub_Caste";
            this.tb_Sub_Caste.Size = new System.Drawing.Size(167, 36);
            this.tb_Sub_Caste.TabIndex = 37;
            // 
            // tb_Caste
            // 
            this.tb_Caste.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Caste.Location = new System.Drawing.Point(188, 167);
            this.tb_Caste.Name = "tb_Caste";
            this.tb_Caste.Size = new System.Drawing.Size(167, 36);
            this.tb_Caste.TabIndex = 36;
            // 
            // lbl_Residing_State
            // 
            this.lbl_Residing_State.AutoSize = true;
            this.lbl_Residing_State.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Residing_State.Location = new System.Drawing.Point(12, 391);
            this.lbl_Residing_State.Name = "lbl_Residing_State";
            this.lbl_Residing_State.Size = new System.Drawing.Size(157, 29);
            this.lbl_Residing_State.TabIndex = 43;
            this.lbl_Residing_State.Text = "Residing State";
            // 
            // lbl_Gothra
            // 
            this.lbl_Gothra.AutoSize = true;
            this.lbl_Gothra.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Gothra.Location = new System.Drawing.Point(12, 320);
            this.lbl_Gothra.Name = "lbl_Gothra";
            this.lbl_Gothra.Size = new System.Drawing.Size(83, 29);
            this.lbl_Gothra.TabIndex = 42;
            this.lbl_Gothra.Text = "Gothra";
            // 
            // lbl_Sub_Caste
            // 
            this.lbl_Sub_Caste.AutoSize = true;
            this.lbl_Sub_Caste.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Sub_Caste.Location = new System.Drawing.Point(12, 243);
            this.lbl_Sub_Caste.Name = "lbl_Sub_Caste";
            this.lbl_Sub_Caste.Size = new System.Drawing.Size(115, 29);
            this.lbl_Sub_Caste.TabIndex = 40;
            this.lbl_Sub_Caste.Text = "Sub Caste";
            // 
            // lbl_Caste
            // 
            this.lbl_Caste.AutoSize = true;
            this.lbl_Caste.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Caste.Location = new System.Drawing.Point(12, 170);
            this.lbl_Caste.Name = "lbl_Caste";
            this.lbl_Caste.Size = new System.Drawing.Size(69, 29);
            this.lbl_Caste.TabIndex = 38;
            this.lbl_Caste.Text = "Caste";
            // 
            // lbl_Residing_City
            // 
            this.lbl_Residing_City.AutoSize = true;
            this.lbl_Residing_City.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Residing_City.Location = new System.Drawing.Point(12, 474);
            this.lbl_Residing_City.Name = "lbl_Residing_City";
            this.lbl_Residing_City.Size = new System.Drawing.Size(150, 29);
            this.lbl_Residing_City.TabIndex = 44;
            this.lbl_Residing_City.Text = "Residing City";
            // 
            // radioButton4
            // 
            this.radioButton4.AutoSize = true;
            this.radioButton4.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton4.Location = new System.Drawing.Point(188, 110);
            this.radioButton4.Name = "radioButton4";
            this.radioButton4.Size = new System.Drawing.Size(227, 33);
            this.radioButton4.TabIndex = 35;
            this.radioButton4.TabStop = true;
            this.radioButton4.Text = "Awaiting  Divorced";
            this.radioButton4.UseVisualStyleBackColor = true;
            // 
            // radioButton3
            // 
            this.radioButton3.AutoSize = true;
            this.radioButton3.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton3.Location = new System.Drawing.Point(486, 67);
            this.radioButton3.Name = "radioButton3";
            this.radioButton3.Size = new System.Drawing.Size(126, 33);
            this.radioButton3.TabIndex = 34;
            this.radioButton3.TabStop = true;
            this.radioButton3.Text = "Divorced";
            this.radioButton3.UseVisualStyleBackColor = true;
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton2.Location = new System.Drawing.Point(373, 69);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(107, 33);
            this.radioButton2.TabIndex = 33;
            this.radioButton2.TabStop = true;
            this.radioButton2.Text = "Widow";
            this.radioButton2.UseVisualStyleBackColor = true;
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton1.Location = new System.Drawing.Point(188, 71);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(179, 33);
            this.radioButton1.TabIndex = 32;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "Never Married";
            this.radioButton1.UseVisualStyleBackColor = true;
            // 
            // lbl_Marital_Status
            // 
            this.lbl_Marital_Status.AutoSize = true;
            this.lbl_Marital_Status.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Marital_Status.Location = new System.Drawing.Point(12, 71);
            this.lbl_Marital_Status.Name = "lbl_Marital_Status";
            this.lbl_Marital_Status.Size = new System.Drawing.Size(158, 29);
            this.lbl_Marital_Status.TabIndex = 18;
            this.lbl_Marital_Status.Text = "Marital Status:";
            // 
            // gb_Physical_Attributes
            // 
            this.gb_Physical_Attributes.Controls.Add(this.cmb_Complexion);
            this.gb_Physical_Attributes.Controls.Add(this.cmb_Body_Type);
            this.gb_Physical_Attributes.Controls.Add(this.tb_Weight);
            this.gb_Physical_Attributes.Controls.Add(this.tb_Height);
            this.gb_Physical_Attributes.Controls.Add(this.rb_Physically_Challenged);
            this.gb_Physical_Attributes.Controls.Add(this.rb_normal);
            this.gb_Physical_Attributes.Controls.Add(this.rb_Dark);
            this.gb_Physical_Attributes.Controls.Add(this.lbl_Physical_Status);
            this.gb_Physical_Attributes.Controls.Add(this.lbl_Complexion);
            this.gb_Physical_Attributes.Controls.Add(this.lbl_Body_Type);
            this.gb_Physical_Attributes.Controls.Add(this.lbl_Weight);
            this.gb_Physical_Attributes.Controls.Add(this.lbl_Height);
            this.gb_Physical_Attributes.Font = new System.Drawing.Font("Times New Roman", 20F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gb_Physical_Attributes.Location = new System.Drawing.Point(755, 122);
            this.gb_Physical_Attributes.Name = "gb_Physical_Attributes";
            this.gb_Physical_Attributes.Size = new System.Drawing.Size(677, 364);
            this.gb_Physical_Attributes.TabIndex = 20;
            this.gb_Physical_Attributes.TabStop = false;
            this.gb_Physical_Attributes.Text = "Physical Attributes";
            // 
            // cmb_Complexion
            // 
            this.cmb_Complexion.Font = new System.Drawing.Font("Times New Roman", 15F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_Complexion.FormattingEnabled = true;
            this.cmb_Complexion.Items.AddRange(new object[] {
            "Fair",
            "Over Fair",
            "Wheatish",
            "Wheatish Brown"});
            this.cmb_Complexion.Location = new System.Drawing.Point(206, 264);
            this.cmb_Complexion.Name = "cmb_Complexion";
            this.cmb_Complexion.Size = new System.Drawing.Size(192, 38);
            this.cmb_Complexion.TabIndex = 36;
            // 
            // cmb_Body_Type
            // 
            this.cmb_Body_Type.Font = new System.Drawing.Font("Times New Roman", 15F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_Body_Type.FormattingEnabled = true;
            this.cmb_Body_Type.Items.AddRange(new object[] {
            "Slim",
            "Average",
            "Athietic",
            "Heavy"});
            this.cmb_Body_Type.Location = new System.Drawing.Point(206, 195);
            this.cmb_Body_Type.Name = "cmb_Body_Type";
            this.cmb_Body_Type.Size = new System.Drawing.Size(192, 38);
            this.cmb_Body_Type.TabIndex = 35;
            // 
            // tb_Weight
            // 
            this.tb_Weight.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Weight.Location = new System.Drawing.Point(206, 127);
            this.tb_Weight.Name = "tb_Weight";
            this.tb_Weight.Size = new System.Drawing.Size(119, 36);
            this.tb_Weight.TabIndex = 20;
            // 
            // tb_Height
            // 
            this.tb_Height.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Height.Location = new System.Drawing.Point(206, 57);
            this.tb_Height.Name = "tb_Height";
            this.tb_Height.Size = new System.Drawing.Size(119, 36);
            this.tb_Height.TabIndex = 18;
            // 
            // rb_Physically_Challenged
            // 
            this.rb_Physically_Challenged.AutoSize = true;
            this.rb_Physically_Challenged.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_Physically_Challenged.Location = new System.Drawing.Point(323, 324);
            this.rb_Physically_Challenged.Name = "rb_Physically_Challenged";
            this.rb_Physically_Challenged.Size = new System.Drawing.Size(256, 33);
            this.rb_Physically_Challenged.TabIndex = 34;
            this.rb_Physically_Challenged.Text = "Physically Challenged";
            this.rb_Physically_Challenged.UseVisualStyleBackColor = true;
            // 
            // rb_normal
            // 
            this.rb_normal.AutoSize = true;
            this.rb_normal.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_normal.Location = new System.Drawing.Point(206, 326);
            this.rb_normal.Name = "rb_normal";
            this.rb_normal.Size = new System.Drawing.Size(110, 33);
            this.rb_normal.TabIndex = 33;
            this.rb_normal.Text = "Normal";
            this.rb_normal.UseVisualStyleBackColor = true;
            // 
            // rb_Dark
            // 
            this.rb_Dark.AutoSize = true;
            this.rb_Dark.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_Dark.Location = new System.Drawing.Point(1023, 357);
            this.rb_Dark.Name = "rb_Dark";
            this.rb_Dark.Size = new System.Drawing.Size(63, 23);
            this.rb_Dark.TabIndex = 32;
            this.rb_Dark.Text = "Dark";
            this.rb_Dark.UseVisualStyleBackColor = true;
            // 
            // lbl_Physical_Status
            // 
            this.lbl_Physical_Status.AutoSize = true;
            this.lbl_Physical_Status.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Physical_Status.Location = new System.Drawing.Point(16, 328);
            this.lbl_Physical_Status.Name = "lbl_Physical_Status";
            this.lbl_Physical_Status.Size = new System.Drawing.Size(165, 29);
            this.lbl_Physical_Status.TabIndex = 23;
            this.lbl_Physical_Status.Text = "Physical Status";
            // 
            // lbl_Complexion
            // 
            this.lbl_Complexion.AutoSize = true;
            this.lbl_Complexion.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Complexion.Location = new System.Drawing.Point(16, 268);
            this.lbl_Complexion.Name = "lbl_Complexion";
            this.lbl_Complexion.Size = new System.Drawing.Size(138, 29);
            this.lbl_Complexion.TabIndex = 22;
            this.lbl_Complexion.Text = "Complexion";
            // 
            // lbl_Body_Type
            // 
            this.lbl_Body_Type.AutoSize = true;
            this.lbl_Body_Type.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Body_Type.Location = new System.Drawing.Point(16, 195);
            this.lbl_Body_Type.Name = "lbl_Body_Type";
            this.lbl_Body_Type.Size = new System.Drawing.Size(123, 29);
            this.lbl_Body_Type.TabIndex = 21;
            this.lbl_Body_Type.Text = "Body Type";
            // 
            // lbl_Weight
            // 
            this.lbl_Weight.AutoSize = true;
            this.lbl_Weight.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Weight.Location = new System.Drawing.Point(16, 134);
            this.lbl_Weight.Name = "lbl_Weight";
            this.lbl_Weight.Size = new System.Drawing.Size(84, 29);
            this.lbl_Weight.TabIndex = 19;
            this.lbl_Weight.Text = "Weight";
            // 
            // lbl_Height
            // 
            this.lbl_Height.AutoSize = true;
            this.lbl_Height.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Height.Location = new System.Drawing.Point(16, 65);
            this.lbl_Height.Name = "lbl_Height";
            this.lbl_Height.Size = new System.Drawing.Size(80, 29);
            this.lbl_Height.TabIndex = 17;
            this.lbl_Height.Text = "Height";
            // 
            // gb_Habits
            // 
            this.gb_Habits.Controls.Add(this.label3);
            this.gb_Habits.Controls.Add(this.label1);
            this.gb_Habits.Controls.Add(this.label2);
            this.gb_Habits.Controls.Add(this.rb_Yes_);
            this.gb_Habits.Controls.Add(this.rb_No_);
            this.gb_Habits.Controls.Add(this.rb_Drink_Socially);
            this.gb_Habits.Controls.Add(this.rb_Yes);
            this.gb_Habits.Controls.Add(this.rb_Occasionally);
            this.gb_Habits.Controls.Add(this.rb_No);
            this.gb_Habits.Controls.Add(this.rb_Eggetarian);
            this.gb_Habits.Controls.Add(this.rb_Non_Vegetarian);
            this.gb_Habits.Controls.Add(this.lbl_Drinking);
            this.gb_Habits.Controls.Add(this.lbl_Smoking);
            this.gb_Habits.Controls.Add(this.rb_Vegetarian);
            this.gb_Habits.Controls.Add(this.lbl_Food);
            this.gb_Habits.Font = new System.Drawing.Font("Times New Roman", 20F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gb_Habits.Location = new System.Drawing.Point(776, 501);
            this.gb_Habits.Name = "gb_Habits";
            this.gb_Habits.Size = new System.Drawing.Size(656, 203);
            this.gb_Habits.TabIndex = 21;
            this.gb_Habits.TabStop = false;
            this.gb_Habits.Text = "Habits";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(4, 46);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(66, 29);
            this.label3.TabIndex = 38;
            this.label3.Text = "Food";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(4, 143);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(101, 29);
            this.label1.TabIndex = 37;
            this.label1.Text = "Drinking";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(4, 96);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(103, 29);
            this.label2.TabIndex = 36;
            this.label2.Text = "Smoking";
            // 
            // rb_Yes_
            // 
            this.rb_Yes_.AutoSize = true;
            this.rb_Yes_.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_Yes_.Location = new System.Drawing.Point(502, 139);
            this.rb_Yes_.Name = "rb_Yes_";
            this.rb_Yes_.Size = new System.Drawing.Size(69, 33);
            this.rb_Yes_.TabIndex = 35;
            this.rb_Yes_.TabStop = true;
            this.rb_Yes_.Text = "Yes";
            this.rb_Yes_.UseVisualStyleBackColor = true;
            // 
            // rb_No_
            // 
            this.rb_No_.AutoSize = true;
            this.rb_No_.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_No_.Location = new System.Drawing.Point(158, 141);
            this.rb_No_.Name = "rb_No_";
            this.rb_No_.Size = new System.Drawing.Size(65, 33);
            this.rb_No_.TabIndex = 33;
            this.rb_No_.TabStop = true;
            this.rb_No_.Text = "No";
            this.rb_No_.UseVisualStyleBackColor = true;
            // 
            // rb_Drink_Socially
            // 
            this.rb_Drink_Socially.AutoSize = true;
            this.rb_Drink_Socially.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_Drink_Socially.Location = new System.Drawing.Point(306, 139);
            this.rb_Drink_Socially.Name = "rb_Drink_Socially";
            this.rb_Drink_Socially.Size = new System.Drawing.Size(177, 33);
            this.rb_Drink_Socially.TabIndex = 34;
            this.rb_Drink_Socially.TabStop = true;
            this.rb_Drink_Socially.Text = "Drink Socially";
            this.rb_Drink_Socially.UseVisualStyleBackColor = true;
            // 
            // rb_Yes
            // 
            this.rb_Yes.AutoSize = true;
            this.rb_Yes.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_Yes.Location = new System.Drawing.Point(502, 92);
            this.rb_Yes.Name = "rb_Yes";
            this.rb_Yes.Size = new System.Drawing.Size(69, 33);
            this.rb_Yes.TabIndex = 32;
            this.rb_Yes.TabStop = true;
            this.rb_Yes.Text = "Yes";
            this.rb_Yes.UseVisualStyleBackColor = true;
            // 
            // rb_Occasionally
            // 
            this.rb_Occasionally.AutoSize = true;
            this.rb_Occasionally.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_Occasionally.Location = new System.Drawing.Point(306, 94);
            this.rb_Occasionally.Name = "rb_Occasionally";
            this.rb_Occasionally.Size = new System.Drawing.Size(163, 33);
            this.rb_Occasionally.TabIndex = 30;
            this.rb_Occasionally.TabStop = true;
            this.rb_Occasionally.Text = "Occasionally";
            this.rb_Occasionally.UseVisualStyleBackColor = true;
            // 
            // rb_No
            // 
            this.rb_No.AutoSize = true;
            this.rb_No.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_No.Location = new System.Drawing.Point(158, 94);
            this.rb_No.Name = "rb_No";
            this.rb_No.Size = new System.Drawing.Size(65, 33);
            this.rb_No.TabIndex = 28;
            this.rb_No.TabStop = true;
            this.rb_No.Text = "No";
            this.rb_No.UseVisualStyleBackColor = true;
            // 
            // rb_Eggetarian
            // 
            this.rb_Eggetarian.AutoSize = true;
            this.rb_Eggetarian.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_Eggetarian.Location = new System.Drawing.Point(502, 46);
            this.rb_Eggetarian.Name = "rb_Eggetarian";
            this.rb_Eggetarian.Size = new System.Drawing.Size(140, 33);
            this.rb_Eggetarian.TabIndex = 27;
            this.rb_Eggetarian.TabStop = true;
            this.rb_Eggetarian.Text = "Eggetarian";
            this.rb_Eggetarian.UseVisualStyleBackColor = true;
            // 
            // rb_Non_Vegetarian
            // 
            this.rb_Non_Vegetarian.AutoSize = true;
            this.rb_Non_Vegetarian.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_Non_Vegetarian.Location = new System.Drawing.Point(306, 46);
            this.rb_Non_Vegetarian.Name = "rb_Non_Vegetarian";
            this.rb_Non_Vegetarian.Size = new System.Drawing.Size(191, 33);
            this.rb_Non_Vegetarian.TabIndex = 25;
            this.rb_Non_Vegetarian.TabStop = true;
            this.rb_Non_Vegetarian.Text = "Non-Vegetarian";
            this.rb_Non_Vegetarian.UseVisualStyleBackColor = true;
            // 
            // lbl_Drinking
            // 
            this.lbl_Drinking.AutoSize = true;
            this.lbl_Drinking.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Drinking.Location = new System.Drawing.Point(-225, 314);
            this.lbl_Drinking.Name = "lbl_Drinking";
            this.lbl_Drinking.Size = new System.Drawing.Size(69, 19);
            this.lbl_Drinking.TabIndex = 31;
            this.lbl_Drinking.Text = "Drinking";
            // 
            // lbl_Smoking
            // 
            this.lbl_Smoking.AutoSize = true;
            this.lbl_Smoking.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Smoking.Location = new System.Drawing.Point(-225, 202);
            this.lbl_Smoking.Name = "lbl_Smoking";
            this.lbl_Smoking.Size = new System.Drawing.Size(69, 19);
            this.lbl_Smoking.TabIndex = 29;
            this.lbl_Smoking.Text = "Smoking";
            // 
            // rb_Vegetarian
            // 
            this.rb_Vegetarian.AutoSize = true;
            this.rb_Vegetarian.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_Vegetarian.Location = new System.Drawing.Point(158, 46);
            this.rb_Vegetarian.Name = "rb_Vegetarian";
            this.rb_Vegetarian.Size = new System.Drawing.Size(139, 33);
            this.rb_Vegetarian.TabIndex = 24;
            this.rb_Vegetarian.TabStop = true;
            this.rb_Vegetarian.Text = "Vegetarian";
            this.rb_Vegetarian.UseVisualStyleBackColor = true;
            // 
            // lbl_Food
            // 
            this.lbl_Food.AutoSize = true;
            this.lbl_Food.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Food.Location = new System.Drawing.Point(-225, 85);
            this.lbl_Food.Name = "lbl_Food";
            this.lbl_Food.Size = new System.Drawing.Size(44, 19);
            this.lbl_Food.TabIndex = 26;
            this.lbl_Food.Text = "Food";
            // 
            // btn_Save
            // 
            this.btn_Save.Font = new System.Drawing.Font("Times New Roman", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Save.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btn_Save.Location = new System.Drawing.Point(312, 672);
            this.btn_Save.Name = "btn_Save";
            this.btn_Save.Size = new System.Drawing.Size(131, 55);
            this.btn_Save.TabIndex = 22;
            this.btn_Save.Text = "Save";
            this.btn_Save.UseVisualStyleBackColor = true;
            // 
            // btn_Next
            // 
            this.btn_Next.Font = new System.Drawing.Font("Times New Roman", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Next.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btn_Next.Location = new System.Drawing.Point(487, 672);
            this.btn_Next.Name = "btn_Next";
            this.btn_Next.Size = new System.Drawing.Size(130, 55);
            this.btn_Next.TabIndex = 23;
            this.btn_Next.Text = "Next";
            this.btn_Next.UseVisualStyleBackColor = true;
            // 
            // frm_More_Details
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ClientSize = new System.Drawing.Size(1482, 753);
            this.Controls.Add(this.btn_Next);
            this.Controls.Add(this.btn_Save);
            this.Controls.Add(this.gb_Habits);
            this.Controls.Add(this.gb_Physical_Attributes);
            this.Controls.Add(this.gb_More_Personal_Details);
            this.Controls.Add(this.panel1);
            this.Name = "frm_More_Details";
            this.Text = "frm_More_Details";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.gb_More_Personal_Details.ResumeLayout(false);
            this.gb_More_Personal_Details.PerformLayout();
            this.gb_Physical_Attributes.ResumeLayout(false);
            this.gb_Physical_Attributes.PerformLayout();
            this.gb_Habits.ResumeLayout(false);
            this.gb_Habits.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lbl_More_Personal_Details;
        private System.Windows.Forms.GroupBox gb_More_Personal_Details;
        private System.Windows.Forms.Label lbl_Marital_Status;
        private System.Windows.Forms.RadioButton radioButton4;
        private System.Windows.Forms.RadioButton radioButton3;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.ComboBox cmb_Residing_City;
        private System.Windows.Forms.ComboBox cmb_Residing_State;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox tb_Sub_Caste;
        private System.Windows.Forms.TextBox tb_Caste;
        private System.Windows.Forms.Label lbl_Residing_State;
        private System.Windows.Forms.Label lbl_Gothra;
        private System.Windows.Forms.Label lbl_Sub_Caste;
        private System.Windows.Forms.Label lbl_Caste;
        private System.Windows.Forms.Label lbl_Residing_City;
        private System.Windows.Forms.GroupBox gb_Physical_Attributes;
        private System.Windows.Forms.TextBox tb_Weight;
        private System.Windows.Forms.TextBox tb_Height;
        private System.Windows.Forms.RadioButton rb_Physically_Challenged;
        private System.Windows.Forms.RadioButton rb_normal;
        private System.Windows.Forms.RadioButton rb_Dark;
        private System.Windows.Forms.Label lbl_Physical_Status;
        private System.Windows.Forms.Label lbl_Complexion;
        private System.Windows.Forms.Label lbl_Body_Type;
        private System.Windows.Forms.Label lbl_Weight;
        private System.Windows.Forms.Label lbl_Height;
        private System.Windows.Forms.GroupBox gb_Habits;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.RadioButton rb_Yes_;
        private System.Windows.Forms.RadioButton rb_No_;
        private System.Windows.Forms.RadioButton rb_Drink_Socially;
        private System.Windows.Forms.RadioButton rb_Yes;
        private System.Windows.Forms.RadioButton rb_Occasionally;
        private System.Windows.Forms.RadioButton rb_No;
        private System.Windows.Forms.RadioButton rb_Eggetarian;
        private System.Windows.Forms.RadioButton rb_Non_Vegetarian;
        private System.Windows.Forms.Label lbl_Drinking;
        private System.Windows.Forms.Label lbl_Smoking;
        private System.Windows.Forms.RadioButton rb_Vegetarian;
        private System.Windows.Forms.Label lbl_Food;
        private System.Windows.Forms.ComboBox cmb_Complexion;
        private System.Windows.Forms.ComboBox cmb_Body_Type;
        private System.Windows.Forms.Button btn_Save;
        private System.Windows.Forms.Button btn_Next;
    }
}