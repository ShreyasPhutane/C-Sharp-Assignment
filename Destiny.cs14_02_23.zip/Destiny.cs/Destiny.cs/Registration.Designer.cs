﻿namespace Destiny.cs
{
    partial class frm_Registration
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.lbl_First_Step = new System.Windows.Forms.Label();
            this.lbl_Matrimony_Profile_For = new System.Windows.Forms.Label();
            this.lbl_ID = new System.Windows.Forms.Label();
            this.lbl_Name = new System.Windows.Forms.Label();
            this.lbl_Gender = new System.Windows.Forms.Label();
            this.lbl_DOB = new System.Windows.Forms.Label();
            this.lbl_Age = new System.Windows.Forms.Label();
            this.lbl_Religion = new System.Windows.Forms.Label();
            this.lbl_Addhar_No = new System.Windows.Forms.Label();
            this.lbl_Mother_Tounge = new System.Windows.Forms.Label();
            this.lbl_Caste = new System.Windows.Forms.Label();
            this.lbl_Mobile_No = new System.Windows.Forms.Label();
            this.lbl_Email = new System.Windows.Forms.Label();
            this.lbl_City = new System.Windows.Forms.Label();
            this.tb_Matrimonial_Profile_For = new System.Windows.Forms.TextBox();
            this.tb_ID = new System.Windows.Forms.TextBox();
            this.tb_Name = new System.Windows.Forms.TextBox();
            this.tb_Gender = new System.Windows.Forms.TextBox();
            this.tb_Age = new System.Windows.Forms.TextBox();
            this.tb_Religion = new System.Windows.Forms.TextBox();
            this.tb_Mother_Tounge = new System.Windows.Forms.TextBox();
            this.tb_Caste = new System.Windows.Forms.TextBox();
            this.tb_Mobile_No = new System.Windows.Forms.TextBox();
            this.tb_Email = new System.Windows.Forms.TextBox();
            this.tb_City = new System.Windows.Forms.TextBox();
            this.tb_Addhar_No = new System.Windows.Forms.TextBox();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel1.Controls.Add(this.lbl_First_Step);
            this.panel1.Location = new System.Drawing.Point(3, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1802, 104);
            this.panel1.TabIndex = 0;
            // 
            // lbl_First_Step
            // 
            this.lbl_First_Step.AutoSize = true;
            this.lbl_First_Step.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.lbl_First_Step.Font = new System.Drawing.Font("Times New Roman", 31.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_First_Step.ForeColor = System.Drawing.Color.Navy;
            this.lbl_First_Step.Location = new System.Drawing.Point(409, 17);
            this.lbl_First_Step.Name = "lbl_First_Step";
            this.lbl_First_Step.Size = new System.Drawing.Size(1021, 61);
            this.lbl_First_Step.TabIndex = 0;
            this.lbl_First_Step.Text = "Take The First Step To Your Happy Marriage";
            // 
            // lbl_Matrimony_Profile_For
            // 
            this.lbl_Matrimony_Profile_For.AutoSize = true;
            this.lbl_Matrimony_Profile_For.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Matrimony_Profile_For.ForeColor = System.Drawing.SystemColors.MenuText;
            this.lbl_Matrimony_Profile_For.Location = new System.Drawing.Point(374, 156);
            this.lbl_Matrimony_Profile_For.Name = "lbl_Matrimony_Profile_For";
            this.lbl_Matrimony_Profile_For.Size = new System.Drawing.Size(267, 33);
            this.lbl_Matrimony_Profile_For.TabIndex = 1;
            this.lbl_Matrimony_Profile_For.Text = "Matrimony Profile For";
            // 
            // lbl_ID
            // 
            this.lbl_ID.AutoSize = true;
            this.lbl_ID.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ID.Location = new System.Drawing.Point(374, 215);
            this.lbl_ID.Name = "lbl_ID";
            this.lbl_ID.Size = new System.Drawing.Size(43, 33);
            this.lbl_ID.TabIndex = 2;
            this.lbl_ID.Text = "ID";
            // 
            // lbl_Name
            // 
            this.lbl_Name.AutoSize = true;
            this.lbl_Name.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Name.Location = new System.Drawing.Point(374, 273);
            this.lbl_Name.Name = "lbl_Name";
            this.lbl_Name.Size = new System.Drawing.Size(79, 33);
            this.lbl_Name.TabIndex = 3;
            this.lbl_Name.Text = "Name";
            // 
            // lbl_Gender
            // 
            this.lbl_Gender.AutoSize = true;
            this.lbl_Gender.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Gender.Location = new System.Drawing.Point(374, 333);
            this.lbl_Gender.Name = "lbl_Gender";
            this.lbl_Gender.Size = new System.Drawing.Size(95, 33);
            this.lbl_Gender.TabIndex = 4;
            this.lbl_Gender.Text = "Gender";
            // 
            // lbl_DOB
            // 
            this.lbl_DOB.AutoSize = true;
            this.lbl_DOB.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_DOB.Location = new System.Drawing.Point(982, 333);
            this.lbl_DOB.Name = "lbl_DOB";
            this.lbl_DOB.Size = new System.Drawing.Size(74, 33);
            this.lbl_DOB.TabIndex = 5;
            this.lbl_DOB.Text = "DOB";
            // 
            // lbl_Age
            // 
            this.lbl_Age.AutoSize = true;
            this.lbl_Age.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Age.Location = new System.Drawing.Point(374, 396);
            this.lbl_Age.Name = "lbl_Age";
            this.lbl_Age.Size = new System.Drawing.Size(59, 33);
            this.lbl_Age.TabIndex = 6;
            this.lbl_Age.Text = "Age";
            // 
            // lbl_Religion
            // 
            this.lbl_Religion.AutoSize = true;
            this.lbl_Religion.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Religion.Location = new System.Drawing.Point(374, 452);
            this.lbl_Religion.Name = "lbl_Religion";
            this.lbl_Religion.Size = new System.Drawing.Size(111, 33);
            this.lbl_Religion.TabIndex = 7;
            this.lbl_Religion.Text = "Religion";
            // 
            // lbl_Addhar_No
            // 
            this.lbl_Addhar_No.AutoSize = true;
            this.lbl_Addhar_No.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Addhar_No.Location = new System.Drawing.Point(982, 393);
            this.lbl_Addhar_No.Name = "lbl_Addhar_No";
            this.lbl_Addhar_No.Size = new System.Drawing.Size(152, 33);
            this.lbl_Addhar_No.TabIndex = 8;
            this.lbl_Addhar_No.Text = "Addhar  No.";
            // 
            // lbl_Mother_Tounge
            // 
            this.lbl_Mother_Tounge.AutoSize = true;
            this.lbl_Mother_Tounge.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Mother_Tounge.Location = new System.Drawing.Point(374, 503);
            this.lbl_Mother_Tounge.Name = "lbl_Mother_Tounge";
            this.lbl_Mother_Tounge.Size = new System.Drawing.Size(198, 33);
            this.lbl_Mother_Tounge.TabIndex = 9;
            this.lbl_Mother_Tounge.Text = "Mother Toungue";
            // 
            // lbl_Caste
            // 
            this.lbl_Caste.AutoSize = true;
            this.lbl_Caste.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Caste.Location = new System.Drawing.Point(374, 556);
            this.lbl_Caste.Name = "lbl_Caste";
            this.lbl_Caste.Size = new System.Drawing.Size(77, 33);
            this.lbl_Caste.TabIndex = 10;
            this.lbl_Caste.Text = "Caste";
            // 
            // lbl_Mobile_No
            // 
            this.lbl_Mobile_No.AutoSize = true;
            this.lbl_Mobile_No.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Mobile_No.Location = new System.Drawing.Point(374, 608);
            this.lbl_Mobile_No.Name = "lbl_Mobile_No";
            this.lbl_Mobile_No.Size = new System.Drawing.Size(144, 33);
            this.lbl_Mobile_No.TabIndex = 11;
            this.lbl_Mobile_No.Text = "Mobile No.";
            // 
            // lbl_Email
            // 
            this.lbl_Email.AutoSize = true;
            this.lbl_Email.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Email.Location = new System.Drawing.Point(374, 657);
            this.lbl_Email.Name = "lbl_Email";
            this.lbl_Email.Size = new System.Drawing.Size(80, 33);
            this.lbl_Email.TabIndex = 12;
            this.lbl_Email.Text = "Email";
            // 
            // lbl_City
            // 
            this.lbl_City.AutoSize = true;
            this.lbl_City.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_City.Location = new System.Drawing.Point(374, 705);
            this.lbl_City.Name = "lbl_City";
            this.lbl_City.Size = new System.Drawing.Size(63, 33);
            this.lbl_City.TabIndex = 13;
            this.lbl_City.Text = "City";
            // 
            // tb_Matrimonial_Profile_For
            // 
            this.tb_Matrimonial_Profile_For.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Matrimonial_Profile_For.Location = new System.Drawing.Point(704, 153);
            this.tb_Matrimonial_Profile_For.Name = "tb_Matrimonial_Profile_For";
            this.tb_Matrimonial_Profile_For.Size = new System.Drawing.Size(257, 39);
            this.tb_Matrimonial_Profile_For.TabIndex = 1;
            // 
            // tb_ID
            // 
            this.tb_ID.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_ID.Location = new System.Drawing.Point(704, 209);
            this.tb_ID.Name = "tb_ID";
            this.tb_ID.Size = new System.Drawing.Size(257, 39);
            this.tb_ID.TabIndex = 2;
            // 
            // tb_Name
            // 
            this.tb_Name.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Name.Location = new System.Drawing.Point(704, 273);
            this.tb_Name.Name = "tb_Name";
            this.tb_Name.Size = new System.Drawing.Size(257, 39);
            this.tb_Name.TabIndex = 3;
            // 
            // tb_Gender
            // 
            this.tb_Gender.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Gender.Location = new System.Drawing.Point(704, 327);
            this.tb_Gender.Name = "tb_Gender";
            this.tb_Gender.Size = new System.Drawing.Size(156, 39);
            this.tb_Gender.TabIndex = 4;
            // 
            // tb_Age
            // 
            this.tb_Age.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Age.Location = new System.Drawing.Point(704, 390);
            this.tb_Age.Name = "tb_Age";
            this.tb_Age.Size = new System.Drawing.Size(156, 39);
            this.tb_Age.TabIndex = 6;
            // 
            // tb_Religion
            // 
            this.tb_Religion.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Religion.Location = new System.Drawing.Point(704, 446);
            this.tb_Religion.Name = "tb_Religion";
            this.tb_Religion.Size = new System.Drawing.Size(156, 39);
            this.tb_Religion.TabIndex = 8;
            // 
            // tb_Mother_Tounge
            // 
            this.tb_Mother_Tounge.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Mother_Tounge.Location = new System.Drawing.Point(704, 503);
            this.tb_Mother_Tounge.Name = "tb_Mother_Tounge";
            this.tb_Mother_Tounge.Size = new System.Drawing.Size(156, 39);
            this.tb_Mother_Tounge.TabIndex = 9;
            // 
            // tb_Caste
            // 
            this.tb_Caste.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Caste.Location = new System.Drawing.Point(704, 553);
            this.tb_Caste.Name = "tb_Caste";
            this.tb_Caste.Size = new System.Drawing.Size(156, 39);
            this.tb_Caste.TabIndex = 10;
            // 
            // tb_Mobile_No
            // 
            this.tb_Mobile_No.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Mobile_No.Location = new System.Drawing.Point(704, 608);
            this.tb_Mobile_No.Name = "tb_Mobile_No";
            this.tb_Mobile_No.Size = new System.Drawing.Size(156, 39);
            this.tb_Mobile_No.TabIndex = 11;
            // 
            // tb_Email
            // 
            this.tb_Email.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Email.Location = new System.Drawing.Point(704, 657);
            this.tb_Email.Name = "tb_Email";
            this.tb_Email.Size = new System.Drawing.Size(367, 39);
            this.tb_Email.TabIndex = 12;
            // 
            // tb_City
            // 
            this.tb_City.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_City.Location = new System.Drawing.Point(704, 705);
            this.tb_City.Name = "tb_City";
            this.tb_City.Size = new System.Drawing.Size(165, 39);
            this.tb_City.TabIndex = 13;
            // 
            // tb_Addhar_No
            // 
            this.tb_Addhar_No.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Addhar_No.Location = new System.Drawing.Point(1178, 387);
            this.tb_Addhar_No.Name = "tb_Addhar_No";
            this.tb_Addhar_No.Size = new System.Drawing.Size(271, 39);
            this.tb_Addhar_No.TabIndex = 7;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.CalendarFont = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker1.Location = new System.Drawing.Point(1178, 325);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(267, 38);
            this.dateTimePicker1.TabIndex = 5;
            // 
            // frm_Registration
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ClientSize = new System.Drawing.Size(1813, 867);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.tb_Addhar_No);
            this.Controls.Add(this.tb_City);
            this.Controls.Add(this.tb_Email);
            this.Controls.Add(this.tb_Mobile_No);
            this.Controls.Add(this.tb_Caste);
            this.Controls.Add(this.tb_Mother_Tounge);
            this.Controls.Add(this.tb_Religion);
            this.Controls.Add(this.tb_Age);
            this.Controls.Add(this.tb_Gender);
            this.Controls.Add(this.tb_Name);
            this.Controls.Add(this.tb_ID);
            this.Controls.Add(this.tb_Matrimonial_Profile_For);
            this.Controls.Add(this.lbl_City);
            this.Controls.Add(this.lbl_Email);
            this.Controls.Add(this.lbl_Mobile_No);
            this.Controls.Add(this.lbl_Caste);
            this.Controls.Add(this.lbl_Mother_Tounge);
            this.Controls.Add(this.lbl_Addhar_No);
            this.Controls.Add(this.lbl_Religion);
            this.Controls.Add(this.lbl_Age);
            this.Controls.Add(this.lbl_DOB);
            this.Controls.Add(this.lbl_Gender);
            this.Controls.Add(this.lbl_Name);
            this.Controls.Add(this.lbl_ID);
            this.Controls.Add(this.lbl_Matrimony_Profile_For);
            this.Controls.Add(this.panel1);
            this.Name = "frm_Registration";
            this.Text = "Registration";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lbl_First_Step;
        private System.Windows.Forms.Label lbl_Matrimony_Profile_For;
        private System.Windows.Forms.Label lbl_ID;
        private System.Windows.Forms.Label lbl_Name;
        private System.Windows.Forms.Label lbl_Gender;
        private System.Windows.Forms.Label lbl_DOB;
        private System.Windows.Forms.Label lbl_Age;
        private System.Windows.Forms.Label lbl_Religion;
        private System.Windows.Forms.Label lbl_Addhar_No;
        private System.Windows.Forms.Label lbl_Mother_Tounge;
        private System.Windows.Forms.Label lbl_Caste;
        private System.Windows.Forms.Label lbl_Mobile_No;
        private System.Windows.Forms.Label lbl_Email;
        private System.Windows.Forms.Label lbl_City;
        private System.Windows.Forms.TextBox tb_Matrimonial_Profile_For;
        private System.Windows.Forms.TextBox tb_ID;
        private System.Windows.Forms.TextBox tb_Name;
        private System.Windows.Forms.TextBox tb_Gender;
        private System.Windows.Forms.TextBox tb_Age;
        private System.Windows.Forms.TextBox tb_Religion;
        private System.Windows.Forms.TextBox tb_Mother_Tounge;
        private System.Windows.Forms.TextBox tb_Caste;
        private System.Windows.Forms.TextBox tb_Mobile_No;
        private System.Windows.Forms.TextBox tb_Email;
        private System.Windows.Forms.TextBox tb_City;
        private System.Windows.Forms.TextBox tb_Addhar_No;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
    }
}