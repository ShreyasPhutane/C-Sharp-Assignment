﻿namespace Destiny.cs
{
    partial class Frm_Create_Profile
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_Client = new System.Windows.Forms.Button();
            this.btn_Friend = new System.Windows.Forms.Button();
            this.btn_Relative = new System.Windows.Forms.Button();
            this.btn_Sister = new System.Windows.Forms.Button();
            this.btn_Brother = new System.Windows.Forms.Button();
            this.btn_Daughter = new System.Windows.Forms.Button();
            this.btn_Son = new System.Windows.Forms.Button();
            this.btn_self = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.pb_Log_Out = new System.Windows.Forms.PictureBox();
            this.pb_Client = new System.Windows.Forms.PictureBox();
            this.pb_Friend = new System.Windows.Forms.PictureBox();
            this.pb_Relative = new System.Windows.Forms.PictureBox();
            this.pb_Sister = new System.Windows.Forms.PictureBox();
            this.pb_Brother = new System.Windows.Forms.PictureBox();
            this.pb_Daughter = new System.Windows.Forms.PictureBox();
            this.pb_son = new System.Windows.Forms.PictureBox();
            this.pb_Self = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Log_Out)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Client)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Friend)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Relative)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Sister)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Brother)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Daughter)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_son)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Self)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.SuspendLayout();
            // 
            // btn_Client
            // 
            this.btn_Client.BackColor = System.Drawing.SystemColors.ControlDark;
            this.btn_Client.Font = new System.Drawing.Font("Times New Roman", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Client.Location = new System.Drawing.Point(1283, 787);
            this.btn_Client.Name = "btn_Client";
            this.btn_Client.Size = new System.Drawing.Size(132, 43);
            this.btn_Client.TabIndex = 26;
            this.btn_Client.Text = "Client ";
            this.btn_Client.UseVisualStyleBackColor = false;
            // 
            // btn_Friend
            // 
            this.btn_Friend.BackColor = System.Drawing.SystemColors.ControlDark;
            this.btn_Friend.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Friend.Location = new System.Drawing.Point(900, 787);
            this.btn_Friend.Name = "btn_Friend";
            this.btn_Friend.Size = new System.Drawing.Size(109, 43);
            this.btn_Friend.TabIndex = 24;
            this.btn_Friend.Text = "Friend";
            this.btn_Friend.UseVisualStyleBackColor = false;
            // 
            // btn_Relative
            // 
            this.btn_Relative.BackColor = System.Drawing.SystemColors.ControlDark;
            this.btn_Relative.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Relative.Location = new System.Drawing.Point(555, 790);
            this.btn_Relative.Name = "btn_Relative";
            this.btn_Relative.Size = new System.Drawing.Size(138, 40);
            this.btn_Relative.TabIndex = 22;
            this.btn_Relative.Text = "Relative";
            this.btn_Relative.UseVisualStyleBackColor = false;
            // 
            // btn_Sister
            // 
            this.btn_Sister.BackColor = System.Drawing.SystemColors.ControlDark;
            this.btn_Sister.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Sister.Location = new System.Drawing.Point(180, 790);
            this.btn_Sister.Name = "btn_Sister";
            this.btn_Sister.Size = new System.Drawing.Size(135, 43);
            this.btn_Sister.TabIndex = 20;
            this.btn_Sister.Text = "Sister";
            this.btn_Sister.UseVisualStyleBackColor = false;
            // 
            // btn_Brother
            // 
            this.btn_Brother.BackColor = System.Drawing.SystemColors.ControlDark;
            this.btn_Brother.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Brother.Location = new System.Drawing.Point(1283, 492);
            this.btn_Brother.Name = "btn_Brother";
            this.btn_Brother.Size = new System.Drawing.Size(120, 46);
            this.btn_Brother.TabIndex = 18;
            this.btn_Brother.Text = "Brother";
            this.btn_Brother.UseVisualStyleBackColor = false;
            // 
            // btn_Daughter
            // 
            this.btn_Daughter.BackColor = System.Drawing.SystemColors.ControlDark;
            this.btn_Daughter.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Daughter.Location = new System.Drawing.Point(900, 496);
            this.btn_Daughter.Name = "btn_Daughter";
            this.btn_Daughter.Size = new System.Drawing.Size(136, 43);
            this.btn_Daughter.TabIndex = 16;
            this.btn_Daughter.Text = "Daughter";
            this.btn_Daughter.UseVisualStyleBackColor = false;
            // 
            // btn_Son
            // 
            this.btn_Son.BackColor = System.Drawing.SystemColors.ControlDark;
            this.btn_Son.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Son.Location = new System.Drawing.Point(567, 492);
            this.btn_Son.Name = "btn_Son";
            this.btn_Son.Size = new System.Drawing.Size(91, 47);
            this.btn_Son.TabIndex = 15;
            this.btn_Son.Text = "Son";
            this.btn_Son.UseVisualStyleBackColor = false;
            // 
            // btn_self
            // 
            this.btn_self.BackColor = System.Drawing.SystemColors.ControlDark;
            this.btn_self.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_self.Location = new System.Drawing.Point(195, 494);
            this.btn_self.Name = "btn_self";
            this.btn_self.Size = new System.Drawing.Size(97, 45);
            this.btn_self.TabIndex = 13;
            this.btn_self.Text = "Self";
            this.btn_self.UseVisualStyleBackColor = false;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(399, 179);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1028, 84);
            this.panel1.TabIndex = 19;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 30F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Navy;
            this.label1.Location = new System.Drawing.Point(296, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(405, 57);
            this.label1.TabIndex = 0;
            this.label1.Text = "Create Profile For";
            // 
            // pb_Log_Out
            // 
            this.pb_Log_Out.Image = global::Destiny.cs.Properties.Resources.gnome_panel_force_quit;
            this.pb_Log_Out.Location = new System.Drawing.Point(1558, 110);
            this.pb_Log_Out.Name = "pb_Log_Out";
            this.pb_Log_Out.Size = new System.Drawing.Size(78, 61);
            this.pb_Log_Out.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb_Log_Out.TabIndex = 32;
            this.pb_Log_Out.TabStop = false;
            // 
            // pb_Client
            // 
            this.pb_Client.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.pb_Client.Image = global::Destiny.cs.Properties.Resources.images__2_;
            this.pb_Client.Location = new System.Drawing.Point(1265, 621);
            this.pb_Client.Name = "pb_Client";
            this.pb_Client.Size = new System.Drawing.Size(162, 144);
            this.pb_Client.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb_Client.TabIndex = 31;
            this.pb_Client.TabStop = false;
            // 
            // pb_Friend
            // 
            this.pb_Friend.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.pb_Friend.Image = global::Destiny.cs.Properties.Resources.download;
            this.pb_Friend.Location = new System.Drawing.Point(874, 621);
            this.pb_Friend.Name = "pb_Friend";
            this.pb_Friend.Size = new System.Drawing.Size(162, 144);
            this.pb_Friend.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb_Friend.TabIndex = 30;
            this.pb_Friend.TabStop = false;
            // 
            // pb_Relative
            // 
            this.pb_Relative.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.pb_Relative.Image = global::Destiny.cs.Properties.Resources.png_clipart_person_logo_people_travel_text_rectangle;
            this.pb_Relative.Location = new System.Drawing.Point(531, 621);
            this.pb_Relative.Name = "pb_Relative";
            this.pb_Relative.Size = new System.Drawing.Size(162, 144);
            this.pb_Relative.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb_Relative.TabIndex = 29;
            this.pb_Relative.TabStop = false;
            // 
            // pb_Sister
            // 
            this.pb_Sister.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.pb_Sister.Image = global::Destiny.cs.Properties.Resources.png_transparent_female_woman_search_people_logo_black;
            this.pb_Sister.Location = new System.Drawing.Point(166, 621);
            this.pb_Sister.Name = "pb_Sister";
            this.pb_Sister.Size = new System.Drawing.Size(162, 144);
            this.pb_Sister.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb_Sister.TabIndex = 28;
            this.pb_Sister.TabStop = false;
            // 
            // pb_Brother
            // 
            this.pb_Brother.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.pb_Brother.Image = global::Destiny.cs.Properties.Resources.images__1_;
            this.pb_Brother.Location = new System.Drawing.Point(1265, 328);
            this.pb_Brother.Name = "pb_Brother";
            this.pb_Brother.Size = new System.Drawing.Size(162, 144);
            this.pb_Brother.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb_Brother.TabIndex = 27;
            this.pb_Brother.TabStop = false;
            // 
            // pb_Daughter
            // 
            this.pb_Daughter.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.pb_Daughter.Image = global::Destiny.cs.Properties.Resources.Venus_symbol_svg;
            this.pb_Daughter.Location = new System.Drawing.Point(874, 328);
            this.pb_Daughter.Name = "pb_Daughter";
            this.pb_Daughter.Size = new System.Drawing.Size(162, 144);
            this.pb_Daughter.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb_Daughter.TabIndex = 25;
            this.pb_Daughter.TabStop = false;
            // 
            // pb_son
            // 
            this.pb_son.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.pb_son.Image = global::Destiny.cs.Properties.Resources.Mars_symbol_svg;
            this.pb_son.Location = new System.Drawing.Point(531, 328);
            this.pb_son.Name = "pb_son";
            this.pb_son.Size = new System.Drawing.Size(162, 144);
            this.pb_son.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb_son.TabIndex = 23;
            this.pb_son.TabStop = false;
            // 
            // pb_Self
            // 
            this.pb_Self.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.pb_Self.ErrorImage = null;
            this.pb_Self.Image = global::Destiny.cs.Properties.Resources.images;
            this.pb_Self.Location = new System.Drawing.Point(166, 328);
            this.pb_Self.Name = "pb_Self";
            this.pb_Self.Size = new System.Drawing.Size(162, 144);
            this.pb_Self.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb_Self.TabIndex = 21;
            this.pb_Self.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::Destiny.cs.Properties.Resources._240_F_249970957_tuBtAHEXSTyetIRq5bA2htD955XU5Nup;
            this.pictureBox4.Location = new System.Drawing.Point(865, 2);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(935, 111);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 17;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::Destiny.cs.Properties.Resources._240_F_249970957_tuBtAHEXSTyetIRq5bA2htD955XU5Nup;
            this.pictureBox3.Location = new System.Drawing.Point(-10, 2);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(876, 111);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 14;
            this.pictureBox3.TabStop = false;
            // 
            // Frm_Create_Profile
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ClientSize = new System.Drawing.Size(1780, 881);
            this.Controls.Add(this.pb_Log_Out);
            this.Controls.Add(this.btn_Client);
            this.Controls.Add(this.btn_Friend);
            this.Controls.Add(this.btn_Relative);
            this.Controls.Add(this.btn_Sister);
            this.Controls.Add(this.btn_Brother);
            this.Controls.Add(this.btn_Daughter);
            this.Controls.Add(this.btn_Son);
            this.Controls.Add(this.btn_self);
            this.Controls.Add(this.pb_Client);
            this.Controls.Add(this.pb_Friend);
            this.Controls.Add(this.pb_Relative);
            this.Controls.Add(this.pb_Sister);
            this.Controls.Add(this.pb_Brother);
            this.Controls.Add(this.pb_Daughter);
            this.Controls.Add(this.pb_son);
            this.Controls.Add(this.pb_Self);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.pictureBox3);
            this.Name = "Frm_Create_Profile";
            this.Text = "Frm_Create_Profile";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Log_Out)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Client)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Friend)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Relative)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Sister)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Brother)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Daughter)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_son)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Self)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_Client;
        private System.Windows.Forms.Button btn_Friend;
        private System.Windows.Forms.Button btn_Relative;
        private System.Windows.Forms.Button btn_Sister;
        private System.Windows.Forms.Button btn_Brother;
        private System.Windows.Forms.Button btn_Daughter;
        private System.Windows.Forms.Button btn_Son;
        private System.Windows.Forms.Button btn_self;
        private System.Windows.Forms.PictureBox pb_Client;
        private System.Windows.Forms.PictureBox pb_Friend;
        private System.Windows.Forms.PictureBox pb_Relative;
        private System.Windows.Forms.PictureBox pb_Sister;
        private System.Windows.Forms.PictureBox pb_Brother;
        private System.Windows.Forms.PictureBox pb_Daughter;
        private System.Windows.Forms.PictureBox pb_son;
        private System.Windows.Forms.PictureBox pb_Self;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pb_Log_Out;
    }
}