﻿namespace Destiny.cs
{
    partial class Frm_Create_Profile_For
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btn_Brother = new System.Windows.Forms.Button();
            this.btn_Daughter = new System.Windows.Forms.Button();
            this.btn_Son = new System.Windows.Forms.Button();
            this.pb_Client = new System.Windows.Forms.PictureBox();
            this.pb_Friend = new System.Windows.Forms.PictureBox();
            this.pb_Relative = new System.Windows.Forms.PictureBox();
            this.pb_Sister = new System.Windows.Forms.PictureBox();
            this.pb_Brother = new System.Windows.Forms.PictureBox();
            this.pb_Daughter = new System.Windows.Forms.PictureBox();
            this.pb_son = new System.Windows.Forms.PictureBox();
            this.pb_Self = new System.Windows.Forms.PictureBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.btn_self = new System.Windows.Forms.Button();
            this.btn_Sister = new System.Windows.Forms.Button();
            this.btn_Relative = new System.Windows.Forms.Button();
            this.btn_Friend = new System.Windows.Forms.Button();
            this.btn_Client = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Client)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Friend)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Relative)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Sister)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Brother)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Daughter)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_son)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Self)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::Destiny.cs.Properties.Resources._240_F_249970957_tuBtAHEXSTyetIRq5bA2htD955XU5Nup;
            this.pictureBox3.Location = new System.Drawing.Point(-1, -2);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(790, 111);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 15;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Destiny.cs.Properties.Resources._240_F_249970957_tuBtAHEXSTyetIRq5bA2htD955XU5Nup;
            this.pictureBox1.Location = new System.Drawing.Point(783, -2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(705, 111);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 16;
            this.pictureBox1.TabStop = false;
            // 
            // btn_Brother
            // 
            this.btn_Brother.BackColor = System.Drawing.Color.LightCoral;
            this.btn_Brother.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Brother.Location = new System.Drawing.Point(1195, 414);
            this.btn_Brother.Name = "btn_Brother";
            this.btn_Brother.Size = new System.Drawing.Size(162, 47);
            this.btn_Brother.TabIndex = 34;
            this.btn_Brother.Text = "Brother";
            this.btn_Brother.UseVisualStyleBackColor = false;
            this.btn_Brother.Click += new System.EventHandler(this.btn_Brother_Click);
            // 
            // btn_Daughter
            // 
            this.btn_Daughter.BackColor = System.Drawing.Color.LightCoral;
            this.btn_Daughter.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Daughter.Location = new System.Drawing.Point(818, 414);
            this.btn_Daughter.Name = "btn_Daughter";
            this.btn_Daughter.Size = new System.Drawing.Size(154, 47);
            this.btn_Daughter.TabIndex = 33;
            this.btn_Daughter.Text = "Daughter";
            this.btn_Daughter.UseVisualStyleBackColor = false;
            this.btn_Daughter.Click += new System.EventHandler(this.btn_Daughter_Click);
            // 
            // btn_Son
            // 
            this.btn_Son.BackColor = System.Drawing.Color.LightCoral;
            this.btn_Son.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Son.Location = new System.Drawing.Point(461, 414);
            this.btn_Son.Name = "btn_Son";
            this.btn_Son.Size = new System.Drawing.Size(162, 47);
            this.btn_Son.TabIndex = 32;
            this.btn_Son.Text = "Son";
            this.btn_Son.UseVisualStyleBackColor = false;
            this.btn_Son.Click += new System.EventHandler(this.btn_Son_Click);
            // 
            // pb_Client
            // 
            this.pb_Client.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.pb_Client.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pb_Client.Image = global::Destiny.cs.Properties.Resources.images__2_;
            this.pb_Client.Location = new System.Drawing.Point(1195, 506);
            this.pb_Client.Name = "pb_Client";
            this.pb_Client.Size = new System.Drawing.Size(162, 144);
            this.pb_Client.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb_Client.TabIndex = 43;
            this.pb_Client.TabStop = false;
            // 
            // pb_Friend
            // 
            this.pb_Friend.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.pb_Friend.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pb_Friend.Image = global::Destiny.cs.Properties.Resources.download;
            this.pb_Friend.Location = new System.Drawing.Point(818, 506);
            this.pb_Friend.Name = "pb_Friend";
            this.pb_Friend.Size = new System.Drawing.Size(162, 144);
            this.pb_Friend.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb_Friend.TabIndex = 42;
            this.pb_Friend.TabStop = false;
            // 
            // pb_Relative
            // 
            this.pb_Relative.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.pb_Relative.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pb_Relative.Image = global::Destiny.cs.Properties.Resources.png_clipart_person_logo_people_travel_text_rectangle;
            this.pb_Relative.Location = new System.Drawing.Point(461, 506);
            this.pb_Relative.Name = "pb_Relative";
            this.pb_Relative.Size = new System.Drawing.Size(162, 144);
            this.pb_Relative.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb_Relative.TabIndex = 41;
            this.pb_Relative.TabStop = false;
            // 
            // pb_Sister
            // 
            this.pb_Sister.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.pb_Sister.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pb_Sister.Image = global::Destiny.cs.Properties.Resources.png_transparent_female_woman_search_people_logo_black;
            this.pb_Sister.Location = new System.Drawing.Point(96, 506);
            this.pb_Sister.Name = "pb_Sister";
            this.pb_Sister.Size = new System.Drawing.Size(162, 144);
            this.pb_Sister.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb_Sister.TabIndex = 40;
            this.pb_Sister.TabStop = false;
            // 
            // pb_Brother
            // 
            this.pb_Brother.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.pb_Brother.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pb_Brother.Image = global::Destiny.cs.Properties.Resources.images__1_;
            this.pb_Brother.Location = new System.Drawing.Point(1195, 246);
            this.pb_Brother.Name = "pb_Brother";
            this.pb_Brother.Size = new System.Drawing.Size(162, 144);
            this.pb_Brother.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb_Brother.TabIndex = 39;
            this.pb_Brother.TabStop = false;
            // 
            // pb_Daughter
            // 
            this.pb_Daughter.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.pb_Daughter.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pb_Daughter.Image = global::Destiny.cs.Properties.Resources.Venus_symbol_svg;
            this.pb_Daughter.Location = new System.Drawing.Point(818, 246);
            this.pb_Daughter.Name = "pb_Daughter";
            this.pb_Daughter.Size = new System.Drawing.Size(162, 144);
            this.pb_Daughter.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb_Daughter.TabIndex = 38;
            this.pb_Daughter.TabStop = false;
            // 
            // pb_son
            // 
            this.pb_son.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.pb_son.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pb_son.Image = global::Destiny.cs.Properties.Resources.Mars_symbol_svg;
            this.pb_son.Location = new System.Drawing.Point(461, 246);
            this.pb_son.Name = "pb_son";
            this.pb_son.Size = new System.Drawing.Size(162, 144);
            this.pb_son.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb_son.TabIndex = 37;
            this.pb_son.TabStop = false;
            // 
            // pb_Self
            // 
            this.pb_Self.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.pb_Self.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pb_Self.ErrorImage = null;
            this.pb_Self.Image = global::Destiny.cs.Properties.Resources.images;
            this.pb_Self.Location = new System.Drawing.Point(96, 246);
            this.pb_Self.Name = "pb_Self";
            this.pb_Self.Size = new System.Drawing.Size(162, 144);
            this.pb_Self.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb_Self.TabIndex = 36;
            this.pb_Self.TabStop = false;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(221, 125);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1028, 84);
            this.panel1.TabIndex = 35;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 30F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Navy;
            this.label1.Location = new System.Drawing.Point(321, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(405, 57);
            this.label1.TabIndex = 0;
            this.label1.Text = "Create Profile For";
            // 
            // btn_self
            // 
            this.btn_self.BackColor = System.Drawing.Color.LightCoral;
            this.btn_self.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_self.Location = new System.Drawing.Point(96, 414);
            this.btn_self.Name = "btn_self";
            this.btn_self.Size = new System.Drawing.Size(162, 47);
            this.btn_self.TabIndex = 44;
            this.btn_self.Text = "Self";
            this.btn_self.UseVisualStyleBackColor = false;
            this.btn_self.Click += new System.EventHandler(this.btn_self_Click);
            // 
            // btn_Sister
            // 
            this.btn_Sister.BackColor = System.Drawing.Color.LightCoral;
            this.btn_Sister.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Sister.Location = new System.Drawing.Point(96, 668);
            this.btn_Sister.Name = "btn_Sister";
            this.btn_Sister.Size = new System.Drawing.Size(162, 51);
            this.btn_Sister.TabIndex = 45;
            this.btn_Sister.Text = "Sister";
            this.btn_Sister.UseVisualStyleBackColor = false;
            this.btn_Sister.Click += new System.EventHandler(this.btn_Sister_Click);
            // 
            // btn_Relative
            // 
            this.btn_Relative.BackColor = System.Drawing.Color.LightCoral;
            this.btn_Relative.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Relative.Location = new System.Drawing.Point(475, 668);
            this.btn_Relative.Name = "btn_Relative";
            this.btn_Relative.Size = new System.Drawing.Size(148, 51);
            this.btn_Relative.TabIndex = 46;
            this.btn_Relative.Text = "Relative";
            this.btn_Relative.UseVisualStyleBackColor = false;
            this.btn_Relative.Click += new System.EventHandler(this.btn_Relative_Click);
            // 
            // btn_Friend
            // 
            this.btn_Friend.BackColor = System.Drawing.Color.LightCoral;
            this.btn_Friend.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Friend.Location = new System.Drawing.Point(818, 668);
            this.btn_Friend.Name = "btn_Friend";
            this.btn_Friend.Size = new System.Drawing.Size(162, 51);
            this.btn_Friend.TabIndex = 47;
            this.btn_Friend.Text = "Friend";
            this.btn_Friend.UseVisualStyleBackColor = false;
            this.btn_Friend.Click += new System.EventHandler(this.btn_Friend_Click);
            // 
            // btn_Client
            // 
            this.btn_Client.BackColor = System.Drawing.Color.LightCoral;
            this.btn_Client.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Client.Location = new System.Drawing.Point(1195, 668);
            this.btn_Client.Name = "btn_Client";
            this.btn_Client.Size = new System.Drawing.Size(162, 51);
            this.btn_Client.TabIndex = 48;
            this.btn_Client.Text = "Client ";
            this.btn_Client.UseVisualStyleBackColor = false;
            this.btn_Client.Click += new System.EventHandler(this.btn_Client_Click);
            // 
            // Frm_Create_Profile_For
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ClientSize = new System.Drawing.Size(1482, 753);
            this.Controls.Add(this.btn_Client);
            this.Controls.Add(this.btn_Friend);
            this.Controls.Add(this.btn_Relative);
            this.Controls.Add(this.btn_Sister);
            this.Controls.Add(this.btn_self);
            this.Controls.Add(this.btn_Brother);
            this.Controls.Add(this.btn_Daughter);
            this.Controls.Add(this.btn_Son);
            this.Controls.Add(this.pb_Client);
            this.Controls.Add(this.pb_Friend);
            this.Controls.Add(this.pb_Relative);
            this.Controls.Add(this.pb_Sister);
            this.Controls.Add(this.pb_Brother);
            this.Controls.Add(this.pb_Daughter);
            this.Controls.Add(this.pb_son);
            this.Controls.Add(this.pb_Self);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.pictureBox3);
            this.Name = "Frm_Create_Profile_For";
            this.Text = "Create Profile For";
            this.Load += new System.EventHandler(this.Frm_Create_Profile_For_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Client)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Friend)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Relative)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Sister)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Brother)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Daughter)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_son)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Self)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button btn_Brother;
        private System.Windows.Forms.Button btn_Daughter;
        private System.Windows.Forms.Button btn_Son;
        private System.Windows.Forms.PictureBox pb_Client;
        private System.Windows.Forms.PictureBox pb_Friend;
        private System.Windows.Forms.PictureBox pb_Relative;
        private System.Windows.Forms.PictureBox pb_Sister;
        private System.Windows.Forms.PictureBox pb_Brother;
        private System.Windows.Forms.PictureBox pb_Daughter;
        private System.Windows.Forms.PictureBox pb_son;
        private System.Windows.Forms.PictureBox pb_Self;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btn_self;
        private System.Windows.Forms.Button btn_Sister;
        private System.Windows.Forms.Button btn_Relative;
        private System.Windows.Forms.Button btn_Friend;
        private System.Windows.Forms.Button btn_Client;
    }
}