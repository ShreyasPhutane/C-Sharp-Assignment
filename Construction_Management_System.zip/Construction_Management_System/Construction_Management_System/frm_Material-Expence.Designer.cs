﻿namespace Construction_Management_System
{
    partial class frm_Material_Expence
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_Material_Expence_Details = new System.Windows.Forms.Label();
            this.lbl_Used_ID = new System.Windows.Forms.Label();
            this.lbl_Site_Name = new System.Windows.Forms.Label();
            this.lbl_Material_Name = new System.Windows.Forms.Label();
            this.lbl_Material_Used = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lbl_Material_Expence_Details
            // 
            this.lbl_Material_Expence_Details.AutoSize = true;
            this.lbl_Material_Expence_Details.Font = new System.Drawing.Font("Cambria", 30F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Material_Expence_Details.Location = new System.Drawing.Point(201, 40);
            this.lbl_Material_Expence_Details.Name = "lbl_Material_Expence_Details";
            this.lbl_Material_Expence_Details.Size = new System.Drawing.Size(707, 59);
            this.lbl_Material_Expence_Details.TabIndex = 0;
            this.lbl_Material_Expence_Details.Text = "MATERIAL  EXPENCE DETAILS";
            // 
            // lbl_Used_ID
            // 
            this.lbl_Used_ID.AutoSize = true;
            this.lbl_Used_ID.Font = new System.Drawing.Font("Cambria", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Used_ID.Location = new System.Drawing.Point(139, 177);
            this.lbl_Used_ID.Name = "lbl_Used_ID";
            this.lbl_Used_ID.Size = new System.Drawing.Size(144, 40);
            this.lbl_Used_ID.TabIndex = 1;
            this.lbl_Used_ID.Text = "USED ID";
            // 
            // lbl_Site_Name
            // 
            this.lbl_Site_Name.AutoSize = true;
            this.lbl_Site_Name.Font = new System.Drawing.Font("Cambria", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Site_Name.Location = new System.Drawing.Point(139, 275);
            this.lbl_Site_Name.Name = "lbl_Site_Name";
            this.lbl_Site_Name.Size = new System.Drawing.Size(188, 40);
            this.lbl_Site_Name.TabIndex = 2;
            this.lbl_Site_Name.Text = "SITE NAME";
            // 
            // lbl_Material_Name
            // 
            this.lbl_Material_Name.AutoSize = true;
            this.lbl_Material_Name.Font = new System.Drawing.Font("Cambria", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Material_Name.Location = new System.Drawing.Point(139, 365);
            this.lbl_Material_Name.Name = "lbl_Material_Name";
            this.lbl_Material_Name.Size = new System.Drawing.Size(282, 40);
            this.lbl_Material_Name.TabIndex = 3;
            this.lbl_Material_Name.Text = "MATERIAL NAME";
            // 
            // lbl_Material_Used
            // 
            this.lbl_Material_Used.AutoSize = true;
            this.lbl_Material_Used.Font = new System.Drawing.Font("Cambria", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Material_Used.Location = new System.Drawing.Point(148, 457);
            this.lbl_Material_Used.Name = "lbl_Material_Used";
            this.lbl_Material_Used.Size = new System.Drawing.Size(273, 40);
            this.lbl_Material_Used.TabIndex = 4;
            this.lbl_Material_Used.Text = "MATERIAL USED";
            // 
            // frm_Material_Expence
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1108, 735);
            this.Controls.Add(this.lbl_Material_Used);
            this.Controls.Add(this.lbl_Material_Name);
            this.Controls.Add(this.lbl_Site_Name);
            this.Controls.Add(this.lbl_Used_ID);
            this.Controls.Add(this.lbl_Material_Expence_Details);
            this.Name = "frm_Material_Expence";
            this.Text = "MATERIAL EXPENCE";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_Material_Expence_Details;
        private System.Windows.Forms.Label lbl_Used_ID;
        private System.Windows.Forms.Label lbl_Site_Name;
        private System.Windows.Forms.Label lbl_Material_Name;
        private System.Windows.Forms.Label lbl_Material_Used;
    }
}