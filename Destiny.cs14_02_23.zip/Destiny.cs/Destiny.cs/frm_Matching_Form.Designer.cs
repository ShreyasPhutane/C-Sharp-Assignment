﻿namespace Destiny.cs
{
    partial class frm_Matching_Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel2 = new System.Windows.Forms.Panel();
            this.lbl_Find_Your_Compader = new System.Windows.Forms.Label();
            this.lbl_matching_Slogen = new System.Windows.Forms.Label();
            this.lbl_Marital_Status = new System.Windows.Forms.Label();
            this.lbl_Caste = new System.Windows.Forms.Label();
            this.lbl_Sub_Caste = new System.Windows.Forms.Label();
            this.cmb_Residing_City = new System.Windows.Forms.ComboBox();
            this.lbl_Residing_City = new System.Windows.Forms.Label();
            this.cmb_Complexion = new System.Windows.Forms.ComboBox();
            this.lbl_Complexion = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.cmb_Employed_In = new System.Windows.Forms.ComboBox();
            this.lbl_Highest_Education = new System.Windows.Forms.Label();
            this.cmb_Highest_Educatiion = new System.Windows.Forms.ComboBox();
            this.lbl_Occupation = new System.Windows.Forms.Label();
            this.cmb_Occupation = new System.Windows.Forms.ComboBox();
            this.lbl_Employed_In = new System.Windows.Forms.Label();
            this.lbl_Monthly_Income = new System.Windows.Forms.Label();
            this.cmb_Monthly_Income = new System.Windows.Forms.ComboBox();
            this.cmb_Family_Type = new System.Windows.Forms.ComboBox();
            this.lbl_Family_Type = new System.Windows.Forms.Label();
            this.cmb_Marital_Status = new System.Windows.Forms.ComboBox();
            this.cmb_Caste = new System.Windows.Forms.ComboBox();
            this.cmb_Sub_Caste = new System.Windows.Forms.ComboBox();
            this.cmb_Food = new System.Windows.Forms.ComboBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel2.Controls.Add(this.pictureBox2);
            this.panel2.Controls.Add(this.pictureBox1);
            this.panel2.Controls.Add(this.lbl_matching_Slogen);
            this.panel2.Controls.Add(this.lbl_Find_Your_Compader);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1482, 110);
            this.panel2.TabIndex = 19;
            // 
            // lbl_Find_Your_Compader
            // 
            this.lbl_Find_Your_Compader.AutoSize = true;
            this.lbl_Find_Your_Compader.Font = new System.Drawing.Font("Times New Roman", 36F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Find_Your_Compader.ForeColor = System.Drawing.Color.Navy;
            this.lbl_Find_Your_Compader.Location = new System.Drawing.Point(439, 2);
            this.lbl_Find_Your_Compader.Name = "lbl_Find_Your_Compader";
            this.lbl_Find_Your_Compader.Size = new System.Drawing.Size(623, 67);
            this.lbl_Find_Your_Compader.TabIndex = 0;
            this.lbl_Find_Your_Compader.Text = "Find Your Compader.....";
            // 
            // lbl_matching_Slogen
            // 
            this.lbl_matching_Slogen.AutoSize = true;
            this.lbl_matching_Slogen.Font = new System.Drawing.Font("Times New Roman", 15F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_matching_Slogen.ForeColor = System.Drawing.Color.Navy;
            this.lbl_matching_Slogen.Location = new System.Drawing.Point(498, 69);
            this.lbl_matching_Slogen.Name = "lbl_matching_Slogen";
            this.lbl_matching_Slogen.Size = new System.Drawing.Size(474, 30);
            this.lbl_matching_Slogen.TabIndex = 1;
            this.lbl_matching_Slogen.Text = "It\'s Better To Hold Onto Each Other In Life.";
            // 
            // lbl_Marital_Status
            // 
            this.lbl_Marital_Status.AutoSize = true;
            this.lbl_Marital_Status.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Marital_Status.Location = new System.Drawing.Point(12, 130);
            this.lbl_Marital_Status.Name = "lbl_Marital_Status";
            this.lbl_Marital_Status.Size = new System.Drawing.Size(158, 29);
            this.lbl_Marital_Status.TabIndex = 36;
            this.lbl_Marital_Status.Text = "Marital Status:";
            // 
            // lbl_Caste
            // 
            this.lbl_Caste.AutoSize = true;
            this.lbl_Caste.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Caste.Location = new System.Drawing.Point(439, 129);
            this.lbl_Caste.Name = "lbl_Caste";
            this.lbl_Caste.Size = new System.Drawing.Size(69, 29);
            this.lbl_Caste.TabIndex = 42;
            this.lbl_Caste.Text = "Caste";
            // 
            // lbl_Sub_Caste
            // 
            this.lbl_Sub_Caste.AutoSize = true;
            this.lbl_Sub_Caste.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Sub_Caste.Location = new System.Drawing.Point(719, 130);
            this.lbl_Sub_Caste.Name = "lbl_Sub_Caste";
            this.lbl_Sub_Caste.Size = new System.Drawing.Size(115, 29);
            this.lbl_Sub_Caste.TabIndex = 44;
            this.lbl_Sub_Caste.Text = "Sub Caste";
            // 
            // cmb_Residing_City
            // 
            this.cmb_Residing_City.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_Residing_City.FormattingEnabled = true;
            this.cmb_Residing_City.Items.AddRange(new object[] {
            "Satara",
            "Kolhapur",
            "Pune",
            "Mumbai"});
            this.cmb_Residing_City.Location = new System.Drawing.Point(1222, 127);
            this.cmb_Residing_City.Name = "cmb_Residing_City";
            this.cmb_Residing_City.Size = new System.Drawing.Size(167, 37);
            this.cmb_Residing_City.TabIndex = 47;
            // 
            // lbl_Residing_City
            // 
            this.lbl_Residing_City.AutoSize = true;
            this.lbl_Residing_City.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Residing_City.Location = new System.Drawing.Point(1066, 130);
            this.lbl_Residing_City.Name = "lbl_Residing_City";
            this.lbl_Residing_City.Size = new System.Drawing.Size(150, 29);
            this.lbl_Residing_City.TabIndex = 46;
            this.lbl_Residing_City.Text = "Residing City";
            // 
            // cmb_Complexion
            // 
            this.cmb_Complexion.Font = new System.Drawing.Font("Times New Roman", 15F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_Complexion.FormattingEnabled = true;
            this.cmb_Complexion.Items.AddRange(new object[] {
            "Fair",
            "Over Fair",
            "Wheatish",
            "Wheatish Brown"});
            this.cmb_Complexion.Location = new System.Drawing.Point(176, 174);
            this.cmb_Complexion.Name = "cmb_Complexion";
            this.cmb_Complexion.Size = new System.Drawing.Size(185, 38);
            this.cmb_Complexion.TabIndex = 49;
            // 
            // lbl_Complexion
            // 
            this.lbl_Complexion.AutoSize = true;
            this.lbl_Complexion.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Complexion.Location = new System.Drawing.Point(12, 178);
            this.lbl_Complexion.Name = "lbl_Complexion";
            this.lbl_Complexion.Size = new System.Drawing.Size(138, 29);
            this.lbl_Complexion.TabIndex = 48;
            this.lbl_Complexion.Text = "Complexion";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(409, 178);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(66, 29);
            this.label3.TabIndex = 61;
            this.label3.Text = "Food";
            // 
            // cmb_Employed_In
            // 
            this.cmb_Employed_In.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_Employed_In.FormattingEnabled = true;
            this.cmb_Employed_In.Items.AddRange(new object[] {
            "Government",
            "Private",
            "Business",
            "Defence",
            "Self Employed"});
            this.cmb_Employed_In.Location = new System.Drawing.Point(588, 228);
            this.cmb_Employed_In.Name = "cmb_Employed_In";
            this.cmb_Employed_In.Size = new System.Drawing.Size(246, 37);
            this.cmb_Employed_In.TabIndex = 64;
            // 
            // lbl_Highest_Education
            // 
            this.lbl_Highest_Education.AutoSize = true;
            this.lbl_Highest_Education.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Highest_Education.Location = new System.Drawing.Point(1026, 177);
            this.lbl_Highest_Education.Name = "lbl_Highest_Education";
            this.lbl_Highest_Education.Size = new System.Drawing.Size(198, 29);
            this.lbl_Highest_Education.TabIndex = 66;
            this.lbl_Highest_Education.Text = "Highest Education";
            // 
            // cmb_Highest_Educatiion
            // 
            this.cmb_Highest_Educatiion.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_Highest_Educatiion.FormattingEnabled = true;
            this.cmb_Highest_Educatiion.Location = new System.Drawing.Point(1236, 174);
            this.cmb_Highest_Educatiion.Name = "cmb_Highest_Educatiion";
            this.cmb_Highest_Educatiion.Size = new System.Drawing.Size(234, 37);
            this.cmb_Highest_Educatiion.TabIndex = 62;
            // 
            // lbl_Occupation
            // 
            this.lbl_Occupation.AutoSize = true;
            this.lbl_Occupation.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Occupation.Location = new System.Drawing.Point(12, 231);
            this.lbl_Occupation.Name = "lbl_Occupation";
            this.lbl_Occupation.Size = new System.Drawing.Size(129, 29);
            this.lbl_Occupation.TabIndex = 67;
            this.lbl_Occupation.Text = "Occupation";
            // 
            // cmb_Occupation
            // 
            this.cmb_Occupation.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_Occupation.FormattingEnabled = true;
            this.cmb_Occupation.Location = new System.Drawing.Point(176, 223);
            this.cmb_Occupation.Name = "cmb_Occupation";
            this.cmb_Occupation.Size = new System.Drawing.Size(231, 37);
            this.cmb_Occupation.TabIndex = 63;
            // 
            // lbl_Employed_In
            // 
            this.lbl_Employed_In.AutoSize = true;
            this.lbl_Employed_In.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Employed_In.Location = new System.Drawing.Point(429, 231);
            this.lbl_Employed_In.Name = "lbl_Employed_In";
            this.lbl_Employed_In.Size = new System.Drawing.Size(144, 29);
            this.lbl_Employed_In.TabIndex = 68;
            this.lbl_Employed_In.Text = "Employed In";
            // 
            // lbl_Monthly_Income
            // 
            this.lbl_Monthly_Income.AutoSize = true;
            this.lbl_Monthly_Income.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Monthly_Income.Location = new System.Drawing.Point(861, 231);
            this.lbl_Monthly_Income.Name = "lbl_Monthly_Income";
            this.lbl_Monthly_Income.Size = new System.Drawing.Size(182, 29);
            this.lbl_Monthly_Income.TabIndex = 69;
            this.lbl_Monthly_Income.Text = "Monthly Income";
            // 
            // cmb_Monthly_Income
            // 
            this.cmb_Monthly_Income.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_Monthly_Income.FormattingEnabled = true;
            this.cmb_Monthly_Income.Location = new System.Drawing.Point(1052, 228);
            this.cmb_Monthly_Income.Name = "cmb_Monthly_Income";
            this.cmb_Monthly_Income.Size = new System.Drawing.Size(246, 37);
            this.cmb_Monthly_Income.TabIndex = 65;
            // 
            // cmb_Family_Type
            // 
            this.cmb_Family_Type.Font = new System.Drawing.Font("Times New Roman", 15F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_Family_Type.FormattingEnabled = true;
            this.cmb_Family_Type.Items.AddRange(new object[] {
            "Joint",
            "Nuclear"});
            this.cmb_Family_Type.Location = new System.Drawing.Point(859, 174);
            this.cmb_Family_Type.Name = "cmb_Family_Type";
            this.cmb_Family_Type.Size = new System.Drawing.Size(155, 38);
            this.cmb_Family_Type.TabIndex = 71;
            // 
            // lbl_Family_Type
            // 
            this.lbl_Family_Type.AutoSize = true;
            this.lbl_Family_Type.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Family_Type.Location = new System.Drawing.Point(715, 178);
            this.lbl_Family_Type.Name = "lbl_Family_Type";
            this.lbl_Family_Type.Size = new System.Drawing.Size(138, 29);
            this.lbl_Family_Type.TabIndex = 70;
            this.lbl_Family_Type.Text = "Family Type";
            // 
            // cmb_Marital_Status
            // 
            this.cmb_Marital_Status.Font = new System.Drawing.Font("Times New Roman", 15F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_Marital_Status.FormattingEnabled = true;
            this.cmb_Marital_Status.Items.AddRange(new object[] {
            "Never Married",
            "Widow\t",
            "Divorced\t\t",
            "Awaiting Divorced"});
            this.cmb_Marital_Status.Location = new System.Drawing.Point(176, 121);
            this.cmb_Marital_Status.Name = "cmb_Marital_Status";
            this.cmb_Marital_Status.Size = new System.Drawing.Size(231, 38);
            this.cmb_Marital_Status.TabIndex = 72;
            // 
            // cmb_Caste
            // 
            this.cmb_Caste.Font = new System.Drawing.Font("Times New Roman", 15F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_Caste.FormattingEnabled = true;
            this.cmb_Caste.Items.AddRange(new object[] {
            "Joint",
            "Nuclear"});
            this.cmb_Caste.Location = new System.Drawing.Point(514, 126);
            this.cmb_Caste.Name = "cmb_Caste";
            this.cmb_Caste.Size = new System.Drawing.Size(168, 38);
            this.cmb_Caste.TabIndex = 73;
            // 
            // cmb_Sub_Caste
            // 
            this.cmb_Sub_Caste.Font = new System.Drawing.Font("Times New Roman", 15F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_Sub_Caste.FormattingEnabled = true;
            this.cmb_Sub_Caste.Items.AddRange(new object[] {
            "Joint",
            "Nuclear"});
            this.cmb_Sub_Caste.Location = new System.Drawing.Point(845, 126);
            this.cmb_Sub_Caste.Name = "cmb_Sub_Caste";
            this.cmb_Sub_Caste.Size = new System.Drawing.Size(166, 38);
            this.cmb_Sub_Caste.TabIndex = 74;
            // 
            // cmb_Food
            // 
            this.cmb_Food.Font = new System.Drawing.Font("Times New Roman", 15F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_Food.FormattingEnabled = true;
            this.cmb_Food.Items.AddRange(new object[] {
            "Vegetarian",
            "Non-Vegetarian",
            "Eggetarian"});
            this.cmb_Food.Location = new System.Drawing.Point(491, 174);
            this.cmb_Food.Name = "cmb_Food";
            this.cmb_Food.Size = new System.Drawing.Size(192, 38);
            this.cmb_Food.TabIndex = 75;
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.Info;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(17, 295);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(1453, 446);
            this.dataGridView1.TabIndex = 76;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Destiny.cs.Properties.Resources.Cliparts_27;
            this.pictureBox1.Location = new System.Drawing.Point(1031, 10);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(491, 97);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 77;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::Destiny.cs.Properties.Resources.Cliparts_27;
            this.pictureBox2.Location = new System.Drawing.Point(-68, 10);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(490, 97);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 78;
            this.pictureBox2.TabStop = false;
            // 
            // frm_Matching_Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.ClientSize = new System.Drawing.Size(1482, 753);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.cmb_Food);
            this.Controls.Add(this.cmb_Sub_Caste);
            this.Controls.Add(this.cmb_Caste);
            this.Controls.Add(this.cmb_Marital_Status);
            this.Controls.Add(this.cmb_Family_Type);
            this.Controls.Add(this.lbl_Family_Type);
            this.Controls.Add(this.cmb_Employed_In);
            this.Controls.Add(this.lbl_Highest_Education);
            this.Controls.Add(this.cmb_Highest_Educatiion);
            this.Controls.Add(this.lbl_Occupation);
            this.Controls.Add(this.cmb_Occupation);
            this.Controls.Add(this.lbl_Employed_In);
            this.Controls.Add(this.lbl_Monthly_Income);
            this.Controls.Add(this.cmb_Monthly_Income);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.cmb_Complexion);
            this.Controls.Add(this.lbl_Complexion);
            this.Controls.Add(this.cmb_Residing_City);
            this.Controls.Add(this.lbl_Residing_City);
            this.Controls.Add(this.lbl_Sub_Caste);
            this.Controls.Add(this.lbl_Caste);
            this.Controls.Add(this.lbl_Marital_Status);
            this.Controls.Add(this.panel2);
            this.Name = "frm_Matching_Form";
            this.Text = "Matching Form";
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label lbl_matching_Slogen;
        private System.Windows.Forms.Label lbl_Find_Your_Compader;
        private System.Windows.Forms.Label lbl_Marital_Status;
        private System.Windows.Forms.Label lbl_Caste;
        private System.Windows.Forms.Label lbl_Sub_Caste;
        private System.Windows.Forms.ComboBox cmb_Residing_City;
        private System.Windows.Forms.Label lbl_Residing_City;
        private System.Windows.Forms.ComboBox cmb_Complexion;
        private System.Windows.Forms.Label lbl_Complexion;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cmb_Employed_In;
        private System.Windows.Forms.Label lbl_Highest_Education;
        private System.Windows.Forms.ComboBox cmb_Highest_Educatiion;
        private System.Windows.Forms.Label lbl_Occupation;
        private System.Windows.Forms.ComboBox cmb_Occupation;
        private System.Windows.Forms.Label lbl_Employed_In;
        private System.Windows.Forms.Label lbl_Monthly_Income;
        private System.Windows.Forms.ComboBox cmb_Monthly_Income;
        private System.Windows.Forms.ComboBox cmb_Family_Type;
        private System.Windows.Forms.Label lbl_Family_Type;
        private System.Windows.Forms.ComboBox cmb_Marital_Status;
        private System.Windows.Forms.ComboBox cmb_Caste;
        private System.Windows.Forms.ComboBox cmb_Sub_Caste;
        private System.Windows.Forms.ComboBox cmb_Food;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
    }
}