﻿namespace Construction_Management_System
{
    partial class frm_Labour_Entry
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_Employee_Details = new System.Windows.Forms.Label();
            this.lbl_Employee_No = new System.Windows.Forms.Label();
            this.lbl_Employee_Name = new System.Windows.Forms.Label();
            this.lbl_Adhaar_No = new System.Windows.Forms.Label();
            this.lbl_Post = new System.Windows.Forms.Label();
            this.lbl_Mobile_No = new System.Windows.Forms.Label();
            this.lbl_Gender = new System.Windows.Forms.Label();
            this.lbl_Birth_Date = new System.Windows.Forms.Label();
            this.lbl_Joining_Date = new System.Windows.Forms.Label();
            this.lbl_Address = new System.Windows.Forms.Label();
            this.lbl_Salary = new System.Windows.Forms.Label();
            this.tb_Employee_No = new System.Windows.Forms.TextBox();
            this.tb_Employee_Name = new System.Windows.Forms.TextBox();
            this.tb_Adhaar_No = new System.Windows.Forms.TextBox();
            this.tb_Mobile_No = new System.Windows.Forms.TextBox();
            this.cb_Post = new System.Windows.Forms.ComboBox();
            this.btn_Show = new System.Windows.Forms.Button();
            this.dtp_Birth_Date = new System.Windows.Forms.DateTimePicker();
            this.dtp_Joining_Date = new System.Windows.Forms.DateTimePicker();
            this.tb_Address = new System.Windows.Forms.TextBox();
            this.tb_Salary = new System.Windows.Forms.TextBox();
            this.rb_Male = new System.Windows.Forms.RadioButton();
            this.rb_Female = new System.Windows.Forms.RadioButton();
            this.btn_Save = new System.Windows.Forms.Button();
            this.btn_Add_Details = new System.Windows.Forms.Button();
            this.btn_Update = new System.Windows.Forms.Button();
            this.btn_Delete = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // lbl_Employee_Details
            // 
            this.lbl_Employee_Details.AutoSize = true;
            this.lbl_Employee_Details.Font = new System.Drawing.Font("Cambria", 30F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Employee_Details.Location = new System.Drawing.Point(283, 23);
            this.lbl_Employee_Details.Name = "lbl_Employee_Details";
            this.lbl_Employee_Details.Size = new System.Drawing.Size(481, 59);
            this.lbl_Employee_Details.TabIndex = 0;
            this.lbl_Employee_Details.Text = "EMPLOYEE DETAILS";
            // 
            // lbl_Employee_No
            // 
            this.lbl_Employee_No.AutoSize = true;
            this.lbl_Employee_No.Font = new System.Drawing.Font("Cambria", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Employee_No.Location = new System.Drawing.Point(52, 141);
            this.lbl_Employee_No.Name = "lbl_Employee_No";
            this.lbl_Employee_No.Size = new System.Drawing.Size(176, 30);
            this.lbl_Employee_No.TabIndex = 1;
            this.lbl_Employee_No.Text = "EMPLOYEE NO";
            // 
            // lbl_Employee_Name
            // 
            this.lbl_Employee_Name.AutoSize = true;
            this.lbl_Employee_Name.Font = new System.Drawing.Font("Cambria", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Employee_Name.Location = new System.Drawing.Point(52, 229);
            this.lbl_Employee_Name.Name = "lbl_Employee_Name";
            this.lbl_Employee_Name.Size = new System.Drawing.Size(210, 30);
            this.lbl_Employee_Name.TabIndex = 2;
            this.lbl_Employee_Name.Text = "EMPLOYEE NAME";
            // 
            // lbl_Adhaar_No
            // 
            this.lbl_Adhaar_No.AutoSize = true;
            this.lbl_Adhaar_No.Font = new System.Drawing.Font("Cambria", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Adhaar_No.Location = new System.Drawing.Point(52, 320);
            this.lbl_Adhaar_No.Name = "lbl_Adhaar_No";
            this.lbl_Adhaar_No.Size = new System.Drawing.Size(154, 30);
            this.lbl_Adhaar_No.TabIndex = 3;
            this.lbl_Adhaar_No.Text = "ADHAAR NO";
            // 
            // lbl_Post
            // 
            this.lbl_Post.AutoSize = true;
            this.lbl_Post.Font = new System.Drawing.Font("Cambria", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Post.Location = new System.Drawing.Point(52, 404);
            this.lbl_Post.Name = "lbl_Post";
            this.lbl_Post.Size = new System.Drawing.Size(74, 30);
            this.lbl_Post.TabIndex = 4;
            this.lbl_Post.Text = "POST";
            // 
            // lbl_Mobile_No
            // 
            this.lbl_Mobile_No.AutoSize = true;
            this.lbl_Mobile_No.Font = new System.Drawing.Font("Cambria", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Mobile_No.Location = new System.Drawing.Point(52, 488);
            this.lbl_Mobile_No.Name = "lbl_Mobile_No";
            this.lbl_Mobile_No.Size = new System.Drawing.Size(144, 30);
            this.lbl_Mobile_No.TabIndex = 5;
            this.lbl_Mobile_No.Text = "MOBILE NO";
            // 
            // lbl_Gender
            // 
            this.lbl_Gender.AutoSize = true;
            this.lbl_Gender.Font = new System.Drawing.Font("Cambria", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Gender.Location = new System.Drawing.Point(52, 578);
            this.lbl_Gender.Name = "lbl_Gender";
            this.lbl_Gender.Size = new System.Drawing.Size(109, 30);
            this.lbl_Gender.TabIndex = 6;
            this.lbl_Gender.Text = "GENDER";
            // 
            // lbl_Birth_Date
            // 
            this.lbl_Birth_Date.AutoSize = true;
            this.lbl_Birth_Date.Font = new System.Drawing.Font("Cambria", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Birth_Date.Location = new System.Drawing.Point(590, 152);
            this.lbl_Birth_Date.Name = "lbl_Birth_Date";
            this.lbl_Birth_Date.Size = new System.Drawing.Size(155, 30);
            this.lbl_Birth_Date.TabIndex = 7;
            this.lbl_Birth_Date.Text = "BIRTH DATE";
            // 
            // lbl_Joining_Date
            // 
            this.lbl_Joining_Date.AutoSize = true;
            this.lbl_Joining_Date.Font = new System.Drawing.Font("Cambria", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Joining_Date.Location = new System.Drawing.Point(590, 235);
            this.lbl_Joining_Date.Name = "lbl_Joining_Date";
            this.lbl_Joining_Date.Size = new System.Drawing.Size(174, 30);
            this.lbl_Joining_Date.TabIndex = 8;
            this.lbl_Joining_Date.Text = "JOINING DATE";
            // 
            // lbl_Address
            // 
            this.lbl_Address.AutoSize = true;
            this.lbl_Address.Font = new System.Drawing.Font("Cambria", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Address.Location = new System.Drawing.Point(590, 320);
            this.lbl_Address.Name = "lbl_Address";
            this.lbl_Address.Size = new System.Drawing.Size(122, 30);
            this.lbl_Address.TabIndex = 9;
            this.lbl_Address.Text = "ADDRESS";
            // 
            // lbl_Salary
            // 
            this.lbl_Salary.AutoSize = true;
            this.lbl_Salary.Font = new System.Drawing.Font("Cambria", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Salary.Location = new System.Drawing.Point(590, 491);
            this.lbl_Salary.Name = "lbl_Salary";
            this.lbl_Salary.Size = new System.Drawing.Size(103, 30);
            this.lbl_Salary.TabIndex = 10;
            this.lbl_Salary.Text = "SALARY";
            // 
            // tb_Employee_No
            // 
            this.tb_Employee_No.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Employee_No.Location = new System.Drawing.Point(268, 145);
            this.tb_Employee_No.Name = "tb_Employee_No";
            this.tb_Employee_No.Size = new System.Drawing.Size(159, 36);
            this.tb_Employee_No.TabIndex = 11;
            // 
            // tb_Employee_Name
            // 
            this.tb_Employee_Name.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Employee_Name.Location = new System.Drawing.Point(268, 229);
            this.tb_Employee_Name.Name = "tb_Employee_Name";
            this.tb_Employee_Name.Size = new System.Drawing.Size(267, 36);
            this.tb_Employee_Name.TabIndex = 12;
            // 
            // tb_Adhaar_No
            // 
            this.tb_Adhaar_No.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Adhaar_No.Location = new System.Drawing.Point(268, 314);
            this.tb_Adhaar_No.Name = "tb_Adhaar_No";
            this.tb_Adhaar_No.Size = new System.Drawing.Size(267, 36);
            this.tb_Adhaar_No.TabIndex = 13;
            // 
            // tb_Mobile_No
            // 
            this.tb_Mobile_No.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Mobile_No.Location = new System.Drawing.Point(268, 488);
            this.tb_Mobile_No.Name = "tb_Mobile_No";
            this.tb_Mobile_No.Size = new System.Drawing.Size(267, 36);
            this.tb_Mobile_No.TabIndex = 14;
            // 
            // cb_Post
            // 
            this.cb_Post.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cb_Post.FormattingEnabled = true;
            this.cb_Post.Items.AddRange(new object[] {
            "MANAGER",
            "ENGINEER",
            "SUPERVISOR",
            "ACCOUNTANT",
            "LABOUR"});
            this.cb_Post.Location = new System.Drawing.Point(268, 404);
            this.cb_Post.Name = "cb_Post";
            this.cb_Post.Size = new System.Drawing.Size(267, 37);
            this.cb_Post.TabIndex = 15;
            // 
            // btn_Show
            // 
            this.btn_Show.Font = new System.Drawing.Font("Cambria", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Show.Location = new System.Drawing.Point(433, 144);
            this.btn_Show.Name = "btn_Show";
            this.btn_Show.Size = new System.Drawing.Size(114, 47);
            this.btn_Show.TabIndex = 16;
            this.btn_Show.Text = "SHOW";
            this.btn_Show.UseVisualStyleBackColor = true;
            // 
            // dtp_Birth_Date
            // 
            this.dtp_Birth_Date.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtp_Birth_Date.Location = new System.Drawing.Point(793, 152);
            this.dtp_Birth_Date.Name = "dtp_Birth_Date";
            this.dtp_Birth_Date.Size = new System.Drawing.Size(259, 36);
            this.dtp_Birth_Date.TabIndex = 17;
            // 
            // dtp_Joining_Date
            // 
            this.dtp_Joining_Date.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtp_Joining_Date.Location = new System.Drawing.Point(793, 226);
            this.dtp_Joining_Date.Name = "dtp_Joining_Date";
            this.dtp_Joining_Date.Size = new System.Drawing.Size(259, 36);
            this.dtp_Joining_Date.TabIndex = 18;
            // 
            // tb_Address
            // 
            this.tb_Address.Location = new System.Drawing.Point(784, 320);
            this.tb_Address.Multiline = true;
            this.tb_Address.Name = "tb_Address";
            this.tb_Address.Size = new System.Drawing.Size(268, 98);
            this.tb_Address.TabIndex = 19;
            // 
            // tb_Salary
            // 
            this.tb_Salary.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Salary.Location = new System.Drawing.Point(793, 488);
            this.tb_Salary.Name = "tb_Salary";
            this.tb_Salary.Size = new System.Drawing.Size(259, 36);
            this.tb_Salary.TabIndex = 20;
            // 
            // rb_Male
            // 
            this.rb_Male.AutoSize = true;
            this.rb_Male.Font = new System.Drawing.Font("Cambria", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_Male.Location = new System.Drawing.Point(270, 576);
            this.rb_Male.Name = "rb_Male";
            this.rb_Male.Size = new System.Drawing.Size(99, 34);
            this.rb_Male.TabIndex = 21;
            this.rb_Male.TabStop = true;
            this.rb_Male.Text = "MALE";
            this.rb_Male.UseVisualStyleBackColor = true;
            // 
            // rb_Female
            // 
            this.rb_Female.AutoSize = true;
            this.rb_Female.Font = new System.Drawing.Font("Cambria", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_Female.Location = new System.Drawing.Point(408, 576);
            this.rb_Female.Name = "rb_Female";
            this.rb_Female.Size = new System.Drawing.Size(127, 34);
            this.rb_Female.TabIndex = 22;
            this.rb_Female.TabStop = true;
            this.rb_Female.Text = "FEMALE";
            this.rb_Female.UseVisualStyleBackColor = true;
            // 
            // btn_Save
            // 
            this.btn_Save.Font = new System.Drawing.Font("Cambria", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Save.Location = new System.Drawing.Point(66, 661);
            this.btn_Save.Name = "btn_Save";
            this.btn_Save.Size = new System.Drawing.Size(116, 49);
            this.btn_Save.TabIndex = 23;
            this.btn_Save.Text = "SAVE";
            this.btn_Save.UseVisualStyleBackColor = true;
            // 
            // btn_Add_Details
            // 
            this.btn_Add_Details.Font = new System.Drawing.Font("Cambria", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Add_Details.Location = new System.Drawing.Point(243, 661);
            this.btn_Add_Details.Name = "btn_Add_Details";
            this.btn_Add_Details.Size = new System.Drawing.Size(225, 47);
            this.btn_Add_Details.TabIndex = 24;
            this.btn_Add_Details.Text = "ADD DETAILS";
            this.btn_Add_Details.UseVisualStyleBackColor = true;
            // 
            // btn_Update
            // 
            this.btn_Update.Font = new System.Drawing.Font("Cambria", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Update.Location = new System.Drawing.Point(560, 659);
            this.btn_Update.Name = "btn_Update";
            this.btn_Update.Size = new System.Drawing.Size(152, 49);
            this.btn_Update.TabIndex = 25;
            this.btn_Update.Text = "UPDATE";
            this.btn_Update.UseVisualStyleBackColor = true;
            // 
            // btn_Delete
            // 
            this.btn_Delete.Font = new System.Drawing.Font("Cambria", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Delete.Location = new System.Drawing.Point(784, 659);
            this.btn_Delete.Name = "btn_Delete";
            this.btn_Delete.Size = new System.Drawing.Size(167, 51);
            this.btn_Delete.TabIndex = 26;
            this.btn_Delete.Text = "DELETE";
            this.btn_Delete.UseVisualStyleBackColor = true;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Coral;
            this.panel1.Controls.Add(this.lbl_Employee_Details);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1112, 100);
            this.panel1.TabIndex = 27;
            // 
            // frm_Labour_Entry
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1112, 732);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.btn_Delete);
            this.Controls.Add(this.btn_Update);
            this.Controls.Add(this.btn_Add_Details);
            this.Controls.Add(this.btn_Save);
            this.Controls.Add(this.rb_Female);
            this.Controls.Add(this.rb_Male);
            this.Controls.Add(this.tb_Salary);
            this.Controls.Add(this.tb_Address);
            this.Controls.Add(this.dtp_Joining_Date);
            this.Controls.Add(this.dtp_Birth_Date);
            this.Controls.Add(this.btn_Show);
            this.Controls.Add(this.cb_Post);
            this.Controls.Add(this.tb_Mobile_No);
            this.Controls.Add(this.tb_Adhaar_No);
            this.Controls.Add(this.tb_Employee_Name);
            this.Controls.Add(this.tb_Employee_No);
            this.Controls.Add(this.lbl_Salary);
            this.Controls.Add(this.lbl_Address);
            this.Controls.Add(this.lbl_Joining_Date);
            this.Controls.Add(this.lbl_Birth_Date);
            this.Controls.Add(this.lbl_Gender);
            this.Controls.Add(this.lbl_Mobile_No);
            this.Controls.Add(this.lbl_Post);
            this.Controls.Add(this.lbl_Adhaar_No);
            this.Controls.Add(this.lbl_Employee_Name);
            this.Controls.Add(this.lbl_Employee_No);
            this.Name = "frm_Labour_Entry";
            this.Text = "LABOUR ENTRY";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_Employee_Details;
        private System.Windows.Forms.Label lbl_Employee_No;
        private System.Windows.Forms.Label lbl_Employee_Name;
        private System.Windows.Forms.Label lbl_Adhaar_No;
        private System.Windows.Forms.Label lbl_Post;
        private System.Windows.Forms.Label lbl_Mobile_No;
        private System.Windows.Forms.Label lbl_Gender;
        private System.Windows.Forms.Label lbl_Birth_Date;
        private System.Windows.Forms.Label lbl_Joining_Date;
        private System.Windows.Forms.Label lbl_Address;
        private System.Windows.Forms.Label lbl_Salary;
        private System.Windows.Forms.TextBox tb_Employee_No;
        private System.Windows.Forms.TextBox tb_Employee_Name;
        private System.Windows.Forms.TextBox tb_Adhaar_No;
        private System.Windows.Forms.TextBox tb_Mobile_No;
        private System.Windows.Forms.ComboBox cb_Post;
        private System.Windows.Forms.Button btn_Show;
        private System.Windows.Forms.DateTimePicker dtp_Birth_Date;
        private System.Windows.Forms.DateTimePicker dtp_Joining_Date;
        private System.Windows.Forms.TextBox tb_Address;
        private System.Windows.Forms.TextBox tb_Salary;
        private System.Windows.Forms.RadioButton rb_Male;
        private System.Windows.Forms.RadioButton rb_Female;
        private System.Windows.Forms.Button btn_Save;
        private System.Windows.Forms.Button btn_Add_Details;
        private System.Windows.Forms.Button btn_Update;
        private System.Windows.Forms.Button btn_Delete;
        private System.Windows.Forms.Panel panel1;
    }
}