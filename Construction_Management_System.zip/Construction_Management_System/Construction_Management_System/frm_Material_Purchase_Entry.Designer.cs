﻿namespace Construction_Management_System
{
    partial class frm_Material_Purchase_Entry
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_Material_Purchase_Details = new System.Windows.Forms.Label();
            this.lbl_Purchase_Entry_Bill = new System.Windows.Forms.Label();
            this.lbl_Bill_No = new System.Windows.Forms.Label();
            this.lbl_Material_Name = new System.Windows.Forms.Label();
            this.lbl_Date = new System.Windows.Forms.Label();
            this.lbl_Supplier_Name = new System.Windows.Forms.Label();
            this.lbl_Weight_Brass_QTY = new System.Windows.Forms.Label();
            this.lbl_GST = new System.Windows.Forms.Label();
            this.lbl_Price = new System.Windows.Forms.Label();
            this.lbl_Bill = new System.Windows.Forms.Label();
            this.tb_Bill_No = new System.Windows.Forms.TextBox();
            this.tb_Supplier_Name = new System.Windows.Forms.TextBox();
            this.tb_Weight_Brass_QTY = new System.Windows.Forms.TextBox();
            this.tb_Price = new System.Windows.Forms.TextBox();
            this.tb_Bill = new System.Windows.Forms.TextBox();
            this.tb_GST = new System.Windows.Forms.TextBox();
            this.cb_Material_List = new System.Windows.Forms.ComboBox();
            this.dtp_Date = new System.Windows.Forms.DateTimePicker();
            this.btn_New = new System.Windows.Forms.Button();
            this.btn_Save = new System.Windows.Forms.Button();
            this.btn_Edit = new System.Windows.Forms.Button();
            this.btn_Delete = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl_Material_Purchase_Details
            // 
            this.lbl_Material_Purchase_Details.AutoSize = true;
            this.lbl_Material_Purchase_Details.Font = new System.Drawing.Font("Cambria", 30F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Material_Purchase_Details.Location = new System.Drawing.Point(195, 49);
            this.lbl_Material_Purchase_Details.Name = "lbl_Material_Purchase_Details";
            this.lbl_Material_Purchase_Details.Size = new System.Drawing.Size(733, 59);
            this.lbl_Material_Purchase_Details.TabIndex = 0;
            this.lbl_Material_Purchase_Details.Text = "MATERIAL PURCHASE DETAILS";
            // 
            // lbl_Purchase_Entry_Bill
            // 
            this.lbl_Purchase_Entry_Bill.AutoSize = true;
            this.lbl_Purchase_Entry_Bill.Font = new System.Drawing.Font("Cambria", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Purchase_Entry_Bill.Location = new System.Drawing.Point(39, 134);
            this.lbl_Purchase_Entry_Bill.Name = "lbl_Purchase_Entry_Bill";
            this.lbl_Purchase_Entry_Bill.Size = new System.Drawing.Size(234, 30);
            this.lbl_Purchase_Entry_Bill.TabIndex = 1;
            this.lbl_Purchase_Entry_Bill.Text = "Purchase Entry Bill";
            // 
            // lbl_Bill_No
            // 
            this.lbl_Bill_No.AutoSize = true;
            this.lbl_Bill_No.Font = new System.Drawing.Font("Cambria", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Bill_No.Location = new System.Drawing.Point(39, 206);
            this.lbl_Bill_No.Name = "lbl_Bill_No";
            this.lbl_Bill_No.Size = new System.Drawing.Size(106, 30);
            this.lbl_Bill_No.TabIndex = 2;
            this.lbl_Bill_No.Text = "BILL NO";
            // 
            // lbl_Material_Name
            // 
            this.lbl_Material_Name.AutoSize = true;
            this.lbl_Material_Name.Font = new System.Drawing.Font("Cambria", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Material_Name.Location = new System.Drawing.Point(39, 288);
            this.lbl_Material_Name.Name = "lbl_Material_Name";
            this.lbl_Material_Name.Size = new System.Drawing.Size(217, 30);
            this.lbl_Material_Name.TabIndex = 3;
            this.lbl_Material_Name.Text = "MATERIIAL NAME";
            // 
            // lbl_Date
            // 
            this.lbl_Date.AutoSize = true;
            this.lbl_Date.Font = new System.Drawing.Font("Cambria", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Date.Location = new System.Drawing.Point(39, 479);
            this.lbl_Date.Name = "lbl_Date";
            this.lbl_Date.Size = new System.Drawing.Size(74, 30);
            this.lbl_Date.TabIndex = 4;
            this.lbl_Date.Text = "DATE";
            // 
            // lbl_Supplier_Name
            // 
            this.lbl_Supplier_Name.AutoSize = true;
            this.lbl_Supplier_Name.Font = new System.Drawing.Font("Cambria", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Supplier_Name.Location = new System.Drawing.Point(39, 382);
            this.lbl_Supplier_Name.Name = "lbl_Supplier_Name";
            this.lbl_Supplier_Name.Size = new System.Drawing.Size(192, 30);
            this.lbl_Supplier_Name.TabIndex = 5;
            this.lbl_Supplier_Name.Text = "SUPPLER NAME";
            // 
            // lbl_Weight_Brass_QTY
            // 
            this.lbl_Weight_Brass_QTY.AutoSize = true;
            this.lbl_Weight_Brass_QTY.Font = new System.Drawing.Font("Cambria", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Weight_Brass_QTY.Location = new System.Drawing.Point(586, 209);
            this.lbl_Weight_Brass_QTY.Name = "lbl_Weight_Brass_QTY";
            this.lbl_Weight_Brass_QTY.Size = new System.Drawing.Size(258, 30);
            this.lbl_Weight_Brass_QTY.TabIndex = 6;
            this.lbl_Weight_Brass_QTY.Text = "WEIGHT/BRASS/QTY";
            // 
            // lbl_GST
            // 
            this.lbl_GST.AutoSize = true;
            this.lbl_GST.Font = new System.Drawing.Font("Cambria", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_GST.Location = new System.Drawing.Point(586, 479);
            this.lbl_GST.Name = "lbl_GST";
            this.lbl_GST.Size = new System.Drawing.Size(94, 30);
            this.lbl_GST.TabIndex = 7;
            this.lbl_GST.Text = "G.S.T%";
            // 
            // lbl_Price
            // 
            this.lbl_Price.AutoSize = true;
            this.lbl_Price.Font = new System.Drawing.Font("Cambria", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Price.Location = new System.Drawing.Point(586, 304);
            this.lbl_Price.Name = "lbl_Price";
            this.lbl_Price.Size = new System.Drawing.Size(82, 30);
            this.lbl_Price.TabIndex = 8;
            this.lbl_Price.Text = "PRICE";
            // 
            // lbl_Bill
            // 
            this.lbl_Bill.AutoSize = true;
            this.lbl_Bill.Font = new System.Drawing.Font("Cambria", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Bill.Location = new System.Drawing.Point(586, 385);
            this.lbl_Bill.Name = "lbl_Bill";
            this.lbl_Bill.Size = new System.Drawing.Size(66, 30);
            this.lbl_Bill.TabIndex = 9;
            this.lbl_Bill.Text = "BILL";
            // 
            // tb_Bill_No
            // 
            this.tb_Bill_No.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Bill_No.Location = new System.Drawing.Point(282, 200);
            this.tb_Bill_No.Name = "tb_Bill_No";
            this.tb_Bill_No.Size = new System.Drawing.Size(239, 36);
            this.tb_Bill_No.TabIndex = 10;
            // 
            // tb_Supplier_Name
            // 
            this.tb_Supplier_Name.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Supplier_Name.Location = new System.Drawing.Point(270, 379);
            this.tb_Supplier_Name.Name = "tb_Supplier_Name";
            this.tb_Supplier_Name.Size = new System.Drawing.Size(251, 36);
            this.tb_Supplier_Name.TabIndex = 12;
            // 
            // tb_Weight_Brass_QTY
            // 
            this.tb_Weight_Brass_QTY.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Weight_Brass_QTY.Location = new System.Drawing.Point(872, 203);
            this.tb_Weight_Brass_QTY.Name = "tb_Weight_Brass_QTY";
            this.tb_Weight_Brass_QTY.Size = new System.Drawing.Size(185, 36);
            this.tb_Weight_Brass_QTY.TabIndex = 15;
            // 
            // tb_Price
            // 
            this.tb_Price.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Price.Location = new System.Drawing.Point(872, 298);
            this.tb_Price.Name = "tb_Price";
            this.tb_Price.Size = new System.Drawing.Size(185, 36);
            this.tb_Price.TabIndex = 16;
            // 
            // tb_Bill
            // 
            this.tb_Bill.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Bill.Location = new System.Drawing.Point(865, 385);
            this.tb_Bill.Name = "tb_Bill";
            this.tb_Bill.Size = new System.Drawing.Size(192, 36);
            this.tb_Bill.TabIndex = 17;
            // 
            // tb_GST
            // 
            this.tb_GST.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_GST.Location = new System.Drawing.Point(865, 473);
            this.tb_GST.Name = "tb_GST";
            this.tb_GST.Size = new System.Drawing.Size(192, 36);
            this.tb_GST.TabIndex = 18;
            // 
            // cb_Material_List
            // 
            this.cb_Material_List.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cb_Material_List.FormattingEnabled = true;
            this.cb_Material_List.Items.AddRange(new object[] {
            "BRICKS",
            "CEMENT",
            "CONCRETE"});
            this.cb_Material_List.Location = new System.Drawing.Point(282, 288);
            this.cb_Material_List.Name = "cb_Material_List";
            this.cb_Material_List.Size = new System.Drawing.Size(239, 37);
            this.cb_Material_List.TabIndex = 19;
            // 
            // dtp_Date
            // 
            this.dtp_Date.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtp_Date.Location = new System.Drawing.Point(250, 473);
            this.dtp_Date.Name = "dtp_Date";
            this.dtp_Date.Size = new System.Drawing.Size(271, 36);
            this.dtp_Date.TabIndex = 20;
            // 
            // btn_New
            // 
            this.btn_New.Font = new System.Drawing.Font("Cambria", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_New.Location = new System.Drawing.Point(44, 608);
            this.btn_New.Name = "btn_New";
            this.btn_New.Size = new System.Drawing.Size(143, 55);
            this.btn_New.TabIndex = 21;
            this.btn_New.Text = "NEW";
            this.btn_New.UseVisualStyleBackColor = true;
            // 
            // btn_Save
            // 
            this.btn_Save.Font = new System.Drawing.Font("Cambria", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Save.Location = new System.Drawing.Point(259, 608);
            this.btn_Save.Name = "btn_Save";
            this.btn_Save.Size = new System.Drawing.Size(143, 55);
            this.btn_Save.TabIndex = 22;
            this.btn_Save.Text = "SAVE";
            this.btn_Save.UseVisualStyleBackColor = true;
            // 
            // btn_Edit
            // 
            this.btn_Edit.Font = new System.Drawing.Font("Cambria", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Edit.Location = new System.Drawing.Point(466, 608);
            this.btn_Edit.Name = "btn_Edit";
            this.btn_Edit.Size = new System.Drawing.Size(151, 55);
            this.btn_Edit.TabIndex = 23;
            this.btn_Edit.Text = "EDIT";
            this.btn_Edit.UseVisualStyleBackColor = true;
            // 
            // btn_Delete
            // 
            this.btn_Delete.Font = new System.Drawing.Font("Cambria", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Delete.Location = new System.Drawing.Point(702, 608);
            this.btn_Delete.Name = "btn_Delete";
            this.btn_Delete.Size = new System.Drawing.Size(167, 55);
            this.btn_Delete.TabIndex = 24;
            this.btn_Delete.Text = "DELETE";
            this.btn_Delete.UseVisualStyleBackColor = true;
            // 
            // frm_Material_Purchase_Entry
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1109, 729);
            this.Controls.Add(this.btn_Delete);
            this.Controls.Add(this.btn_Edit);
            this.Controls.Add(this.btn_Save);
            this.Controls.Add(this.btn_New);
            this.Controls.Add(this.dtp_Date);
            this.Controls.Add(this.cb_Material_List);
            this.Controls.Add(this.tb_GST);
            this.Controls.Add(this.tb_Bill);
            this.Controls.Add(this.tb_Price);
            this.Controls.Add(this.tb_Weight_Brass_QTY);
            this.Controls.Add(this.tb_Supplier_Name);
            this.Controls.Add(this.tb_Bill_No);
            this.Controls.Add(this.lbl_Bill);
            this.Controls.Add(this.lbl_Price);
            this.Controls.Add(this.lbl_GST);
            this.Controls.Add(this.lbl_Weight_Brass_QTY);
            this.Controls.Add(this.lbl_Supplier_Name);
            this.Controls.Add(this.lbl_Date);
            this.Controls.Add(this.lbl_Material_Name);
            this.Controls.Add(this.lbl_Bill_No);
            this.Controls.Add(this.lbl_Purchase_Entry_Bill);
            this.Controls.Add(this.lbl_Material_Purchase_Details);
            this.Name = "frm_Material_Purchase_Entry";
            this.Text = "MATERIAL PURCHASE ENTRY";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_Material_Purchase_Details;
        private System.Windows.Forms.Label lbl_Purchase_Entry_Bill;
        private System.Windows.Forms.Label lbl_Bill_No;
        private System.Windows.Forms.Label lbl_Material_Name;
        private System.Windows.Forms.Label lbl_Date;
        private System.Windows.Forms.Label lbl_Supplier_Name;
        private System.Windows.Forms.Label lbl_Weight_Brass_QTY;
        private System.Windows.Forms.Label lbl_GST;
        private System.Windows.Forms.Label lbl_Price;
        private System.Windows.Forms.Label lbl_Bill;
        private System.Windows.Forms.TextBox tb_Bill_No;
        private System.Windows.Forms.TextBox tb_Supplier_Name;
        private System.Windows.Forms.TextBox tb_Weight_Brass_QTY;
        private System.Windows.Forms.TextBox tb_Price;
        private System.Windows.Forms.TextBox tb_Bill;
        private System.Windows.Forms.TextBox tb_GST;
        private System.Windows.Forms.ComboBox cb_Material_List;
        private System.Windows.Forms.DateTimePicker dtp_Date;
        private System.Windows.Forms.Button btn_New;
        private System.Windows.Forms.Button btn_Save;
        private System.Windows.Forms.Button btn_Edit;
        private System.Windows.Forms.Button btn_Delete;
    }
}