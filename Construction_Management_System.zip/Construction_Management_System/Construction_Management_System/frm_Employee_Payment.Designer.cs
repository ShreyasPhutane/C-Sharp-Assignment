﻿namespace Construction_Management_System
{
    partial class frm_Employee_Payment
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_Employee_Payment = new System.Windows.Forms.Label();
            this.lbl_Emp_No = new System.Windows.Forms.Label();
            this.lbl_From = new System.Windows.Forms.Label();
            this.lbl_Emp_Name = new System.Windows.Forms.Label();
            this.lbl_To = new System.Windows.Forms.Label();
            this.lbl_Post = new System.Windows.Forms.Label();
            this.lbl_Total_Paid_Day = new System.Windows.Forms.Label();
            this.lbl_Due_Salary = new System.Windows.Forms.Label();
            this.lbl_Salary_Per_Day = new System.Windows.Forms.Label();
            this.lbl_Extra_Days = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.lbl_Full_Day = new System.Windows.Forms.Label();
            this.lbl_Half_Day = new System.Windows.Forms.Label();
            this.lbl_Absent = new System.Windows.Forms.Label();
            this.tb_Emp_No = new System.Windows.Forms.TextBox();
            this.tb_Emp_Name = new System.Windows.Forms.TextBox();
            this.dtp_From = new System.Windows.Forms.DateTimePicker();
            this.dtp_To = new System.Windows.Forms.DateTimePicker();
            this.tb_Full_Day = new System.Windows.Forms.TextBox();
            this.tb_Half_Day = new System.Windows.Forms.TextBox();
            this.tb_Absent = new System.Windows.Forms.TextBox();
            this.tb_Post = new System.Windows.Forms.TextBox();
            this.tb_Salary_Per_Day = new System.Windows.Forms.TextBox();
            this.tb_Total_Paid_Day = new System.Windows.Forms.TextBox();
            this.tb_Extra_Days = new System.Windows.Forms.TextBox();
            this.tb_Due_Salary = new System.Windows.Forms.TextBox();
            this.btn_Paid_And_Save = new System.Windows.Forms.Button();
            this.btn_Edit = new System.Windows.Forms.Button();
            this.btn_Delete = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl_Employee_Payment
            // 
            this.lbl_Employee_Payment.AutoSize = true;
            this.lbl_Employee_Payment.Font = new System.Drawing.Font("Cambria", 30F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Employee_Payment.Location = new System.Drawing.Point(294, 45);
            this.lbl_Employee_Payment.Name = "lbl_Employee_Payment";
            this.lbl_Employee_Payment.Size = new System.Drawing.Size(509, 59);
            this.lbl_Employee_Payment.TabIndex = 0;
            this.lbl_Employee_Payment.Text = "EMPLOYEE PAYMENT";
            // 
            // lbl_Emp_No
            // 
            this.lbl_Emp_No.AutoSize = true;
            this.lbl_Emp_No.Font = new System.Drawing.Font("Cambria", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Emp_No.Location = new System.Drawing.Point(12, 194);
            this.lbl_Emp_No.Name = "lbl_Emp_No";
            this.lbl_Emp_No.Size = new System.Drawing.Size(103, 30);
            this.lbl_Emp_No.TabIndex = 1;
            this.lbl_Emp_No.Text = "EMP NO";
            // 
            // lbl_From
            // 
            this.lbl_From.AutoSize = true;
            this.lbl_From.Font = new System.Drawing.Font("Cambria", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_From.Location = new System.Drawing.Point(12, 280);
            this.lbl_From.Name = "lbl_From";
            this.lbl_From.Size = new System.Drawing.Size(81, 30);
            this.lbl_From.TabIndex = 2;
            this.lbl_From.Text = "FROM";
            // 
            // lbl_Emp_Name
            // 
            this.lbl_Emp_Name.AutoSize = true;
            this.lbl_Emp_Name.Font = new System.Drawing.Font("Cambria", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Emp_Name.Location = new System.Drawing.Point(288, 197);
            this.lbl_Emp_Name.Name = "lbl_Emp_Name";
            this.lbl_Emp_Name.Size = new System.Drawing.Size(137, 30);
            this.lbl_Emp_Name.TabIndex = 3;
            this.lbl_Emp_Name.Text = "EMP NAME";
            // 
            // lbl_To
            // 
            this.lbl_To.AutoSize = true;
            this.lbl_To.Font = new System.Drawing.Font("Cambria", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_To.Location = new System.Drawing.Point(335, 286);
            this.lbl_To.Name = "lbl_To";
            this.lbl_To.Size = new System.Drawing.Size(45, 30);
            this.lbl_To.TabIndex = 4;
            this.lbl_To.Text = "TO";
            // 
            // lbl_Post
            // 
            this.lbl_Post.AutoSize = true;
            this.lbl_Post.Font = new System.Drawing.Font("Cambria", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Post.Location = new System.Drawing.Point(707, 200);
            this.lbl_Post.Name = "lbl_Post";
            this.lbl_Post.Size = new System.Drawing.Size(74, 30);
            this.lbl_Post.TabIndex = 5;
            this.lbl_Post.Text = "POST";
            // 
            // lbl_Total_Paid_Day
            // 
            this.lbl_Total_Paid_Day.AutoSize = true;
            this.lbl_Total_Paid_Day.Font = new System.Drawing.Font("Cambria", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Total_Paid_Day.Location = new System.Drawing.Point(673, 374);
            this.lbl_Total_Paid_Day.Name = "lbl_Total_Paid_Day";
            this.lbl_Total_Paid_Day.Size = new System.Drawing.Size(201, 30);
            this.lbl_Total_Paid_Day.TabIndex = 6;
            this.lbl_Total_Paid_Day.Text = "TOTAL PAID DAY";
            // 
            // lbl_Due_Salary
            // 
            this.lbl_Due_Salary.AutoSize = true;
            this.lbl_Due_Salary.Font = new System.Drawing.Font("Cambria", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Due_Salary.Location = new System.Drawing.Point(675, 521);
            this.lbl_Due_Salary.Name = "lbl_Due_Salary";
            this.lbl_Due_Salary.Size = new System.Drawing.Size(158, 30);
            this.lbl_Due_Salary.TabIndex = 7;
            this.lbl_Due_Salary.Text = "DUE SALARY";
            // 
            // lbl_Salary_Per_Day
            // 
            this.lbl_Salary_Per_Day.AutoSize = true;
            this.lbl_Salary_Per_Day.Font = new System.Drawing.Font("Cambria", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Salary_Per_Day.Location = new System.Drawing.Point(673, 289);
            this.lbl_Salary_Per_Day.Name = "lbl_Salary_Per_Day";
            this.lbl_Salary_Per_Day.Size = new System.Drawing.Size(214, 30);
            this.lbl_Salary_Per_Day.TabIndex = 8;
            this.lbl_Salary_Per_Day.Text = "SALARY/PER DAY";
            // 
            // lbl_Extra_Days
            // 
            this.lbl_Extra_Days.AutoSize = true;
            this.lbl_Extra_Days.Font = new System.Drawing.Font("Cambria", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Extra_Days.Location = new System.Drawing.Point(675, 450);
            this.lbl_Extra_Days.Name = "lbl_Extra_Days";
            this.lbl_Extra_Days.Size = new System.Drawing.Size(156, 30);
            this.lbl_Extra_Days.TabIndex = 9;
            this.lbl_Extra_Days.Text = "EXTRA DAYS";
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Cambria", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(146, 362);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(340, 54);
            this.button1.TabIndex = 10;
            this.button1.Text = "SHOW TOTAL DAYS";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // lbl_Full_Day
            // 
            this.lbl_Full_Day.AutoSize = true;
            this.lbl_Full_Day.Font = new System.Drawing.Font("Cambria", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Full_Day.Location = new System.Drawing.Point(34, 473);
            this.lbl_Full_Day.Name = "lbl_Full_Day";
            this.lbl_Full_Day.Size = new System.Drawing.Size(124, 30);
            this.lbl_Full_Day.TabIndex = 11;
            this.lbl_Full_Day.Text = "FULL DAY";
            // 
            // lbl_Half_Day
            // 
            this.lbl_Half_Day.AutoSize = true;
            this.lbl_Half_Day.Font = new System.Drawing.Font("Cambria", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Half_Day.Location = new System.Drawing.Point(239, 473);
            this.lbl_Half_Day.Name = "lbl_Half_Day";
            this.lbl_Half_Day.Size = new System.Drawing.Size(127, 30);
            this.lbl_Half_Day.TabIndex = 12;
            this.lbl_Half_Day.Text = "HALF DAY";
            // 
            // lbl_Absent
            // 
            this.lbl_Absent.AutoSize = true;
            this.lbl_Absent.Font = new System.Drawing.Font("Cambria", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Absent.Location = new System.Drawing.Point(439, 473);
            this.lbl_Absent.Name = "lbl_Absent";
            this.lbl_Absent.Size = new System.Drawing.Size(105, 30);
            this.lbl_Absent.TabIndex = 13;
            this.lbl_Absent.Text = "ABSENT";
            // 
            // tb_Emp_No
            // 
            this.tb_Emp_No.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Emp_No.Location = new System.Drawing.Point(132, 191);
            this.tb_Emp_No.Name = "tb_Emp_No";
            this.tb_Emp_No.Size = new System.Drawing.Size(139, 36);
            this.tb_Emp_No.TabIndex = 14;
            // 
            // tb_Emp_Name
            // 
            this.tb_Emp_Name.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Emp_Name.Location = new System.Drawing.Point(431, 194);
            this.tb_Emp_Name.Name = "tb_Emp_Name";
            this.tb_Emp_Name.Size = new System.Drawing.Size(254, 36);
            this.tb_Emp_Name.TabIndex = 15;
            // 
            // dtp_From
            // 
            this.dtp_From.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtp_From.Location = new System.Drawing.Point(110, 286);
            this.dtp_From.Name = "dtp_From";
            this.dtp_From.Size = new System.Drawing.Size(192, 26);
            this.dtp_From.TabIndex = 16;
            // 
            // dtp_To
            // 
            this.dtp_To.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtp_To.Location = new System.Drawing.Point(431, 289);
            this.dtp_To.Name = "dtp_To";
            this.dtp_To.Size = new System.Drawing.Size(216, 26);
            this.dtp_To.TabIndex = 17;
            // 
            // tb_Full_Day
            // 
            this.tb_Full_Day.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Full_Day.Location = new System.Drawing.Point(39, 515);
            this.tb_Full_Day.Name = "tb_Full_Day";
            this.tb_Full_Day.Size = new System.Drawing.Size(119, 36);
            this.tb_Full_Day.TabIndex = 18;
            // 
            // tb_Half_Day
            // 
            this.tb_Half_Day.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Half_Day.Location = new System.Drawing.Point(234, 515);
            this.tb_Half_Day.Name = "tb_Half_Day";
            this.tb_Half_Day.Size = new System.Drawing.Size(132, 36);
            this.tb_Half_Day.TabIndex = 19;
            // 
            // tb_Absent
            // 
            this.tb_Absent.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Absent.Location = new System.Drawing.Point(431, 515);
            this.tb_Absent.Name = "tb_Absent";
            this.tb_Absent.Size = new System.Drawing.Size(118, 36);
            this.tb_Absent.TabIndex = 20;
            // 
            // tb_Post
            // 
            this.tb_Post.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Post.Location = new System.Drawing.Point(895, 197);
            this.tb_Post.Name = "tb_Post";
            this.tb_Post.Size = new System.Drawing.Size(200, 36);
            this.tb_Post.TabIndex = 21;
            // 
            // tb_Salary_Per_Day
            // 
            this.tb_Salary_Per_Day.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Salary_Per_Day.Location = new System.Drawing.Point(895, 289);
            this.tb_Salary_Per_Day.Name = "tb_Salary_Per_Day";
            this.tb_Salary_Per_Day.Size = new System.Drawing.Size(200, 36);
            this.tb_Salary_Per_Day.TabIndex = 22;
            // 
            // tb_Total_Paid_Day
            // 
            this.tb_Total_Paid_Day.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Total_Paid_Day.Location = new System.Drawing.Point(895, 374);
            this.tb_Total_Paid_Day.Name = "tb_Total_Paid_Day";
            this.tb_Total_Paid_Day.Size = new System.Drawing.Size(200, 36);
            this.tb_Total_Paid_Day.TabIndex = 23;
            // 
            // tb_Extra_Days
            // 
            this.tb_Extra_Days.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Extra_Days.Location = new System.Drawing.Point(895, 444);
            this.tb_Extra_Days.Name = "tb_Extra_Days";
            this.tb_Extra_Days.Size = new System.Drawing.Size(200, 36);
            this.tb_Extra_Days.TabIndex = 24;
            // 
            // tb_Due_Salary
            // 
            this.tb_Due_Salary.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Due_Salary.Location = new System.Drawing.Point(895, 515);
            this.tb_Due_Salary.Name = "tb_Due_Salary";
            this.tb_Due_Salary.Size = new System.Drawing.Size(200, 36);
            this.tb_Due_Salary.TabIndex = 25;
            // 
            // btn_Paid_And_Save
            // 
            this.btn_Paid_And_Save.Font = new System.Drawing.Font("Cambria", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Paid_And_Save.Location = new System.Drawing.Point(39, 635);
            this.btn_Paid_And_Save.Name = "btn_Paid_And_Save";
            this.btn_Paid_And_Save.Size = new System.Drawing.Size(320, 57);
            this.btn_Paid_And_Save.TabIndex = 26;
            this.btn_Paid_And_Save.Text = "PAID AND SAVE";
            this.btn_Paid_And_Save.UseVisualStyleBackColor = true;
            // 
            // btn_Edit
            // 
            this.btn_Edit.Font = new System.Drawing.Font("Cambria", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Edit.Location = new System.Drawing.Point(455, 635);
            this.btn_Edit.Name = "btn_Edit";
            this.btn_Edit.Size = new System.Drawing.Size(150, 57);
            this.btn_Edit.TabIndex = 27;
            this.btn_Edit.Text = "EDIT";
            this.btn_Edit.UseVisualStyleBackColor = true;
            // 
            // btn_Delete
            // 
            this.btn_Delete.Font = new System.Drawing.Font("Cambria", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Delete.Location = new System.Drawing.Point(695, 635);
            this.btn_Delete.Name = "btn_Delete";
            this.btn_Delete.Size = new System.Drawing.Size(179, 54);
            this.btn_Delete.TabIndex = 28;
            this.btn_Delete.Text = "DELETE";
            this.btn_Delete.UseVisualStyleBackColor = true;
            // 
            // frm_Employee_Payment
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1107, 735);
            this.Controls.Add(this.btn_Delete);
            this.Controls.Add(this.btn_Edit);
            this.Controls.Add(this.btn_Paid_And_Save);
            this.Controls.Add(this.tb_Due_Salary);
            this.Controls.Add(this.tb_Extra_Days);
            this.Controls.Add(this.tb_Total_Paid_Day);
            this.Controls.Add(this.tb_Salary_Per_Day);
            this.Controls.Add(this.tb_Post);
            this.Controls.Add(this.tb_Absent);
            this.Controls.Add(this.tb_Half_Day);
            this.Controls.Add(this.tb_Full_Day);
            this.Controls.Add(this.dtp_To);
            this.Controls.Add(this.dtp_From);
            this.Controls.Add(this.tb_Emp_Name);
            this.Controls.Add(this.tb_Emp_No);
            this.Controls.Add(this.lbl_Absent);
            this.Controls.Add(this.lbl_Half_Day);
            this.Controls.Add(this.lbl_Full_Day);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.lbl_Extra_Days);
            this.Controls.Add(this.lbl_Salary_Per_Day);
            this.Controls.Add(this.lbl_Due_Salary);
            this.Controls.Add(this.lbl_Total_Paid_Day);
            this.Controls.Add(this.lbl_Post);
            this.Controls.Add(this.lbl_To);
            this.Controls.Add(this.lbl_Emp_Name);
            this.Controls.Add(this.lbl_From);
            this.Controls.Add(this.lbl_Emp_No);
            this.Controls.Add(this.lbl_Employee_Payment);
            this.Name = "frm_Employee_Payment";
            this.Text = "EMPLOYEE  PAYMENT DETAILS";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_Employee_Payment;
        private System.Windows.Forms.Label lbl_Emp_No;
        private System.Windows.Forms.Label lbl_From;
        private System.Windows.Forms.Label lbl_Emp_Name;
        private System.Windows.Forms.Label lbl_To;
        private System.Windows.Forms.Label lbl_Post;
        private System.Windows.Forms.Label lbl_Total_Paid_Day;
        private System.Windows.Forms.Label lbl_Due_Salary;
        private System.Windows.Forms.Label lbl_Salary_Per_Day;
        private System.Windows.Forms.Label lbl_Extra_Days;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label lbl_Full_Day;
        private System.Windows.Forms.Label lbl_Half_Day;
        private System.Windows.Forms.Label lbl_Absent;
        private System.Windows.Forms.TextBox tb_Emp_No;
        private System.Windows.Forms.TextBox tb_Emp_Name;
        private System.Windows.Forms.DateTimePicker dtp_From;
        private System.Windows.Forms.DateTimePicker dtp_To;
        private System.Windows.Forms.TextBox tb_Full_Day;
        private System.Windows.Forms.TextBox tb_Half_Day;
        private System.Windows.Forms.TextBox tb_Absent;
        private System.Windows.Forms.TextBox tb_Post;
        private System.Windows.Forms.TextBox tb_Salary_Per_Day;
        private System.Windows.Forms.TextBox tb_Total_Paid_Day;
        private System.Windows.Forms.TextBox tb_Extra_Days;
        private System.Windows.Forms.TextBox tb_Due_Salary;
        private System.Windows.Forms.Button btn_Paid_And_Save;
        private System.Windows.Forms.Button btn_Edit;
        private System.Windows.Forms.Button btn_Delete;
    }
}