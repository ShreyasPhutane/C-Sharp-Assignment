﻿namespace Destiny.cs
{
    partial class frm_Expectations
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.lbl_Your_Expectations = new System.Windows.Forms.Label();
            this.gb_Personal_Details = new System.Windows.Forms.GroupBox();
            this.cmb_Residing_City = new System.Windows.Forms.ComboBox();
            this.tb_Sub_Caste = new System.Windows.Forms.TextBox();
            this.tb_Caste = new System.Windows.Forms.TextBox();
            this.lbl_Sub_Caste = new System.Windows.Forms.Label();
            this.lbl_Caste = new System.Windows.Forms.Label();
            this.lbl_Residing_City = new System.Windows.Forms.Label();
            this.radioButton4 = new System.Windows.Forms.RadioButton();
            this.radioButton3 = new System.Windows.Forms.RadioButton();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.lbl_Marital_Status = new System.Windows.Forms.Label();
            this.gb_Physical_Attributes = new System.Windows.Forms.GroupBox();
            this.cmb_Complexion = new System.Windows.Forms.ComboBox();
            this.cmb_Body_Type = new System.Windows.Forms.ComboBox();
            this.rb_Physically_Challenged = new System.Windows.Forms.RadioButton();
            this.rb_normal = new System.Windows.Forms.RadioButton();
            this.rb_Dark = new System.Windows.Forms.RadioButton();
            this.lbl_Physical_Status = new System.Windows.Forms.Label();
            this.lbl_Complexion = new System.Windows.Forms.Label();
            this.lbl_Body_Type = new System.Windows.Forms.Label();
            this.gb_Habits = new System.Windows.Forms.GroupBox();
            this.cmb_Drinking = new System.Windows.Forms.ComboBox();
            this.cmb_Smoking = new System.Windows.Forms.ComboBox();
            this.cmb_Food = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lbl_Drinking = new System.Windows.Forms.Label();
            this.lbl_Smoking = new System.Windows.Forms.Label();
            this.lbl_Food = new System.Windows.Forms.Label();
            this.gb_Education_And_Occupation = new System.Windows.Forms.GroupBox();
            this.cmb_Employed_In = new System.Windows.Forms.ComboBox();
            this.lbl_Highest_Education = new System.Windows.Forms.Label();
            this.cmb_Highest_Educatiion = new System.Windows.Forms.ComboBox();
            this.lbl_Occupation = new System.Windows.Forms.Label();
            this.cmb_Occupation = new System.Windows.Forms.ComboBox();
            this.lbl_Employed_In = new System.Windows.Forms.Label();
            this.lbl_Monthly_Income = new System.Windows.Forms.Label();
            this.cmb_Monthly_Income = new System.Windows.Forms.ComboBox();
            this.btn_Next = new System.Windows.Forms.Button();
            this.btn_Save = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.cmb_Family_Status = new System.Windows.Forms.ComboBox();
            this.cmb_Family_Type = new System.Windows.Forms.ComboBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.panel1.SuspendLayout();
            this.gb_Personal_Details.SuspendLayout();
            this.gb_Physical_Attributes.SuspendLayout();
            this.gb_Habits.SuspendLayout();
            this.gb_Education_And_Occupation.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel1.Controls.Add(this.lbl_Your_Expectations);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1482, 116);
            this.panel1.TabIndex = 19;
            // 
            // lbl_Your_Expectations
            // 
            this.lbl_Your_Expectations.AutoSize = true;
            this.lbl_Your_Expectations.Font = new System.Drawing.Font("Times New Roman", 36F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Your_Expectations.ForeColor = System.Drawing.Color.Navy;
            this.lbl_Your_Expectations.Location = new System.Drawing.Point(517, 21);
            this.lbl_Your_Expectations.Name = "lbl_Your_Expectations";
            this.lbl_Your_Expectations.Size = new System.Drawing.Size(480, 67);
            this.lbl_Your_Expectations.TabIndex = 0;
            this.lbl_Your_Expectations.Text = "Your Expectations";
            // 
            // gb_Personal_Details
            // 
            this.gb_Personal_Details.Controls.Add(this.cmb_Residing_City);
            this.gb_Personal_Details.Controls.Add(this.tb_Sub_Caste);
            this.gb_Personal_Details.Controls.Add(this.tb_Caste);
            this.gb_Personal_Details.Controls.Add(this.lbl_Sub_Caste);
            this.gb_Personal_Details.Controls.Add(this.lbl_Caste);
            this.gb_Personal_Details.Controls.Add(this.lbl_Residing_City);
            this.gb_Personal_Details.Controls.Add(this.radioButton4);
            this.gb_Personal_Details.Controls.Add(this.radioButton3);
            this.gb_Personal_Details.Controls.Add(this.radioButton2);
            this.gb_Personal_Details.Controls.Add(this.radioButton1);
            this.gb_Personal_Details.Controls.Add(this.lbl_Marital_Status);
            this.gb_Personal_Details.Font = new System.Drawing.Font("Times New Roman", 19.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gb_Personal_Details.Location = new System.Drawing.Point(33, 122);
            this.gb_Personal_Details.Name = "gb_Personal_Details";
            this.gb_Personal_Details.Size = new System.Drawing.Size(617, 358);
            this.gb_Personal_Details.TabIndex = 20;
            this.gb_Personal_Details.TabStop = false;
            this.gb_Personal_Details.Text = "Personal Details ";
            // 
            // cmb_Residing_City
            // 
            this.cmb_Residing_City.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_Residing_City.FormattingEnabled = true;
            this.cmb_Residing_City.Items.AddRange(new object[] {
            "Satara",
            "Kolhapur",
            "Pune",
            "Mumbai"});
            this.cmb_Residing_City.Location = new System.Drawing.Point(188, 282);
            this.cmb_Residing_City.Name = "cmb_Residing_City";
            this.cmb_Residing_City.Size = new System.Drawing.Size(167, 37);
            this.cmb_Residing_City.TabIndex = 45;
            // 
            // tb_Sub_Caste
            // 
            this.tb_Sub_Caste.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Sub_Caste.Location = new System.Drawing.Point(188, 217);
            this.tb_Sub_Caste.Name = "tb_Sub_Caste";
            this.tb_Sub_Caste.Size = new System.Drawing.Size(167, 36);
            this.tb_Sub_Caste.TabIndex = 37;
            // 
            // tb_Caste
            // 
            this.tb_Caste.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Caste.Location = new System.Drawing.Point(188, 158);
            this.tb_Caste.Name = "tb_Caste";
            this.tb_Caste.Size = new System.Drawing.Size(167, 36);
            this.tb_Caste.TabIndex = 36;
            // 
            // lbl_Sub_Caste
            // 
            this.lbl_Sub_Caste.AutoSize = true;
            this.lbl_Sub_Caste.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Sub_Caste.Location = new System.Drawing.Point(12, 220);
            this.lbl_Sub_Caste.Name = "lbl_Sub_Caste";
            this.lbl_Sub_Caste.Size = new System.Drawing.Size(115, 29);
            this.lbl_Sub_Caste.TabIndex = 40;
            this.lbl_Sub_Caste.Text = "Sub Caste";
            // 
            // lbl_Caste
            // 
            this.lbl_Caste.AutoSize = true;
            this.lbl_Caste.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Caste.Location = new System.Drawing.Point(12, 161);
            this.lbl_Caste.Name = "lbl_Caste";
            this.lbl_Caste.Size = new System.Drawing.Size(69, 29);
            this.lbl_Caste.TabIndex = 38;
            this.lbl_Caste.Text = "Caste";
            // 
            // lbl_Residing_City
            // 
            this.lbl_Residing_City.AutoSize = true;
            this.lbl_Residing_City.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Residing_City.Location = new System.Drawing.Point(12, 285);
            this.lbl_Residing_City.Name = "lbl_Residing_City";
            this.lbl_Residing_City.Size = new System.Drawing.Size(150, 29);
            this.lbl_Residing_City.TabIndex = 44;
            this.lbl_Residing_City.Text = "Residing City";
            // 
            // radioButton4
            // 
            this.radioButton4.AutoSize = true;
            this.radioButton4.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton4.Location = new System.Drawing.Point(188, 110);
            this.radioButton4.Name = "radioButton4";
            this.radioButton4.Size = new System.Drawing.Size(227, 33);
            this.radioButton4.TabIndex = 35;
            this.radioButton4.TabStop = true;
            this.radioButton4.Text = "Awaiting  Divorced";
            this.radioButton4.UseVisualStyleBackColor = true;
            // 
            // radioButton3
            // 
            this.radioButton3.AutoSize = true;
            this.radioButton3.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton3.Location = new System.Drawing.Point(486, 67);
            this.radioButton3.Name = "radioButton3";
            this.radioButton3.Size = new System.Drawing.Size(126, 33);
            this.radioButton3.TabIndex = 34;
            this.radioButton3.TabStop = true;
            this.radioButton3.Text = "Divorced";
            this.radioButton3.UseVisualStyleBackColor = true;
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton2.Location = new System.Drawing.Point(373, 69);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(107, 33);
            this.radioButton2.TabIndex = 33;
            this.radioButton2.TabStop = true;
            this.radioButton2.Text = "Widow";
            this.radioButton2.UseVisualStyleBackColor = true;
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton1.Location = new System.Drawing.Point(188, 71);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(179, 33);
            this.radioButton1.TabIndex = 32;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "Never Married";
            this.radioButton1.UseVisualStyleBackColor = true;
            // 
            // lbl_Marital_Status
            // 
            this.lbl_Marital_Status.AutoSize = true;
            this.lbl_Marital_Status.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Marital_Status.Location = new System.Drawing.Point(12, 71);
            this.lbl_Marital_Status.Name = "lbl_Marital_Status";
            this.lbl_Marital_Status.Size = new System.Drawing.Size(158, 29);
            this.lbl_Marital_Status.TabIndex = 18;
            this.lbl_Marital_Status.Text = "Marital Status:";
            // 
            // gb_Physical_Attributes
            // 
            this.gb_Physical_Attributes.Controls.Add(this.cmb_Complexion);
            this.gb_Physical_Attributes.Controls.Add(this.cmb_Body_Type);
            this.gb_Physical_Attributes.Controls.Add(this.rb_Physically_Challenged);
            this.gb_Physical_Attributes.Controls.Add(this.rb_normal);
            this.gb_Physical_Attributes.Controls.Add(this.rb_Dark);
            this.gb_Physical_Attributes.Controls.Add(this.lbl_Physical_Status);
            this.gb_Physical_Attributes.Controls.Add(this.lbl_Complexion);
            this.gb_Physical_Attributes.Controls.Add(this.lbl_Body_Type);
            this.gb_Physical_Attributes.Font = new System.Drawing.Font("Times New Roman", 20F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gb_Physical_Attributes.Location = new System.Drawing.Point(33, 486);
            this.gb_Physical_Attributes.Name = "gb_Physical_Attributes";
            this.gb_Physical_Attributes.Size = new System.Drawing.Size(617, 229);
            this.gb_Physical_Attributes.TabIndex = 21;
            this.gb_Physical_Attributes.TabStop = false;
            this.gb_Physical_Attributes.Text = "Physical Attributes";
            // 
            // cmb_Complexion
            // 
            this.cmb_Complexion.Font = new System.Drawing.Font("Times New Roman", 15F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_Complexion.FormattingEnabled = true;
            this.cmb_Complexion.Items.AddRange(new object[] {
            "Fair",
            "Over Fair",
            "Wheatish",
            "Wheatish Brown"});
            this.cmb_Complexion.Location = new System.Drawing.Point(197, 121);
            this.cmb_Complexion.Name = "cmb_Complexion";
            this.cmb_Complexion.Size = new System.Drawing.Size(192, 38);
            this.cmb_Complexion.TabIndex = 36;
            // 
            // cmb_Body_Type
            // 
            this.cmb_Body_Type.Font = new System.Drawing.Font("Times New Roman", 15F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_Body_Type.FormattingEnabled = true;
            this.cmb_Body_Type.Items.AddRange(new object[] {
            "Slim",
            "Average",
            "Athietic",
            "Heavy"});
            this.cmb_Body_Type.Location = new System.Drawing.Point(197, 52);
            this.cmb_Body_Type.Name = "cmb_Body_Type";
            this.cmb_Body_Type.Size = new System.Drawing.Size(192, 38);
            this.cmb_Body_Type.TabIndex = 35;
            // 
            // rb_Physically_Challenged
            // 
            this.rb_Physically_Challenged.AutoSize = true;
            this.rb_Physically_Challenged.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_Physically_Challenged.Location = new System.Drawing.Point(314, 181);
            this.rb_Physically_Challenged.Name = "rb_Physically_Challenged";
            this.rb_Physically_Challenged.Size = new System.Drawing.Size(256, 33);
            this.rb_Physically_Challenged.TabIndex = 34;
            this.rb_Physically_Challenged.Text = "Physically Challenged";
            this.rb_Physically_Challenged.UseVisualStyleBackColor = true;
            // 
            // rb_normal
            // 
            this.rb_normal.AutoSize = true;
            this.rb_normal.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_normal.Location = new System.Drawing.Point(197, 183);
            this.rb_normal.Name = "rb_normal";
            this.rb_normal.Size = new System.Drawing.Size(110, 33);
            this.rb_normal.TabIndex = 33;
            this.rb_normal.Text = "Normal";
            this.rb_normal.UseVisualStyleBackColor = true;
            // 
            // rb_Dark
            // 
            this.rb_Dark.AutoSize = true;
            this.rb_Dark.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_Dark.Location = new System.Drawing.Point(1023, 357);
            this.rb_Dark.Name = "rb_Dark";
            this.rb_Dark.Size = new System.Drawing.Size(63, 23);
            this.rb_Dark.TabIndex = 32;
            this.rb_Dark.Text = "Dark";
            this.rb_Dark.UseVisualStyleBackColor = true;
            // 
            // lbl_Physical_Status
            // 
            this.lbl_Physical_Status.AutoSize = true;
            this.lbl_Physical_Status.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Physical_Status.Location = new System.Drawing.Point(7, 185);
            this.lbl_Physical_Status.Name = "lbl_Physical_Status";
            this.lbl_Physical_Status.Size = new System.Drawing.Size(165, 29);
            this.lbl_Physical_Status.TabIndex = 23;
            this.lbl_Physical_Status.Text = "Physical Status";
            // 
            // lbl_Complexion
            // 
            this.lbl_Complexion.AutoSize = true;
            this.lbl_Complexion.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Complexion.Location = new System.Drawing.Point(7, 125);
            this.lbl_Complexion.Name = "lbl_Complexion";
            this.lbl_Complexion.Size = new System.Drawing.Size(138, 29);
            this.lbl_Complexion.TabIndex = 22;
            this.lbl_Complexion.Text = "Complexion";
            // 
            // lbl_Body_Type
            // 
            this.lbl_Body_Type.AutoSize = true;
            this.lbl_Body_Type.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Body_Type.Location = new System.Drawing.Point(7, 52);
            this.lbl_Body_Type.Name = "lbl_Body_Type";
            this.lbl_Body_Type.Size = new System.Drawing.Size(123, 29);
            this.lbl_Body_Type.TabIndex = 21;
            this.lbl_Body_Type.Text = "Body Type";
            // 
            // gb_Habits
            // 
            this.gb_Habits.Controls.Add(this.cmb_Drinking);
            this.gb_Habits.Controls.Add(this.cmb_Smoking);
            this.gb_Habits.Controls.Add(this.cmb_Food);
            this.gb_Habits.Controls.Add(this.label3);
            this.gb_Habits.Controls.Add(this.label1);
            this.gb_Habits.Controls.Add(this.label2);
            this.gb_Habits.Controls.Add(this.lbl_Drinking);
            this.gb_Habits.Controls.Add(this.lbl_Smoking);
            this.gb_Habits.Controls.Add(this.lbl_Food);
            this.gb_Habits.Font = new System.Drawing.Font("Times New Roman", 20F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gb_Habits.Location = new System.Drawing.Point(656, 122);
            this.gb_Habits.Name = "gb_Habits";
            this.gb_Habits.Size = new System.Drawing.Size(656, 161);
            this.gb_Habits.TabIndex = 22;
            this.gb_Habits.TabStop = false;
            this.gb_Habits.Text = "Habits";
            // 
            // cmb_Drinking
            // 
            this.cmb_Drinking.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_Drinking.FormattingEnabled = true;
            this.cmb_Drinking.Items.AddRange(new object[] {
            "No ",
            "Drink Socially",
            "Yes"});
            this.cmb_Drinking.Location = new System.Drawing.Point(158, 95);
            this.cmb_Drinking.Name = "cmb_Drinking";
            this.cmb_Drinking.Size = new System.Drawing.Size(139, 37);
            this.cmb_Drinking.TabIndex = 25;
            // 
            // cmb_Smoking
            // 
            this.cmb_Smoking.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_Smoking.FormattingEnabled = true;
            this.cmb_Smoking.Items.AddRange(new object[] {
            "No",
            "Occasionally",
            "Yes"});
            this.cmb_Smoking.Location = new System.Drawing.Point(480, 38);
            this.cmb_Smoking.Name = "cmb_Smoking";
            this.cmb_Smoking.Size = new System.Drawing.Size(139, 37);
            this.cmb_Smoking.TabIndex = 25;
            // 
            // cmb_Food
            // 
            this.cmb_Food.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_Food.FormattingEnabled = true;
            this.cmb_Food.Items.AddRange(new object[] {
            "Vegetarian",
            "Non-Vegetarian",
            "Eggetarian"});
            this.cmb_Food.Location = new System.Drawing.Point(158, 38);
            this.cmb_Food.Name = "cmb_Food";
            this.cmb_Food.Size = new System.Drawing.Size(139, 37);
            this.cmb_Food.TabIndex = 25;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(4, 46);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(66, 29);
            this.label3.TabIndex = 38;
            this.label3.Text = "Food";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(4, 108);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(101, 29);
            this.label1.TabIndex = 37;
            this.label1.Text = "Drinking";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(326, 46);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(103, 29);
            this.label2.TabIndex = 36;
            this.label2.Text = "Smoking";
            // 
            // lbl_Drinking
            // 
            this.lbl_Drinking.AutoSize = true;
            this.lbl_Drinking.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Drinking.Location = new System.Drawing.Point(-225, 314);
            this.lbl_Drinking.Name = "lbl_Drinking";
            this.lbl_Drinking.Size = new System.Drawing.Size(69, 19);
            this.lbl_Drinking.TabIndex = 31;
            this.lbl_Drinking.Text = "Drinking";
            // 
            // lbl_Smoking
            // 
            this.lbl_Smoking.AutoSize = true;
            this.lbl_Smoking.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Smoking.Location = new System.Drawing.Point(-225, 202);
            this.lbl_Smoking.Name = "lbl_Smoking";
            this.lbl_Smoking.Size = new System.Drawing.Size(69, 19);
            this.lbl_Smoking.TabIndex = 29;
            this.lbl_Smoking.Text = "Smoking";
            // 
            // lbl_Food
            // 
            this.lbl_Food.AutoSize = true;
            this.lbl_Food.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Food.Location = new System.Drawing.Point(-225, 85);
            this.lbl_Food.Name = "lbl_Food";
            this.lbl_Food.Size = new System.Drawing.Size(44, 19);
            this.lbl_Food.TabIndex = 26;
            this.lbl_Food.Text = "Food";
            // 
            // gb_Education_And_Occupation
            // 
            this.gb_Education_And_Occupation.Controls.Add(this.cmb_Employed_In);
            this.gb_Education_And_Occupation.Controls.Add(this.lbl_Highest_Education);
            this.gb_Education_And_Occupation.Controls.Add(this.cmb_Highest_Educatiion);
            this.gb_Education_And_Occupation.Controls.Add(this.lbl_Occupation);
            this.gb_Education_And_Occupation.Controls.Add(this.cmb_Occupation);
            this.gb_Education_And_Occupation.Controls.Add(this.lbl_Employed_In);
            this.gb_Education_And_Occupation.Controls.Add(this.lbl_Monthly_Income);
            this.gb_Education_And_Occupation.Controls.Add(this.cmb_Monthly_Income);
            this.gb_Education_And_Occupation.Font = new System.Drawing.Font("Times New Roman", 20F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gb_Education_And_Occupation.Location = new System.Drawing.Point(656, 302);
            this.gb_Education_And_Occupation.Name = "gb_Education_And_Occupation";
            this.gb_Education_And_Occupation.Size = new System.Drawing.Size(525, 274);
            this.gb_Education_And_Occupation.TabIndex = 23;
            this.gb_Education_And_Occupation.TabStop = false;
            this.gb_Education_And_Occupation.Text = "Education And  Occupation";
            // 
            // cmb_Employed_In
            // 
            this.cmb_Employed_In.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_Employed_In.FormattingEnabled = true;
            this.cmb_Employed_In.Items.AddRange(new object[] {
            "Government",
            "Private",
            "Business",
            "Defence",
            "Self Employed"});
            this.cmb_Employed_In.Location = new System.Drawing.Point(216, 162);
            this.cmb_Employed_In.Name = "cmb_Employed_In";
            this.cmb_Employed_In.Size = new System.Drawing.Size(246, 37);
            this.cmb_Employed_In.TabIndex = 15;
            // 
            // lbl_Highest_Education
            // 
            this.lbl_Highest_Education.AutoSize = true;
            this.lbl_Highest_Education.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Highest_Education.Location = new System.Drawing.Point(6, 56);
            this.lbl_Highest_Education.Name = "lbl_Highest_Education";
            this.lbl_Highest_Education.Size = new System.Drawing.Size(198, 29);
            this.lbl_Highest_Education.TabIndex = 10;
            this.lbl_Highest_Education.Text = "Highest Education";
            // 
            // cmb_Highest_Educatiion
            // 
            this.cmb_Highest_Educatiion.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_Highest_Educatiion.FormattingEnabled = true;
            this.cmb_Highest_Educatiion.Location = new System.Drawing.Point(216, 53);
            this.cmb_Highest_Educatiion.Name = "cmb_Highest_Educatiion";
            this.cmb_Highest_Educatiion.Size = new System.Drawing.Size(246, 37);
            this.cmb_Highest_Educatiion.TabIndex = 9;
            // 
            // lbl_Occupation
            // 
            this.lbl_Occupation.AutoSize = true;
            this.lbl_Occupation.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Occupation.Location = new System.Drawing.Point(6, 110);
            this.lbl_Occupation.Name = "lbl_Occupation";
            this.lbl_Occupation.Size = new System.Drawing.Size(129, 29);
            this.lbl_Occupation.TabIndex = 12;
            this.lbl_Occupation.Text = "Occupation";
            // 
            // cmb_Occupation
            // 
            this.cmb_Occupation.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_Occupation.FormattingEnabled = true;
            this.cmb_Occupation.Location = new System.Drawing.Point(216, 107);
            this.cmb_Occupation.Name = "cmb_Occupation";
            this.cmb_Occupation.Size = new System.Drawing.Size(246, 37);
            this.cmb_Occupation.TabIndex = 11;
            // 
            // lbl_Employed_In
            // 
            this.lbl_Employed_In.AutoSize = true;
            this.lbl_Employed_In.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Employed_In.Location = new System.Drawing.Point(6, 165);
            this.lbl_Employed_In.Name = "lbl_Employed_In";
            this.lbl_Employed_In.Size = new System.Drawing.Size(144, 29);
            this.lbl_Employed_In.TabIndex = 14;
            this.lbl_Employed_In.Text = "Employed In";
            // 
            // lbl_Monthly_Income
            // 
            this.lbl_Monthly_Income.AutoSize = true;
            this.lbl_Monthly_Income.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Monthly_Income.Location = new System.Drawing.Point(6, 219);
            this.lbl_Monthly_Income.Name = "lbl_Monthly_Income";
            this.lbl_Monthly_Income.Size = new System.Drawing.Size(182, 29);
            this.lbl_Monthly_Income.TabIndex = 16;
            this.lbl_Monthly_Income.Text = "Monthly Income";
            // 
            // cmb_Monthly_Income
            // 
            this.cmb_Monthly_Income.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_Monthly_Income.FormattingEnabled = true;
            this.cmb_Monthly_Income.Location = new System.Drawing.Point(216, 216);
            this.cmb_Monthly_Income.Name = "cmb_Monthly_Income";
            this.cmb_Monthly_Income.Size = new System.Drawing.Size(246, 37);
            this.cmb_Monthly_Income.TabIndex = 20;
            // 
            // btn_Next
            // 
            this.btn_Next.BackColor = System.Drawing.SystemColors.Info;
            this.btn_Next.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Next.ForeColor = System.Drawing.Color.Red;
            this.btn_Next.Location = new System.Drawing.Point(1332, 683);
            this.btn_Next.Name = "btn_Next";
            this.btn_Next.Size = new System.Drawing.Size(138, 46);
            this.btn_Next.TabIndex = 25;
            this.btn_Next.Text = "Next";
            this.btn_Next.UseVisualStyleBackColor = false;
            // 
            // btn_Save
            // 
            this.btn_Save.BackColor = System.Drawing.SystemColors.Info;
            this.btn_Save.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Save.ForeColor = System.Drawing.Color.Red;
            this.btn_Save.Location = new System.Drawing.Point(1174, 683);
            this.btn_Save.Name = "btn_Save";
            this.btn_Save.Size = new System.Drawing.Size(138, 46);
            this.btn_Save.TabIndex = 26;
            this.btn_Save.Text = "Save";
            this.btn_Save.UseVisualStyleBackColor = false;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(6, 61);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(151, 29);
            this.label5.TabIndex = 0;
            this.label5.Text = "Family Status";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(6, 116);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(138, 29);
            this.label4.TabIndex = 1;
            this.label4.Text = "Family Type";
            // 
            // cmb_Family_Status
            // 
            this.cmb_Family_Status.Font = new System.Drawing.Font("Times New Roman", 15F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_Family_Status.FormattingEnabled = true;
            this.cmb_Family_Status.Items.AddRange(new object[] {
            "Middle Class",
            "Upper Middle Class",
            "Rich",
            "Affluent"});
            this.cmb_Family_Status.Location = new System.Drawing.Point(177, 57);
            this.cmb_Family_Status.Name = "cmb_Family_Status";
            this.cmb_Family_Status.Size = new System.Drawing.Size(231, 38);
            this.cmb_Family_Status.TabIndex = 3;
            // 
            // cmb_Family_Type
            // 
            this.cmb_Family_Type.Font = new System.Drawing.Font("Times New Roman", 15F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_Family_Type.FormattingEnabled = true;
            this.cmb_Family_Type.Items.AddRange(new object[] {
            "Joint",
            "Nuclear"});
            this.cmb_Family_Type.Location = new System.Drawing.Point(177, 112);
            this.cmb_Family_Type.Name = "cmb_Family_Type";
            this.cmb_Family_Type.Size = new System.Drawing.Size(231, 38);
            this.cmb_Family_Type.TabIndex = 4;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.cmb_Family_Type);
            this.groupBox3.Controls.Add(this.cmb_Family_Status);
            this.groupBox3.Controls.Add(this.label4);
            this.groupBox3.Controls.Add(this.label5);
            this.groupBox3.Font = new System.Drawing.Font("Times New Roman", 19.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox3.Location = new System.Drawing.Point(656, 584);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(448, 157);
            this.groupBox3.TabIndex = 24;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Family Profile";
            // 
            // frm_Expectations
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ClientSize = new System.Drawing.Size(1482, 753);
            this.Controls.Add(this.btn_Save);
            this.Controls.Add(this.btn_Next);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.gb_Education_And_Occupation);
            this.Controls.Add(this.gb_Habits);
            this.Controls.Add(this.gb_Physical_Attributes);
            this.Controls.Add(this.gb_Personal_Details);
            this.Controls.Add(this.panel1);
            this.Name = "frm_Expectations";
            this.Text = "Expectations";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.gb_Personal_Details.ResumeLayout(false);
            this.gb_Personal_Details.PerformLayout();
            this.gb_Physical_Attributes.ResumeLayout(false);
            this.gb_Physical_Attributes.PerformLayout();
            this.gb_Habits.ResumeLayout(false);
            this.gb_Habits.PerformLayout();
            this.gb_Education_And_Occupation.ResumeLayout(false);
            this.gb_Education_And_Occupation.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lbl_Your_Expectations;
        private System.Windows.Forms.GroupBox gb_Personal_Details;
        private System.Windows.Forms.ComboBox cmb_Residing_City;
        private System.Windows.Forms.TextBox tb_Sub_Caste;
        private System.Windows.Forms.TextBox tb_Caste;
        private System.Windows.Forms.Label lbl_Sub_Caste;
        private System.Windows.Forms.Label lbl_Caste;
        private System.Windows.Forms.Label lbl_Residing_City;
        private System.Windows.Forms.RadioButton radioButton4;
        private System.Windows.Forms.RadioButton radioButton3;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.Label lbl_Marital_Status;
        private System.Windows.Forms.GroupBox gb_Physical_Attributes;
        private System.Windows.Forms.ComboBox cmb_Complexion;
        private System.Windows.Forms.ComboBox cmb_Body_Type;
        private System.Windows.Forms.RadioButton rb_Physically_Challenged;
        private System.Windows.Forms.RadioButton rb_normal;
        private System.Windows.Forms.RadioButton rb_Dark;
        private System.Windows.Forms.Label lbl_Physical_Status;
        private System.Windows.Forms.Label lbl_Complexion;
        private System.Windows.Forms.Label lbl_Body_Type;
        private System.Windows.Forms.GroupBox gb_Habits;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lbl_Drinking;
        private System.Windows.Forms.Label lbl_Smoking;
        private System.Windows.Forms.Label lbl_Food;
        private System.Windows.Forms.GroupBox gb_Education_And_Occupation;
        private System.Windows.Forms.ComboBox cmb_Employed_In;
        private System.Windows.Forms.Label lbl_Highest_Education;
        private System.Windows.Forms.ComboBox cmb_Highest_Educatiion;
        private System.Windows.Forms.Label lbl_Occupation;
        private System.Windows.Forms.ComboBox cmb_Occupation;
        private System.Windows.Forms.Label lbl_Employed_In;
        private System.Windows.Forms.Label lbl_Monthly_Income;
        private System.Windows.Forms.ComboBox cmb_Monthly_Income;
        private System.Windows.Forms.ComboBox cmb_Drinking;
        private System.Windows.Forms.ComboBox cmb_Smoking;
        private System.Windows.Forms.ComboBox cmb_Food;
        private System.Windows.Forms.Button btn_Next;
        private System.Windows.Forms.Button btn_Save;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox cmb_Family_Status;
        private System.Windows.Forms.ComboBox cmb_Family_Type;
        private System.Windows.Forms.GroupBox groupBox3;
    }
}