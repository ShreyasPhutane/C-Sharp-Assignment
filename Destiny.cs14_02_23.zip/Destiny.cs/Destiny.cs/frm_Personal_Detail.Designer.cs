﻿namespace Destiny.cs
{
    partial class frm_Personal_Detail
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.lbl_Start_A_New_Life = new System.Windows.Forms.Label();
            this.lbl_Destiny = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.s = new System.Windows.Forms.GroupBox();
            this.tb_ID = new System.Windows.Forms.TextBox();
            this.lbl_ID = new System.Windows.Forms.Label();
            this.tb_Address = new System.Windows.Forms.TextBox();
            this.tb_Cast = new System.Windows.Forms.TextBox();
            this.tb_Religion = new System.Windows.Forms.TextBox();
            this.tb_Mobile_No = new System.Windows.Forms.TextBox();
            this.lbl_Address = new System.Windows.Forms.Label();
            this.lbl_Cast = new System.Windows.Forms.Label();
            this.lbl_Religion = new System.Windows.Forms.Label();
            this.lbl_Mobile_No = new System.Windows.Forms.Label();
            this.dtp_DOB = new System.Windows.Forms.DateTimePicker();
            this.lbl_DOB = new System.Windows.Forms.Label();
            this.tb_Gender = new System.Windows.Forms.TextBox();
            this.lbl_Gender = new System.Windows.Forms.Label();
            this.tb_Last_Name = new System.Windows.Forms.TextBox();
            this.lbl_Last_Name = new System.Windows.Forms.Label();
            this.v = new System.Windows.Forms.TextBox();
            this.lbl_First_Name = new System.Windows.Forms.Label();
            this.btn_Upload = new System.Windows.Forms.Button();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.lbl_Registration_Details = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.panel1.SuspendLayout();
            this.s.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            this.panel4.SuspendLayout();
            this.SuspendLayout();
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::Destiny.cs.Properties.Resources._240_F_249970957_tuBtAHEXSTyetIRq5bA2htD955XU5Nup;
            this.pictureBox3.Location = new System.Drawing.Point(0, 0);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(607, 111);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 1;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Destiny.cs.Properties.Resources._240_F_249970957_tuBtAHEXSTyetIRq5bA2htD955XU5Nup;
            this.pictureBox1.Location = new System.Drawing.Point(871, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(611, 111);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::Destiny.cs.Properties.Resources.indian_wedding_character_set_23_2148631133;
            this.pictureBox2.Location = new System.Drawing.Point(0, 111);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(488, 640);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 3;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::Destiny.cs.Properties.Resources.indian_wedding_character_set_23_2148631133;
            this.pictureBox4.Location = new System.Drawing.Point(1004, 111);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(480, 640);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 4;
            this.pictureBox4.TabStop = false;
            // 
            // lbl_Start_A_New_Life
            // 
            this.lbl_Start_A_New_Life.AutoSize = true;
            this.lbl_Start_A_New_Life.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Start_A_New_Life.Location = new System.Drawing.Point(686, 63);
            this.lbl_Start_A_New_Life.Name = "lbl_Start_A_New_Life";
            this.lbl_Start_A_New_Life.Size = new System.Drawing.Size(118, 18);
            this.lbl_Start_A_New_Life.TabIndex = 15;
            this.lbl_Start_A_New_Life.Text = "-Start A New Life";
            // 
            // lbl_Destiny
            // 
            this.lbl_Destiny.AutoSize = true;
            this.lbl_Destiny.Font = new System.Drawing.Font("Palatino Linotype", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Destiny.Location = new System.Drawing.Point(613, 0);
            this.lbl_Destiny.Name = "lbl_Destiny";
            this.lbl_Destiny.Size = new System.Drawing.Size(252, 81);
            this.lbl_Destiny.TabIndex = 14;
            this.lbl_Destiny.Text = "Destiny";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Controls.Add(this.pictureBox3);
            this.panel1.Controls.Add(this.lbl_Start_A_New_Life);
            this.panel1.Controls.Add(this.lbl_Destiny);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1482, 111);
            this.panel1.TabIndex = 16;
            // 
            // s
            // 
            this.s.Controls.Add(this.tb_ID);
            this.s.Controls.Add(this.lbl_ID);
            this.s.Controls.Add(this.tb_Address);
            this.s.Controls.Add(this.tb_Cast);
            this.s.Controls.Add(this.tb_Religion);
            this.s.Controls.Add(this.tb_Mobile_No);
            this.s.Controls.Add(this.lbl_Address);
            this.s.Controls.Add(this.lbl_Cast);
            this.s.Controls.Add(this.lbl_Religion);
            this.s.Controls.Add(this.lbl_Mobile_No);
            this.s.Controls.Add(this.dtp_DOB);
            this.s.Controls.Add(this.lbl_DOB);
            this.s.Controls.Add(this.tb_Gender);
            this.s.Controls.Add(this.lbl_Gender);
            this.s.Controls.Add(this.tb_Last_Name);
            this.s.Controls.Add(this.lbl_Last_Name);
            this.s.Controls.Add(this.v);
            this.s.Controls.Add(this.lbl_First_Name);
            this.s.Controls.Add(this.btn_Upload);
            this.s.Controls.Add(this.pictureBox5);
            this.s.Controls.Add(this.panel4);
            this.s.Location = new System.Drawing.Point(488, 111);
            this.s.Name = "s";
            this.s.Size = new System.Drawing.Size(518, 640);
            this.s.TabIndex = 17;
            this.s.TabStop = false;
            // 
            // tb_ID
            // 
            this.tb_ID.Font = new System.Drawing.Font("Times New Roman", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_ID.Location = new System.Drawing.Point(223, 233);
            this.tb_ID.Name = "tb_ID";
            this.tb_ID.Size = new System.Drawing.Size(93, 32);
            this.tb_ID.TabIndex = 22;
            // 
            // lbl_ID
            // 
            this.lbl_ID.AutoSize = true;
            this.lbl_ID.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ID.ForeColor = System.Drawing.Color.Navy;
            this.lbl_ID.Location = new System.Drawing.Point(77, 239);
            this.lbl_ID.Name = "lbl_ID";
            this.lbl_ID.Size = new System.Drawing.Size(36, 26);
            this.lbl_ID.TabIndex = 21;
            this.lbl_ID.Text = "ID";
            // 
            // tb_Address
            // 
            this.tb_Address.Font = new System.Drawing.Font("Times New Roman", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Address.Location = new System.Drawing.Point(223, 604);
            this.tb_Address.Name = "tb_Address";
            this.tb_Address.Size = new System.Drawing.Size(229, 32);
            this.tb_Address.TabIndex = 18;
            // 
            // tb_Cast
            // 
            this.tb_Cast.Font = new System.Drawing.Font("Times New Roman", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Cast.Location = new System.Drawing.Point(223, 558);
            this.tb_Cast.Name = "tb_Cast";
            this.tb_Cast.Size = new System.Drawing.Size(229, 32);
            this.tb_Cast.TabIndex = 16;
            // 
            // tb_Religion
            // 
            this.tb_Religion.Font = new System.Drawing.Font("Times New Roman", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Religion.Location = new System.Drawing.Point(223, 510);
            this.tb_Religion.Name = "tb_Religion";
            this.tb_Religion.Size = new System.Drawing.Size(229, 32);
            this.tb_Religion.TabIndex = 14;
            // 
            // tb_Mobile_No
            // 
            this.tb_Mobile_No.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Mobile_No.Location = new System.Drawing.Point(223, 462);
            this.tb_Mobile_No.Name = "tb_Mobile_No";
            this.tb_Mobile_No.Size = new System.Drawing.Size(229, 32);
            this.tb_Mobile_No.TabIndex = 13;
            // 
            // lbl_Address
            // 
            this.lbl_Address.AutoSize = true;
            this.lbl_Address.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Address.ForeColor = System.Drawing.Color.Navy;
            this.lbl_Address.Location = new System.Drawing.Point(77, 607);
            this.lbl_Address.Name = "lbl_Address";
            this.lbl_Address.Size = new System.Drawing.Size(88, 26);
            this.lbl_Address.TabIndex = 20;
            this.lbl_Address.Text = "Address";
            // 
            // lbl_Cast
            // 
            this.lbl_Cast.AutoSize = true;
            this.lbl_Cast.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Cast.ForeColor = System.Drawing.Color.Navy;
            this.lbl_Cast.Location = new System.Drawing.Point(77, 561);
            this.lbl_Cast.Name = "lbl_Cast";
            this.lbl_Cast.Size = new System.Drawing.Size(52, 26);
            this.lbl_Cast.TabIndex = 19;
            this.lbl_Cast.Text = "Cast";
            // 
            // lbl_Religion
            // 
            this.lbl_Religion.AutoSize = true;
            this.lbl_Religion.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Religion.ForeColor = System.Drawing.Color.Navy;
            this.lbl_Religion.Location = new System.Drawing.Point(77, 513);
            this.lbl_Religion.Name = "lbl_Religion";
            this.lbl_Religion.Size = new System.Drawing.Size(90, 26);
            this.lbl_Religion.TabIndex = 17;
            this.lbl_Religion.Text = "Religion";
            // 
            // lbl_Mobile_No
            // 
            this.lbl_Mobile_No.AutoSize = true;
            this.lbl_Mobile_No.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Mobile_No.ForeColor = System.Drawing.Color.Navy;
            this.lbl_Mobile_No.Location = new System.Drawing.Point(77, 462);
            this.lbl_Mobile_No.Name = "lbl_Mobile_No";
            this.lbl_Mobile_No.Size = new System.Drawing.Size(117, 26);
            this.lbl_Mobile_No.TabIndex = 15;
            this.lbl_Mobile_No.Text = "Mobile No.";
            // 
            // dtp_DOB
            // 
            this.dtp_DOB.CalendarFont = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtp_DOB.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtp_DOB.Location = new System.Drawing.Point(223, 417);
            this.dtp_DOB.Name = "dtp_DOB";
            this.dtp_DOB.Size = new System.Drawing.Size(243, 32);
            this.dtp_DOB.TabIndex = 11;
            // 
            // lbl_DOB
            // 
            this.lbl_DOB.AutoSize = true;
            this.lbl_DOB.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_DOB.ForeColor = System.Drawing.Color.Navy;
            this.lbl_DOB.Location = new System.Drawing.Point(77, 417);
            this.lbl_DOB.Name = "lbl_DOB";
            this.lbl_DOB.Size = new System.Drawing.Size(59, 26);
            this.lbl_DOB.TabIndex = 12;
            this.lbl_DOB.Text = "DOB";
            // 
            // tb_Gender
            // 
            this.tb_Gender.Font = new System.Drawing.Font("Times New Roman", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Gender.Location = new System.Drawing.Point(223, 367);
            this.tb_Gender.Name = "tb_Gender";
            this.tb_Gender.Size = new System.Drawing.Size(232, 32);
            this.tb_Gender.TabIndex = 9;
            // 
            // lbl_Gender
            // 
            this.lbl_Gender.AutoSize = true;
            this.lbl_Gender.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Gender.ForeColor = System.Drawing.Color.Navy;
            this.lbl_Gender.Location = new System.Drawing.Point(77, 373);
            this.lbl_Gender.Name = "lbl_Gender";
            this.lbl_Gender.Size = new System.Drawing.Size(80, 26);
            this.lbl_Gender.TabIndex = 10;
            this.lbl_Gender.Text = "Gender";
            // 
            // tb_Last_Name
            // 
            this.tb_Last_Name.Font = new System.Drawing.Font("Times New Roman", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Last_Name.Location = new System.Drawing.Point(223, 317);
            this.tb_Last_Name.Name = "tb_Last_Name";
            this.tb_Last_Name.Size = new System.Drawing.Size(232, 32);
            this.tb_Last_Name.TabIndex = 7;
            // 
            // lbl_Last_Name
            // 
            this.lbl_Last_Name.AutoSize = true;
            this.lbl_Last_Name.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Last_Name.ForeColor = System.Drawing.Color.Navy;
            this.lbl_Last_Name.Location = new System.Drawing.Point(77, 323);
            this.lbl_Last_Name.Name = "lbl_Last_Name";
            this.lbl_Last_Name.Size = new System.Drawing.Size(110, 26);
            this.lbl_Last_Name.TabIndex = 8;
            this.lbl_Last_Name.Text = "Last Name";
            // 
            // v
            // 
            this.v.Font = new System.Drawing.Font("Times New Roman", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.v.Location = new System.Drawing.Point(223, 274);
            this.v.Name = "v";
            this.v.Size = new System.Drawing.Size(229, 32);
            this.v.TabIndex = 5;
            // 
            // lbl_First_Name
            // 
            this.lbl_First_Name.AutoSize = true;
            this.lbl_First_Name.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_First_Name.ForeColor = System.Drawing.Color.Navy;
            this.lbl_First_Name.Location = new System.Drawing.Point(77, 277);
            this.lbl_First_Name.Name = "lbl_First_Name";
            this.lbl_First_Name.Size = new System.Drawing.Size(114, 26);
            this.lbl_First_Name.TabIndex = 6;
            this.lbl_First_Name.Text = "First Name";
            // 
            // btn_Upload
            // 
            this.btn_Upload.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.btn_Upload.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Upload.Location = new System.Drawing.Point(200, 182);
            this.btn_Upload.Name = "btn_Upload";
            this.btn_Upload.Size = new System.Drawing.Size(116, 37);
            this.btn_Upload.TabIndex = 4;
            this.btn_Upload.Text = "Upload";
            this.btn_Upload.UseVisualStyleBackColor = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.pictureBox5.Location = new System.Drawing.Point(200, 65);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(116, 111);
            this.pictureBox5.TabIndex = 3;
            this.pictureBox5.TabStop = false;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.panel4.Controls.Add(this.lbl_Registration_Details);
            this.panel4.Location = new System.Drawing.Point(0, 0);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(518, 59);
            this.panel4.TabIndex = 2;
            // 
            // lbl_Registration_Details
            // 
            this.lbl_Registration_Details.AutoSize = true;
            this.lbl_Registration_Details.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Registration_Details.Location = new System.Drawing.Point(168, 13);
            this.lbl_Registration_Details.Name = "lbl_Registration_Details";
            this.lbl_Registration_Details.Size = new System.Drawing.Size(237, 33);
            this.lbl_Registration_Details.TabIndex = 0;
            this.lbl_Registration_Details.Text = "Registration Details";
            // 
            // frm_Personal_Detail
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.ClientSize = new System.Drawing.Size(1482, 753);
            this.Controls.Add(this.s);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.pictureBox2);
            this.Name = "frm_Personal_Detail";
            this.Text = "frm_Personal_Detail";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.s.ResumeLayout(false);
            this.s.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Label lbl_Start_A_New_Life;
        private System.Windows.Forms.Label lbl_Destiny;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.GroupBox s;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label lbl_Registration_Details;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.Button btn_Upload;
        private System.Windows.Forms.TextBox v;
        private System.Windows.Forms.Label lbl_First_Name;
        private System.Windows.Forms.TextBox tb_Last_Name;
        private System.Windows.Forms.Label lbl_Last_Name;
        private System.Windows.Forms.TextBox tb_Gender;
        private System.Windows.Forms.Label lbl_Gender;
        private System.Windows.Forms.DateTimePicker dtp_DOB;
        private System.Windows.Forms.Label lbl_DOB;
        private System.Windows.Forms.TextBox tb_Address;
        private System.Windows.Forms.TextBox tb_Cast;
        private System.Windows.Forms.TextBox tb_Religion;
        private System.Windows.Forms.TextBox tb_Mobile_No;
        private System.Windows.Forms.Label lbl_Address;
        private System.Windows.Forms.Label lbl_Cast;
        private System.Windows.Forms.Label lbl_Religion;
        private System.Windows.Forms.Label lbl_Mobile_No;
        private System.Windows.Forms.Label lbl_ID;
        private System.Windows.Forms.TextBox tb_ID;
    }
}