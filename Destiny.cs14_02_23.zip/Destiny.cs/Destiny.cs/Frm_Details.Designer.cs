﻿namespace Destiny.cs
{
    partial class Frm_Details
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gb_Education_And_Occupation = new System.Windows.Forms.GroupBox();
            this.cmb_Employed_In = new System.Windows.Forms.ComboBox();
            this.lbl_Highest_Education = new System.Windows.Forms.Label();
            this.cmb_Highest_Educatiion = new System.Windows.Forms.ComboBox();
            this.lbl_Occupation = new System.Windows.Forms.Label();
            this.cmb_Occupation = new System.Windows.Forms.ComboBox();
            this.lbl_Employed_In = new System.Windows.Forms.Label();
            this.lbl_Monthly_Income = new System.Windows.Forms.Label();
            this.cmb_Monthly_Income = new System.Windows.Forms.ComboBox();
            this.btn_Save = new System.Windows.Forms.Button();
            this.btn_Next = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lbl_More_Personal_Details = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.cmb_Family_Values = new System.Windows.Forms.ComboBox();
            this.cmb_Family_Type = new System.Windows.Forms.ComboBox();
            this.cmb_Family_Status = new System.Windows.Forms.ComboBox();
            this.lbl_Family_Values = new System.Windows.Forms.Label();
            this.lbl_Family_Type = new System.Windows.Forms.Label();
            this.lbl_Family_Status = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.tb_Rassi_Moon_Sign = new System.Windows.Forms.TextBox();
            this.tb_Star = new System.Windows.Forms.TextBox();
            this.lbl_Rassi_Moon_Sign = new System.Windows.Forms.Label();
            this.lbl_Star = new System.Windows.Forms.Label();
            this.radioButton3 = new System.Windows.Forms.RadioButton();
            this.rb_Yes = new System.Windows.Forms.RadioButton();
            this.rb_No = new System.Windows.Forms.RadioButton();
            this.lbl_Have_Dash = new System.Windows.Forms.Label();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.gb_Education_And_Occupation.SuspendLayout();
            this.panel1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            this.SuspendLayout();
            // 
            // gb_Education_And_Occupation
            // 
            this.gb_Education_And_Occupation.Controls.Add(this.cmb_Employed_In);
            this.gb_Education_And_Occupation.Controls.Add(this.lbl_Highest_Education);
            this.gb_Education_And_Occupation.Controls.Add(this.cmb_Highest_Educatiion);
            this.gb_Education_And_Occupation.Controls.Add(this.lbl_Occupation);
            this.gb_Education_And_Occupation.Controls.Add(this.cmb_Occupation);
            this.gb_Education_And_Occupation.Controls.Add(this.lbl_Employed_In);
            this.gb_Education_And_Occupation.Controls.Add(this.lbl_Monthly_Income);
            this.gb_Education_And_Occupation.Controls.Add(this.cmb_Monthly_Income);
            this.gb_Education_And_Occupation.Font = new System.Drawing.Font("Times New Roman", 20F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gb_Education_And_Occupation.Location = new System.Drawing.Point(104, 153);
            this.gb_Education_And_Occupation.Name = "gb_Education_And_Occupation";
            this.gb_Education_And_Occupation.Size = new System.Drawing.Size(525, 343);
            this.gb_Education_And_Occupation.TabIndex = 1;
            this.gb_Education_And_Occupation.TabStop = false;
            this.gb_Education_And_Occupation.Text = "Education And  Occupation";
            // 
            // cmb_Employed_In
            // 
            this.cmb_Employed_In.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_Employed_In.FormattingEnabled = true;
            this.cmb_Employed_In.Items.AddRange(new object[] {
            "Government",
            "Private",
            "Business",
            "Defence",
            "Self Employed"});
            this.cmb_Employed_In.Location = new System.Drawing.Point(216, 203);
            this.cmb_Employed_In.Name = "cmb_Employed_In";
            this.cmb_Employed_In.Size = new System.Drawing.Size(246, 37);
            this.cmb_Employed_In.TabIndex = 15;
            // 
            // lbl_Highest_Education
            // 
            this.lbl_Highest_Education.AutoSize = true;
            this.lbl_Highest_Education.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Highest_Education.Location = new System.Drawing.Point(6, 56);
            this.lbl_Highest_Education.Name = "lbl_Highest_Education";
            this.lbl_Highest_Education.Size = new System.Drawing.Size(198, 29);
            this.lbl_Highest_Education.TabIndex = 10;
            this.lbl_Highest_Education.Text = "Highest Education";
            // 
            // cmb_Highest_Educatiion
            // 
            this.cmb_Highest_Educatiion.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_Highest_Educatiion.FormattingEnabled = true;
            this.cmb_Highest_Educatiion.Location = new System.Drawing.Point(216, 53);
            this.cmb_Highest_Educatiion.Name = "cmb_Highest_Educatiion";
            this.cmb_Highest_Educatiion.Size = new System.Drawing.Size(246, 37);
            this.cmb_Highest_Educatiion.TabIndex = 9;
            // 
            // lbl_Occupation
            // 
            this.lbl_Occupation.AutoSize = true;
            this.lbl_Occupation.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Occupation.Location = new System.Drawing.Point(6, 131);
            this.lbl_Occupation.Name = "lbl_Occupation";
            this.lbl_Occupation.Size = new System.Drawing.Size(129, 29);
            this.lbl_Occupation.TabIndex = 12;
            this.lbl_Occupation.Text = "Occupation";
            // 
            // cmb_Occupation
            // 
            this.cmb_Occupation.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_Occupation.FormattingEnabled = true;
            this.cmb_Occupation.Location = new System.Drawing.Point(216, 128);
            this.cmb_Occupation.Name = "cmb_Occupation";
            this.cmb_Occupation.Size = new System.Drawing.Size(246, 37);
            this.cmb_Occupation.TabIndex = 11;
            // 
            // lbl_Employed_In
            // 
            this.lbl_Employed_In.AutoSize = true;
            this.lbl_Employed_In.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Employed_In.Location = new System.Drawing.Point(6, 206);
            this.lbl_Employed_In.Name = "lbl_Employed_In";
            this.lbl_Employed_In.Size = new System.Drawing.Size(144, 29);
            this.lbl_Employed_In.TabIndex = 14;
            this.lbl_Employed_In.Text = "Employed In";
            // 
            // lbl_Monthly_Income
            // 
            this.lbl_Monthly_Income.AutoSize = true;
            this.lbl_Monthly_Income.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Monthly_Income.Location = new System.Drawing.Point(6, 280);
            this.lbl_Monthly_Income.Name = "lbl_Monthly_Income";
            this.lbl_Monthly_Income.Size = new System.Drawing.Size(182, 29);
            this.lbl_Monthly_Income.TabIndex = 16;
            this.lbl_Monthly_Income.Text = "Monthly Income";
            // 
            // cmb_Monthly_Income
            // 
            this.cmb_Monthly_Income.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_Monthly_Income.FormattingEnabled = true;
            this.cmb_Monthly_Income.Location = new System.Drawing.Point(216, 277);
            this.cmb_Monthly_Income.Name = "cmb_Monthly_Income";
            this.cmb_Monthly_Income.Size = new System.Drawing.Size(246, 37);
            this.cmb_Monthly_Income.TabIndex = 20;
            // 
            // btn_Save
            // 
            this.btn_Save.BackColor = System.Drawing.SystemColors.Info;
            this.btn_Save.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Save.ForeColor = System.Drawing.Color.Red;
            this.btn_Save.Location = new System.Drawing.Point(788, 511);
            this.btn_Save.Name = "btn_Save";
            this.btn_Save.Size = new System.Drawing.Size(138, 46);
            this.btn_Save.TabIndex = 1;
            this.btn_Save.Text = "Save";
            this.btn_Save.UseVisualStyleBackColor = false;
            // 
            // btn_Next
            // 
            this.btn_Next.BackColor = System.Drawing.SystemColors.Info;
            this.btn_Next.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Next.ForeColor = System.Drawing.Color.Red;
            this.btn_Next.Location = new System.Drawing.Point(1024, 511);
            this.btn_Next.Name = "btn_Next";
            this.btn_Next.Size = new System.Drawing.Size(107, 46);
            this.btn_Next.TabIndex = 2;
            this.btn_Next.Text = "Next";
            this.btn_Next.UseVisualStyleBackColor = false;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel1.Controls.Add(this.pictureBox7);
            this.panel1.Controls.Add(this.lbl_More_Personal_Details);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1482, 116);
            this.panel1.TabIndex = 17;
            // 
            // lbl_More_Personal_Details
            // 
            this.lbl_More_Personal_Details.AutoSize = true;
            this.lbl_More_Personal_Details.Font = new System.Drawing.Font("Times New Roman", 36F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_More_Personal_Details.ForeColor = System.Drawing.Color.Navy;
            this.lbl_More_Personal_Details.Location = new System.Drawing.Point(440, 23);
            this.lbl_More_Personal_Details.Name = "lbl_More_Personal_Details";
            this.lbl_More_Personal_Details.Size = new System.Drawing.Size(586, 67);
            this.lbl_More_Personal_Details.TabIndex = 0;
            this.lbl_More_Personal_Details.Text = "More Personal Details";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.cmb_Family_Values);
            this.groupBox1.Controls.Add(this.cmb_Family_Type);
            this.groupBox1.Controls.Add(this.cmb_Family_Status);
            this.groupBox1.Controls.Add(this.lbl_Family_Values);
            this.groupBox1.Controls.Add(this.lbl_Family_Type);
            this.groupBox1.Controls.Add(this.lbl_Family_Status);
            this.groupBox1.Font = new System.Drawing.Font("Times New Roman", 19.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(765, 153);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(516, 261);
            this.groupBox1.TabIndex = 18;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Family Profile";
            // 
            // cmb_Family_Values
            // 
            this.cmb_Family_Values.Font = new System.Drawing.Font("Times New Roman", 15F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_Family_Values.FormattingEnabled = true;
            this.cmb_Family_Values.Items.AddRange(new object[] {
            "Orthodox",
            "Traditional",
            "Moderate",
            "Liberal"});
            this.cmb_Family_Values.Location = new System.Drawing.Point(177, 191);
            this.cmb_Family_Values.Name = "cmb_Family_Values";
            this.cmb_Family_Values.Size = new System.Drawing.Size(231, 38);
            this.cmb_Family_Values.TabIndex = 5;
            // 
            // cmb_Family_Type
            // 
            this.cmb_Family_Type.Font = new System.Drawing.Font("Times New Roman", 15F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_Family_Type.FormattingEnabled = true;
            this.cmb_Family_Type.Items.AddRange(new object[] {
            "Joint",
            "Nuclear"});
            this.cmb_Family_Type.Location = new System.Drawing.Point(177, 125);
            this.cmb_Family_Type.Name = "cmb_Family_Type";
            this.cmb_Family_Type.Size = new System.Drawing.Size(231, 38);
            this.cmb_Family_Type.TabIndex = 4;
            // 
            // cmb_Family_Status
            // 
            this.cmb_Family_Status.Font = new System.Drawing.Font("Times New Roman", 15F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_Family_Status.FormattingEnabled = true;
            this.cmb_Family_Status.Items.AddRange(new object[] {
            "Middle Class",
            "Upper Middle Class",
            "Rich",
            "Affluent"});
            this.cmb_Family_Status.Location = new System.Drawing.Point(177, 57);
            this.cmb_Family_Status.Name = "cmb_Family_Status";
            this.cmb_Family_Status.Size = new System.Drawing.Size(231, 38);
            this.cmb_Family_Status.TabIndex = 3;
            // 
            // lbl_Family_Values
            // 
            this.lbl_Family_Values.AutoSize = true;
            this.lbl_Family_Values.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Family_Values.Location = new System.Drawing.Point(6, 196);
            this.lbl_Family_Values.Name = "lbl_Family_Values";
            this.lbl_Family_Values.Size = new System.Drawing.Size(155, 29);
            this.lbl_Family_Values.TabIndex = 2;
            this.lbl_Family_Values.Text = "Family Values";
            // 
            // lbl_Family_Type
            // 
            this.lbl_Family_Type.AutoSize = true;
            this.lbl_Family_Type.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Family_Type.Location = new System.Drawing.Point(6, 129);
            this.lbl_Family_Type.Name = "lbl_Family_Type";
            this.lbl_Family_Type.Size = new System.Drawing.Size(138, 29);
            this.lbl_Family_Type.TabIndex = 1;
            this.lbl_Family_Type.Text = "Family Type";
            // 
            // lbl_Family_Status
            // 
            this.lbl_Family_Status.AutoSize = true;
            this.lbl_Family_Status.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Family_Status.Location = new System.Drawing.Point(6, 61);
            this.lbl_Family_Status.Name = "lbl_Family_Status";
            this.lbl_Family_Status.Size = new System.Drawing.Size(151, 29);
            this.lbl_Family_Status.TabIndex = 0;
            this.lbl_Family_Status.Text = "Family Status";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.tb_Rassi_Moon_Sign);
            this.groupBox2.Controls.Add(this.tb_Star);
            this.groupBox2.Controls.Add(this.lbl_Rassi_Moon_Sign);
            this.groupBox2.Controls.Add(this.lbl_Star);
            this.groupBox2.Controls.Add(this.radioButton3);
            this.groupBox2.Controls.Add(this.rb_Yes);
            this.groupBox2.Controls.Add(this.rb_No);
            this.groupBox2.Controls.Add(this.lbl_Have_Dash);
            this.groupBox2.Font = new System.Drawing.Font("Times New Roman", 19.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(104, 485);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(567, 239);
            this.groupBox2.TabIndex = 19;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Astrological Info";
            // 
            // tb_Rassi_Moon_Sign
            // 
            this.tb_Rassi_Moon_Sign.Font = new System.Drawing.Font("Times New Roman", 15F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Rassi_Moon_Sign.Location = new System.Drawing.Point(216, 177);
            this.tb_Rassi_Moon_Sign.Name = "tb_Rassi_Moon_Sign";
            this.tb_Rassi_Moon_Sign.Size = new System.Drawing.Size(120, 36);
            this.tb_Rassi_Moon_Sign.TabIndex = 7;
            // 
            // tb_Star
            // 
            this.tb_Star.Font = new System.Drawing.Font("Times New Roman", 15F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Star.Location = new System.Drawing.Point(216, 116);
            this.tb_Star.Name = "tb_Star";
            this.tb_Star.Size = new System.Drawing.Size(120, 36);
            this.tb_Star.TabIndex = 6;
            // 
            // lbl_Rassi_Moon_Sign
            // 
            this.lbl_Rassi_Moon_Sign.AutoSize = true;
            this.lbl_Rassi_Moon_Sign.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Rassi_Moon_Sign.Location = new System.Drawing.Point(6, 177);
            this.lbl_Rassi_Moon_Sign.Name = "lbl_Rassi_Moon_Sign";
            this.lbl_Rassi_Moon_Sign.Size = new System.Drawing.Size(198, 29);
            this.lbl_Rassi_Moon_Sign.TabIndex = 5;
            this.lbl_Rassi_Moon_Sign.Text = "Rassi / Moon Sign";
            // 
            // lbl_Star
            // 
            this.lbl_Star.AutoSize = true;
            this.lbl_Star.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Star.Location = new System.Drawing.Point(6, 123);
            this.lbl_Star.Name = "lbl_Star";
            this.lbl_Star.Size = new System.Drawing.Size(53, 29);
            this.lbl_Star.TabIndex = 4;
            this.lbl_Star.Text = "Star";
            // 
            // radioButton3
            // 
            this.radioButton3.AutoSize = true;
            this.radioButton3.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton3.Location = new System.Drawing.Point(402, 60);
            this.radioButton3.Name = "radioButton3";
            this.radioButton3.Size = new System.Drawing.Size(157, 33);
            this.radioButton3.TabIndex = 3;
            this.radioButton3.TabStop = true;
            this.radioButton3.Text = "Don\'t Know";
            this.radioButton3.UseVisualStyleBackColor = true;
            // 
            // rb_Yes
            // 
            this.rb_Yes.AutoSize = true;
            this.rb_Yes.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_Yes.Location = new System.Drawing.Point(312, 60);
            this.rb_Yes.Name = "rb_Yes";
            this.rb_Yes.Size = new System.Drawing.Size(69, 33);
            this.rb_Yes.TabIndex = 2;
            this.rb_Yes.TabStop = true;
            this.rb_Yes.Text = "Yes";
            this.rb_Yes.UseVisualStyleBackColor = true;
            // 
            // rb_No
            // 
            this.rb_No.AutoSize = true;
            this.rb_No.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_No.Location = new System.Drawing.Point(216, 60);
            this.rb_No.Name = "rb_No";
            this.rb_No.Size = new System.Drawing.Size(65, 33);
            this.rb_No.TabIndex = 1;
            this.rb_No.TabStop = true;
            this.rb_No.Text = "No";
            this.rb_No.UseVisualStyleBackColor = true;
            // 
            // lbl_Have_Dash
            // 
            this.lbl_Have_Dash.AutoSize = true;
            this.lbl_Have_Dash.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Have_Dash.Location = new System.Drawing.Point(6, 62);
            this.lbl_Have_Dash.Name = "lbl_Have_Dash";
            this.lbl_Have_Dash.Size = new System.Drawing.Size(123, 29);
            this.lbl_Have_Dash.TabIndex = 0;
            this.lbl_Have_Dash.Text = "Have Dash";
            // 
            // pictureBox7
            // 
            this.pictureBox7.Image = global::Destiny.cs.Properties.Resources.download__1_1;
            this.pictureBox7.Location = new System.Drawing.Point(1401, 23);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(78, 67);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox7.TabIndex = 24;
            this.pictureBox7.TabStop = false;
            // 
            // Frm_Details
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ClientSize = new System.Drawing.Size(1482, 753);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.btn_Next);
            this.Controls.Add(this.btn_Save);
            this.Controls.Add(this.gb_Education_And_Occupation);
            this.Name = "Frm_Details";
            this.Text = "Frm_Details";
            this.gb_Education_And_Occupation.ResumeLayout(false);
            this.gb_Education_And_Occupation.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.GroupBox gb_Education_And_Occupation;
        private System.Windows.Forms.ComboBox cmb_Employed_In;
        private System.Windows.Forms.Label lbl_Highest_Education;
        private System.Windows.Forms.ComboBox cmb_Highest_Educatiion;
        private System.Windows.Forms.Label lbl_Occupation;
        private System.Windows.Forms.ComboBox cmb_Occupation;
        private System.Windows.Forms.Label lbl_Employed_In;
        private System.Windows.Forms.ComboBox cmb_Monthly_Income;
        private System.Windows.Forms.Label lbl_Monthly_Income;
        private System.Windows.Forms.Button btn_Save;
        private System.Windows.Forms.Button btn_Next;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lbl_More_Personal_Details;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ComboBox cmb_Family_Values;
        private System.Windows.Forms.ComboBox cmb_Family_Type;
        private System.Windows.Forms.ComboBox cmb_Family_Status;
        private System.Windows.Forms.Label lbl_Family_Values;
        private System.Windows.Forms.Label lbl_Family_Type;
        private System.Windows.Forms.Label lbl_Family_Status;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox tb_Rassi_Moon_Sign;
        private System.Windows.Forms.TextBox tb_Star;
        private System.Windows.Forms.Label lbl_Rassi_Moon_Sign;
        private System.Windows.Forms.Label lbl_Star;
        private System.Windows.Forms.RadioButton radioButton3;
        private System.Windows.Forms.RadioButton rb_Yes;
        private System.Windows.Forms.RadioButton rb_No;
        private System.Windows.Forms.Label lbl_Have_Dash;
        private System.Windows.Forms.PictureBox pictureBox7;
    }
}